
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Borehole model

clear all
close all
clc




n         =      7;             % no. of input variables





%---------------------------lognormal------------------------------%

m_log    =      7.71;
s_log    =      1.0056*2;
v_log    =      s_log.^2;

m_norm   =      log(m_log.^2./sqrt(v_log + m_log.^2));
s_norm   =      sqrt(log(v_log./m_log.^2 + 1));

g_log    =      (exp(s_norm.^2) + 2) .* sqrt(exp(s_norm.^2) - 1);
G_log    =      exp(4*s_norm.^2) + 2*exp(3*s_norm.^2) + 3*exp(2*s_norm.^2) - 6 + 3;


%-----------------------uniform----------------------------%

a_uni    =      [63070,  990,  63.1,  700,  1120,  9855];
b_uni    =      [115600, 1110,  116,  820,  1680,  12045];

m_uni    =      (a_uni + b_uni)./2;
s_uni    =      sqrt(1/12 * (b_uni - a_uni).^2);
g_uni    =      zeros(1,6);
G_uni    =      repmat(-6/5 + 3, [1,6]);

a_uni    =      a_uni - m_uni * 0.4;
b_uni    =      b_uni + m_uni * 0.4;

m_uni    =      (a_uni + b_uni)./2;
s_uni    =      sqrt(1/12 * (b_uni - a_uni).^2);


%%%%%%%%%%%%%%%%%%%%%%%%

mu       =      [m_log, m_uni];
sigma    =      [s_log, s_uni];
gamma    =      [g_log, g_uni];
Gamma    =      [G_log, G_uni];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cov       =      diag(sigma.^2);
rho       =      corrcov(cov);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha +-

alpha_p   =    (gamma  + sqrt(4 + gamma.^2))/2;
alpha_m   =    (-gamma + sqrt(4 + gamma.^2))/2;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% weights +-

w_p       =    alpha_m ./ (alpha_p + alpha_m);
w_m       =    alpha_p ./ (alpha_p + alpha_m);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% samples  

%---------------samples xi--------------------%
e  =  eye(n,n);

sam_1 = [];
for i = 1:n
    
    xi_p    =    mu + alpha_p .* sigma .* e(i,:);
    xi_m    =    mu - alpha_m .* sigma .* e(i,:);
    
    sam_1   =    [sam_1; xi_p; xi_m];
    
end
sam_1;



%---------------samples xi xj-----------------%
b  =  nchoosek(n,2);
C  =  nchoosek([1:n],2);


sam_2 = [];
for i = 1:b
    
    row         =   C(i,:);    
    xi_p_xj_p   =   mu + alpha_p .* sigma .* e(row(1),:) + alpha_p .* sigma .* e(row(2),:);    
    sam_2       =   [sam_2; xi_p_xj_p];
    
end
sam_2;

samples  =  [mu; sam_1; sam_2];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L_sam = size(samples,1);

y = [];
for i = 1:L_sam
    
    x = samples(i,:);
   
    rw       =      0.1;
    num      =      2 * pi * x(2) .* (x(3) - x(5));
    deno     =      log(x(1)./rw) .* (1 + 2*x(6).*x(2)./(log(x(1)./rw) .* rw.^2 .* x(7)) + x(2)./x(4));

    f        =      num./deno;
    
    y = [y; f];
    
end
y;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Delta

rho_ij = [];
for i = 1:n-1
    
    row     =   rho(i,i+1:end);    
    rho_ij  =   [rho_ij, row];
    
end
rho_ij;



alpha_ij = [];
for i = 1:b
    
    row       =   C(i,:);    
    v         =   alpha_p(row(1)) * alpha_p(row(2));    
    alpha_ij  =   [alpha_ij, v];
    
end
alpha_ij;


delta_ij  =   rho_ij./alpha_ij;
Wpp       =   delta_ij;



del_matrix = [];
for i = 1:n
    
    vec         =    delta_ij(1:n-i);    
    m           =    [zeros(1,i-1), 1, vec];    
    del_matrix  =    [del_matrix; m];    
    Lv          =    length(vec);    
    delta_ij    =    delta_ij(Lv+1:end);
    
end
del_matrix;


upper          =   triu(del_matrix,1);           % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
del_matrix     =   upper + eye(n,n) + lower;



delta_i  =  sum(del_matrix,2);
delta    =  sum(delta_i);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Final Weights

W0  =  1 - 3*n/2 + delta/2;

Wp  =  w_p - delta_i' + 1;

Wm  =  w_m;









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    new_y    =  y.^i;
          
    mom      =  W0 * new_y(1) + sum(Wp .* new_y(2:2:2*n+1)') + sum(Wm .* new_y(3:2:2*n+1)') + sum(Wpp .* new_y(2*n+2:end)');
        
    raw_mom  =  [raw_mom; mom];
        
end
raw_mom;       
        

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

[mean_y, std_y, ske_y, kur_y]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 72.1021;
std_mcs  = 15.4828;
ske_mcs  = 0.3746;
kur_mcs  = 2.8801;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
 
mean_mcs = 75.2969;
std_mcs  = 58.5024;
ske_mcs  = 0.6612;
kur_mcs  = 3.6711;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
  
mean_mcs = 82.0959;
std_mcs  = 118.5638;
ske_mcs  = 1.0653;
kur_mcs  = 5.9195;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

