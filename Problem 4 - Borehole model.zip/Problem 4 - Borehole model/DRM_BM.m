
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Borehole model


clear all
close all
clc


%%%%%%%%%%%%%%%%%%%
% no of inputs

n       =    7;



%%%%%%%%%%%%%%%%%%%%%%%%%
% no of samples

N       =    5;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

%---------------------------lognormal------------------------------%

m_log    =      7.71;
s_log    =      1.0056*2;
v_log    =      s_log.^2;

m_norm   =      log(m_log.^2./sqrt(v_log + m_log.^2));
s_norm   =      sqrt(log(v_log./m_log.^2 + 1));

%-----------------------uniform----------------------------%

a_uni    =      [63070,  990,  63.1,  700,  1120,  9855];
b_uni    =      [115600, 1110,  116,  820,  1680,  12045];

m_uni    =      (a_uni + b_uni)./2;
s_uni    =      sqrt(1/12 * (b_uni - a_uni).^2);

a_uni    =      a_uni - m_uni * 0.4;
b_uni    =      b_uni + m_uni * 0.4;

m_uni    =      (a_uni + b_uni)./2;
s_uni    =      sqrt(1/12 * (b_uni - a_uni).^2);

mu       =      [m_log, m_uni];
sigma    =      [s_log, s_uni];



%%%%%%%%%%%%%%%%%%%%%%
% no of output moments

m       =    4;


%%%%%%%%%%%%%%%%%%%%
% s-variate

s       =    4;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% input moments mu_j,i for each x_j using moment generating function

moments_l = [];

for i = 0:2*N-1
    
    mom      =   exp(i.*m_norm + 0.5*i^2*s_norm.^2);
    
    moments_l  =  [moments_l; mom];
    
end

moments_l;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% input moments mu_j,i for each x_j using moment generating function

moments_u = [];

for i = 0:2*N-1
    
    mom = 0;
    
    for j = 0:i
        
        mom   =   mom + (1/(i+1)) * a_uni.^j .* b_uni.^(i-j);
        
    end
        
    moments_u  =  [moments_u; mom];
    
end

moments_u;


moments = [moments_l, moments_u];






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights: w_j,i and Points: x_j,i

points  = [];
weights = [];

for j = 1:n                            % for each j = 1, 2, 3, ... , n
    
    moments_j   =   moments(:,j);      % moments of x_j = x1, x2,...
    
    
    
    
    
    
    
    %------------------------%
    % LHS matrix of moments
    
    LHS = [];    
    for i = 1:N
        
        vec     =   moments_j(i:N+i-1);
        
        
        row = [];        
        for k = 1:length(vec)
            
            row   =   [row, (-1)^(k-1) * vec(end-k+1)];
            
        end
        
        Row   =   row;        
        LHS   =   [LHS; Row];
        
            
    end    
    LHS;
    
    
    
    
    
    %------------------------------%
    % RHS column matrix of moments
    
    RHS    =    moments_j(N+1:2*N);
    
    
    
    
    
    
    
    %------------------------------%
    % r_j,1 ; r_j,2, r_j,3 ; ...
    
    r_j    =    linsolve(LHS, RHS);


    
    
    
    
    %-------------------------%
    % x_j,1 ; x_j,2 ; x_j,3  
    
    coeff = 1;    
    for k = 1:length(r_j)
        
        coeff    =   [coeff, (-1)^k * r_j(k)];
        
    end
    
    x_j    =   roots(coeff);  

    points =   [points, x_j];
    

    
    
    %-----------------------------%
    % Denominators of each w_j,i
    
    deno = [];
    for i = 1:N
        
        pr   =   1;
        
        for k = 1:N
            if (k~=i)                
                pr    =    pr * (x_j(i) - x_j(k));
            end            
        end
        
        deno    =    [deno; pr];
        
    end
    deno;
    
    
    
    
    
    
    
    %--------------------------------------%
    % moments in numerator of each w_j,i
    
    num_mu  =  flip(moments_j(1:N))';
    
    for i = 1:length(num_mu)
        
        if (rem(i,2)==0)
            
            num_mu(i)   =   - num_mu(i);
            
        end
        
    end    
    num_mu;
    

    
    
    
    
    
    
    %----------------------------------%
    % q_j,ik in numerators of w_j,i
    
    q_ik = [];
    
    for i = 1:N
        
        
        
        q0  =  1;
        
        q   =  [];       
        for k = 1:N-1
            
            q_k   =   r_j(k) - x_j(i) * q0;
            q0    =   q_k;
            q     =   [q; q0];
            
        end
        
        
        
        
        q_ik   =   [q_ik, q];
        
    end
            
    num_q   =   [repmat(1, [1,N]); q_ik]'; 
    
    

    
    
    
    
    
    
    
    %----------------------------%
    % numerator in w_j,i
    
    num   =   sum(num_mu .* num_q, 2);
    
    
    
    
    %---------------------------%
    % Weights w_j,i
    
    w_j       =   num./deno;
    
    weights   =   [weights, w_j];
        
end

points    =   points;
weights   =   weights;











for i = 1:s
    
    nCs(i) = nchoosek(n,i);
    
end
nCs;

max_nCs  =  max(nCs);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculating all expectations & their powers

all_exp = [];
for i = 1:s
    
    C = nchoosek([1:n], i);
    
    % E[Z(x1)],         E[Z(x2)],         E[Z(x3)]                             i = 1
    % E[Z(x1, x2)],     E[Z(x1, x3)],     E[Z(x2,x3)]                          i = 2
    % E[Z(x1, x2, x3)], E[Z(x1, x2, x4)], E[Z(x1, x3, x4)], E[Z(x2, x3, x4)]   i = 3
    
    
    
    
    
    
    %---------------------------------------------------------------------%
    Exp_j_m = [];
    
    for j = 1:length(C)
        
        vec = C(j,:);
        
        % i = 1
        % E[Z(x1)]  j = 1
        % E[Z(x2)]  j = 2
        % E[Z(x3)]  j = 3
        
        % i = 2
        % E[Z(x1, x2)]  j = 1
        % E[Z(x1, x3)]  j = 2
        % E[Z(x2, x3)]  j = 3
        
        % i = 3
        % E[Z(x1, x2, x3)]  j = 1
        % E[Z(x1, x2, x4)]  j = 1
        % E[Z(x1, x3, x4)]  j = 1
        % E[Z(x2, x3, x4)]  j = 1
        
        
        
        
        
        
        
        %--------Collection of weights & points---------%
        
        Ws   = [];
        x_js = [];
        for k = 1:length(vec)
            
            col         =     vec(k);
            
            wj_call     =     weights(:,col);            
            Ws          =     [Ws, wj_call];
            
            xj_call     =     points(:,col);
            x_js        =     [x_js, xj_call];
            
        end
        
        Ws;
        
        x_js;
        
        %--------Collection of weights & points---------%
        
        
        
        
        
        
        %------------------Product of weights--------------%
        prod_w   =   1;
        
        L        =   length(vec);

        for i1 = 1:L
            
            w_call   =   Ws(:,i1);
            
            
            
            
            new_w  = [];
            for i2 = 1:N                      % no. of quad points
                
                w          =   w_call(i2);
                
                
                rep_w      =   repmat(w, [N^(L-i1), 1]);
                
                new_w      =   [new_w; rep_w];
                
                rep_new_w  =   repmat(new_w, [N^(i1-1), 1]);
                 
            end
            
            rep_new_w;
            
            
            
            
            
            prod_w    =   prod_w .* rep_new_w;
            
        end
        final_w       =   prod_w;
        %------------------Product of weights--------------%
  
        
        
        
        
        
        
        
        
        
        %----------------------samples-----------------------%
        %-----------------------------------------%
        final_xj = [];
        for i1 = 1:length(vec)
            
            xj_call   =   x_js(:,i1);
            
            
            
            
            new_xj = [];
            for i2 = 1:N                     % no. of quad points
                
                xj          =   xj_call(i2);
                
                
                rep_xj      =   repmat(xj, [N^(L-i1), 1]);
                
                new_xj      =   [new_xj; rep_xj];
                
                rep_new_xj  =   repmat(new_xj, [N^(i1-1), 1]);
                 
            end
            
            
            
         
            final_xj = [final_xj, rep_new_xj];
                   
        end
        
        final_xj;
        %---------------------------------------%
        %--------------------------------------%
        L2       =     size(final_xj,1);
        
        sample   =     mu;
        
        samples = [];
        for i1 = 1:L2
            
            row_call           =     final_xj(i1,:);
            
            
            
            for i2 = 1:L
                
                position             =    vec(i2);
                
                entry_call           =    row_call(i2);
                
                sample(position)     =    entry_call;
                
            end
            
            
            
            samples = [samples; sample];
            
        end
        samples;       
        %-------------------------------------%
        %----------------------------samples----------------------%
        
        
        
        
        
        %----------------function----------------------%
        
        final_y = [];
        for k = 1:L2
            
            x        =      samples(k,:);  
    
            rw       =      0.1;
            num      =      2 * pi * x(2) .* (x(3) - x(5));
            deno     =      log(x(1)./rw) .* (1 + 2*x(6).*x(2)./(log(x(1)./rw) .* rw.^2 .* x(7)) + x(2)./x(4));

            f        =      num./deno;
       
            final_y  =     [final_y; f];
            
        end
        final_y;
        
        %----------------function----------------------%
        
        
        
        
        
        
        
        
        %-----------------Expectations ^ m------------------------%
        M = [1:m];
        
        Exp_1 = [];
        for k = 1:m
            
            Exp_j      =   sum(final_w .* final_y.^k);
            
            Exp_1      =   [Exp_1; Exp_j];
            
        end
        Exp_1;
        %-----------------Expectations ^ m------------------------%
        
        
        
        
        
        Exp_j_m = [Exp_j_m, Exp_1];
        
    end  %----- j
    Exp_j_m;
    %-----------------------------------------------------------------------%
    
    
    
    
    
    
    
    
    %----------collection of all exp---------------%
    if (s>1)
        no_col    =  max_nCs - nchoosek(n,i);
        zeromat   =  zeros(m, no_col);
        Exp_j_m   =  [Exp_j_m, zeromat];
    end

        
    all_exp         =  [all_exp; Exp_j_m];
    %----------collection of all exp---------------%
    
    
   
    
end %------ i
all_exp;

% E[Z(x1)],      E[Z(x2)],      E[Z(x3)]
% E[Z(x1)]^2,    E[Z(x2)]^2,    E[Z(x3)]^2

% E[Z(x1,x2)],   E[Z(x1,x3)],   E[Z(x2,x3)]
% E[Z(x1,x2)]^2, E[Z(x1,x3)]^2, E[Z(x2,x3)]^2








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Z(mu) = y(mu), y(mu)^2, ..., y(mu)^m

rw       =      0.1;
num      =      2 * pi * mu(2) .* (mu(3) - mu(5));
deno     =      log(mu(1)./rw) .* (1 + 2*mu(6).*mu(2)./(log(mu(1)./rw) .* rw.^2 .* mu(7)) + mu(2)./mu(4));

y_mean   =      num./deno;


for i = 1:m
    
    z_mean(i)    =    y_mean^i;
    
end

z_mean  =  z_mean';








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Raw Moments of y(x)

raw_mom = [];
for i = 1:m
    
    
    Exp_2       =     all_exp(i:m:end,:);
    
    
    %--------------------------------------------%
    SUM = 0;
    for j = 0:s
        
        b       =    (-1)^j * nchoosek(n-s+j-1,j);
        
        if (j==s)
            
            E   =    z_mean(i);
            
        else
            
            E   =    sum(Exp_2(end-j,:));
            
        end
        
        SUM     =    SUM + (b*E);
        
    end
    %-------------------------------------------%
    
    
    
    raw_mom        =  [raw_mom; SUM];
        
    
end
raw_mom;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Central moments of y(x)

mean_y = raw_mom(1)

var_y  = raw_mom(2) - mean_y^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4


[mean_y, std_y, ske_y, kur_y]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 72.1021;
std_mcs  = 15.4828;
ske_mcs  = 0.3746;
kur_mcs  = 2.8801;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
 
mean_mcs = 75.2969;
std_mcs  = 58.5024;
ske_mcs  = 0.6612;
kur_mcs  = 3.6711;
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
  
mean_mcs = 82.0959;
std_mcs  = 118.5638;
ske_mcs  = 1.0653;
kur_mcs  = 5.9195;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

