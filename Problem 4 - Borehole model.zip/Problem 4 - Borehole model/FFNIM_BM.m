
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Borehole model

clear all
close all
clc




n         =      7;             % no. of input variables





%---------------------------lognormal------------------------------%

m_log    =      7.71;
s_log    =      1.0056*2;
v_log    =      s_log.^2;

m_norm   =      log(m_log.^2./sqrt(v_log + m_log.^2));
s_norm   =      sqrt(log(v_log./m_log.^2 + 1));

g_log    =      (exp(s_norm.^2) + 2) .* sqrt(exp(s_norm.^2) - 1);
G_log    =      exp(4*s_norm.^2) + 2*exp(3*s_norm.^2) + 3*exp(2*s_norm.^2) - 6 + 3;


%-----------------------uniform----------------------------%

a_uni    =      [63070,  990,  63.1,  700,  1120,  9855];
b_uni    =      [115600, 1110,  116,  820,  1680,  12045];

m_uni    =      (a_uni + b_uni)./2;
s_uni    =      sqrt(1/12 * (b_uni - a_uni).^2);
g_uni    =      zeros(1,6);
G_uni    =      repmat(-6/5 + 3, [1,6]);

a_uni    =      a_uni - m_uni * 0.4;
b_uni    =      b_uni + m_uni * 0.4;

m_uni    =      (a_uni + b_uni)./2;
s_uni    =      sqrt(1/12 * (b_uni - a_uni).^2);


%%%%%%%%%%%%%%%%%%%%%%%%

mu       =      [m_log, m_uni];
sigma    =      [s_log, s_uni];
gamma    =      [g_log, g_uni];
Gamma    =      [G_log, G_uni];






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha 

alpha_1      =     (gamma - sqrt(4 * Gamma - 3 * gamma.^2))/2;
alpha_2      =     zeros(1, n);
alpha_3      =     (gamma + sqrt(4 * Gamma - 3 * gamma.^2))/2;


alpha_x1     =     [alpha_1(1), alpha_2(1), alpha_3(1)];
alpha_x2     =     [alpha_1(2), alpha_2(2), alpha_3(2)];
alpha_x3     =     [alpha_1(3), alpha_2(3), alpha_3(3)];
alpha_x4     =     [alpha_1(4), alpha_2(4), alpha_3(4)];
alpha_x5     =     [alpha_1(5), alpha_2(5), alpha_3(5)];
alpha_x6     =     [alpha_1(6), alpha_2(6), alpha_3(6)];
alpha_x7     =     [alpha_1(7), alpha_2(7), alpha_3(7)];





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights

w1   =   ((4 * Gamma - 3 * gamma.^2) + gamma .* sqrt(4 * Gamma - 3 * gamma.^2)) ./ (2 * (4 * Gamma - 3 * gamma.^2) .* (Gamma - gamma.^2));
w2   =   (Gamma - gamma.^2 - 1) ./ (Gamma - gamma.^2);
w3   =   ((4 * Gamma - 3 * gamma.^2) - gamma .* sqrt(4 * Gamma - 3 * gamma.^2)) ./ (2 * (4 * Gamma - 3 * gamma.^2) .* (Gamma - gamma.^2));


w_x1  =  [w1(1), w2(1), w3(1)];
w_x2  =  [w1(2), w2(2), w3(2)];
w_x3  =  [w1(3), w2(3), w3(3)];
w_x4  =  [w1(4), w2(4), w3(4)];
w_x5  =  [w1(5), w2(5), w3(5)];
w_x6  =  [w1(6), w2(6), w3(6)];
w_x7  =  [w1(7), w2(7), w3(7)];


w  =  [];
for i1 = 1:3    
    w_1   =   w_x1(i1);
    
    for i2 = 1:3        
        w_2    =    w_x2(i2);
        
        for i3 = 1:3            
            w_3    =   w_x3(i3);
            
            for i4 = 1:3
                w_4   =   w_x4(i4);

                for i5 = 1:3
                    w_5   =   w_x5(i5);

                    for i6 = 1:3
                        w_6   =   w_x6(i6);

                        for i7 = 1:3
                            w_7  =  w_x7(i7);
            
                            we     =   w_1 * w_2 * w_3 * w_4 * w_5 * w_6 * w_7;            
                            w      =   [w; we];
                        end

                    end
                end
            end            
        end        
    end    
end
w;






 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples

samples  =  [];
for i1 = 1:3    
    vec1   =   mu(1)  +  alpha_x1(i1) * sigma(1);
    
    for i2 = 1:3        
        vec2    =    mu(2)  +  alpha_x2(i2) * sigma(2);
        
        for i3 = 1:3            
            vec3   =   mu(3)   +   alpha_x3(i3) * sigma(3);
            
            for i4 = 1:3
                vec4       =  mu(4)   +  alpha_x4(i4) * sigma(4);

                for i5 = 1:3
                    vec5   =   mu(5)  +  alpha_x5(i5) * sigma(5);

                    for i6 = 1:3
                        vec6   =   mu(6)   +  alpha_x6(i6) * sigma(6);

                        for i7 = 1:3
                            vec7   =   mu(7)  +  alpha_x7(i7) * sigma(7);
            
                            s          =   [vec1,  vec2,  vec3, vec4, vec5, vec6, vec7];            
                            samples    =   [samples; s];
                        end
                    end
                end
            end
        end        
    end
end
samples;









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L_sam = size(samples,1);

y = [];
for i = 1:L_sam
    
    x = samples(i,:);
    
    rw       =      0.1;
    num      =      2 * pi * x(2) .* (x(3) - x(5));
    deno     =      log(x(1)./rw) .* (1 + 2*x(6).*x(2)./(log(x(1)./rw) .* rw.^2 .* x(7)) + x(2)./x(4));

    f        =      num./deno;
    
    y = [y; f];
    
end
y;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m  =  4;

raw_mom = [];
for i = 1:m
    
    mom     = sum(w .* y.^i);
    raw_mom = [raw_mom; mom];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

[mean_y, std_y, ske_y, kur_y]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 72.1021;
% std_mcs  = 15.4828;
% ske_mcs  = 0.3746;
% kur_mcs  = 2.8801;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
 
% mean_mcs = 75.2969;
% std_mcs  = 58.5024;
% ske_mcs  = 0.6612;
% kur_mcs  = 3.6711;
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
  
mean_mcs = 82.0959;
std_mcs  = 118.5638;
ske_mcs  = 1.0653;
kur_mcs  = 5.9195;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

