
% Borehole model

clc
clear all
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Evans method

% EM_1 = [-0.0595   -0.0248  -48.9716    3.1071];
% EM_2 = [0.1071    0.2211  -18.5042   28.6078];
% EM_3 = [0.5577    1.7099    4.3002   54.5937];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FFNI method

FFNIM_1 = [0.0222    0.0314    0.2505    0.3075];
FFNIM_2 = [0.0208    0.1489    1.6093    1.6701];
FFNIM_3 = [0.2500    0.8091    7.0199    9.3179];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Harr method

HM_1 = [-0.0792   -1.9889   27.7718   20.6823];
HM_2 = [-2.4081    0.1431   73.2771   29.4419];
HM_3 = [-50.3024  -82.2222 -126.3513  -44.2708];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Li method

LM_1 = [0.0219    1.5306  122.6870   81.1250];
LM_2 = [0.0161    8.6409  127.8256   80.5515];
LM_3 = [0.2193   21.0038  125.5651   87.0480];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified Harr method

MHM_1 = [-0.0792   -1.9889   27.7718   20.6823];
MHM_2 = [-2.4081    0.1431   73.2771   29.4419];
MHM_3 = [-50.3024  -82.2222 -126.3513  -44.2708];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified Rosenblueth method

MRM_1 = [0.0362    2.0105  135.1545   89.2899];
MRM_2 = [0.2640    9.3283  130.3656   88.6485];
MRM_3 = [1.6471   22.3470  126.7094   92.1343];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Zhao and Ono method

ZOM_1 = [0.0261    1.6915   85.6125    6.5964];
ZOM_2 = [0.0009    8.7304   95.9664   29.2468];
ZOM_3 = [-0.0271   20.8168   95.7423   56.0250];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rosenblueth method

RM_1 = [0.0365    0.5289   14.1694   12.2422];
RM_2 = [0.2682    1.3090   13.5561   21.6758];
RM_3 = [1.6698    4.7841   26.3387   37.6188];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DRM

DRM_1 = [0.0222    0.0314    0.2505    0.3075];
DRM_2 = [0.0208    0.1489    1.6094    1.6651];
DRM_3 = [0.0687    0.0325    0.3841    0.3889];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MEan

y1 = abs([RM_1(1) HM_1(1) MHM_1(1) LM_1(1) MRM_1(1) ZOM_1(1) FFNIM_1(1) DRM_1(1);  RM_2(1) HM_2(1) MHM_2(1) LM_2(1) MRM_2(1) ZOM_2(1) FFNIM_2(1) DRM_2(1); RM_3(1) HM_3(1) MHM_3(1) LM_3(1) MRM_3(1) ZOM_3(1) FFNIM_3(1) DRM_3(1)]);
y2 = abs([RM_1(2) HM_1(2) MHM_1(2) LM_1(2) MRM_1(2) ZOM_1(2) FFNIM_1(2) DRM_1(2);  RM_2(2) HM_2(2) MHM_2(2) LM_2(2) MRM_2(2) ZOM_2(2) FFNIM_2(2) DRM_2(2); RM_3(2) HM_3(2) MHM_3(2) LM_3(2) MRM_3(2) ZOM_3(2) FFNIM_3(2) DRM_3(2)]);
y3 = abs([RM_1(3) HM_1(3) MHM_1(3) LM_1(3) MRM_1(3) ZOM_1(3) FFNIM_1(3) DRM_1(3);  RM_2(3) HM_2(3) MHM_2(3) LM_2(3) MRM_2(3) ZOM_2(3) FFNIM_2(3) DRM_2(3); RM_3(3) HM_3(3) MHM_3(3) LM_3(3) MRM_3(3) ZOM_3(3) FFNIM_3(3) DRM_3(3)]);
y4 = abs([RM_1(4) HM_1(4) MHM_1(4) LM_1(4) MRM_1(4) ZOM_1(4) FFNIM_1(4) DRM_1(4);  RM_2(4) HM_2(4) MHM_2(4) LM_2(4) MRM_2(4) ZOM_2(4) FFNIM_2(4) DRM_2(4); RM_3(4) HM_3(4) MHM_3(4) LM_3(4) MRM_3(4) ZOM_3(4) FFNIM_3(4) DRM_3(4)]);









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

color_matrix = [
    % 0.0 0.5 0.5; 
    0.0 0.8 0.8; 
    0.5 0.5 0.0;
    0.8 0.8 0.0; 
    0.9 0.54 0.0; 
    0.40 0.40 0.70; 
    0.60 0.40 0.80;
    0.6 0.10 0.10; 
    1.0 0.30 0.30  
];

% 1. Create a tiled chart layout
figure;
tcl = tiledlayout(2,2); % Adjust rows and columns as needed



% 2. Plot your data in different tiles
nexttile;
b1 = bar(y1, 'FaceColor', 'flat');
for k = 1:size(y1,2)
    b1(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'Case 1','Case 2', 'Case 3'});
ylabel('Relative error, $\mathcal{E}_{1}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)


nexttile;
b2 = bar(y2, 'FaceColor','flat');
for k = 1:size(y2,2)
    b2(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'Case 1','Case 2', 'Case 3'});
ylabel('Relative error, $\mathcal{E}_{2}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



nexttile;
b3 = bar(y3, 'FaceColor','flat');
for k = 1:size(y3,2)
    b3(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'Case 1','Case 2', 'Case 3'});
ylabel('Relative error, $\mathcal{E}_{3}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



nexttile;
b4 = bar(y4, 'FaceColor','flat');
for k = 1:size(y4,2)
    b4(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'Case 1','Case 2', 'Case 3'});
ylabel('Relative error, $\mathcal{E}_{4}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



% 3. Create a single legend for all plots
hL = legend(b1, 'RM ($\mathcal{N}$ = 128)', 'HM ($\mathcal{N}$ = 14)', 'MHM ($\mathcal{N}$ = 14)', 'LM ($\mathcal{N}$ = 15)', 'MRM ($\mathcal{N}$ = 15)', 'ZOM, v=7 ($\mathcal{N}$ = 43)', 'FFNIM ($\mathcal{N}$ = 2187)', 'Four variate DRM, v=3, 5 ($\mathcal{N}$ = 1172, 13110)', 'Location', 'south','Orientation','horizontal','NumColumns',4,'Interpreter','latex'); % You can specify an initial location here
set(gca,'FontName','Arial','linewidth',1.1)

% 4. Move the legend to the right side using the Layout property
hL.Layout.Tile = 'south';
hL.ItemTokenSize = [11 11];


set(gcf,'position',[100,100,650,500])
str = 'Prob_4_BM';
savePDF(str)

