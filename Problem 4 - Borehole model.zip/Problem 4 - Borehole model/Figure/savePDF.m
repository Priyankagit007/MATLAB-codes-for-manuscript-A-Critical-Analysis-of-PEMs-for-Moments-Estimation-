%% Crop and save MatLAB figure as PDF
function savePDF(str)

h = gcf;
set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

path = 'C:\Users\priya\OneDrive\Desktop\MATLAB codes\Problem 4 - Borehole model\Figure\';
saveas(h,fullfile(path,[str,'.pdf'])) % saving fig in pdf



end