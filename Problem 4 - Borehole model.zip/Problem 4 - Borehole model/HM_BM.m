
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Borehole model

clear all
close all
clc




n         =      7;             % no. of input variables





%---------------------------lognormal------------------------------%

m_log    =      7.71;
s_log    =      1.0056*2;
v_log    =      s_log.^2;

m_norm   =      log(m_log.^2./sqrt(v_log + m_log.^2));
s_norm   =      sqrt(log(v_log./m_log.^2 + 1));

g_log    =      (exp(s_norm.^2) + 2) .* sqrt(exp(s_norm.^2) - 1);
G_log    =      exp(4*s_norm.^2) + 2*exp(3*s_norm.^2) + 3*exp(2*s_norm.^2) - 6 + 3;


%-----------------------uniform----------------------------%

a_uni    =      [63070,  990,  63.1,  700,  1120,  9855];
b_uni    =      [115600, 1110,  116,  820,  1680,  12045];

m_uni    =      (a_uni + b_uni)./2;
s_uni    =      sqrt(1/12 * (b_uni - a_uni).^2);
g_uni    =      zeros(1,6);
G_uni    =      repmat(-6/5 + 3, [1,6]);

a_uni    =      a_uni - m_uni * 0.4;
b_uni    =      b_uni + m_uni * 0.4;

m_uni    =      (a_uni + b_uni)./2;
s_uni    =      sqrt(1/12 * (b_uni - a_uni).^2);


%%%%%%%%%%%%%%%%%%%%%%%%

mu       =      [m_log, m_uni];
sigma    =      [s_log, s_uni];
gamma    =      [g_log, g_uni];
Gamma    =      [G_log, G_uni];






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cov      =     diag(sigma.^2);                 % covariance matrix        
rho      =     corrcov(cov);                   % corerlation matrix






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eigenvectors & Eigenvalues of correlation matrix

[eig_vec,eig_val]    =    eig(rho);         % eignvectors & eigenvalues

V                    =    eig_vec;          % eigenvectors
lambda               =    diag(eig_val);    % eigenvalues






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Diagonal matrix of standard deviations

sq_D  =  sqrt(cov);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples

samples  = [];
for i = 1:n
    
    xi_p     =   mu + (sqrt(n) * sq_D * V(:,i))';
    xi_m     =   mu - (sqrt(n) * sq_D * V(:,i))';
    
    samples  =   [samples; xi_p; xi_m];
    
end
samples;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L = size(samples,1);

y = [];
for i = 1:L
    
    x = samples(i,:);
    
    rw       =      0.1;
    num      =      2 * pi * x(2) .* (x(3) - x(5));
    deno     =      log(x(1)./rw) .* (1 + 2*x(6).*x(2)./(log(x(1)./rw) .* rw.^2 .* x(7)) + x(2)./x(4));

    f        =      num./deno;
    
    y = [y; f];
    
end
y;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    new_y = y.^i;
    
    mom = 0;
    for j = 1:n
        
        mom     = mom + lambda(j) * (new_y(2*j-1) + new_y(2*j))/2;
        
    end
    
    raw_mom = [raw_mom; mom/sum(lambda)];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

[mean_y, std_y, ske_y, kur_y]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 72.1021;
% std_mcs  = 15.4828;
% ske_mcs  = 0.3746;
% kur_mcs  = 2.8801;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
 
% mean_mcs = 75.2969;
% std_mcs  = 58.5024;
% ske_mcs  = 0.6612;
% kur_mcs  = 3.6711;
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Monte Carlo
  
mean_mcs = 82.0959;
std_mcs  = 118.5638;
ske_mcs  = 1.0653;
kur_mcs  = 5.9195;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

