
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Borehole model

clear all
close all
clc




n         =      7;             % no. of input variables
m         =      7;




%--------------------------- r ~ lognormal------------------------------%

m_log    =      7.71;                  % input mean
s_log    =      1.0056*2;              % input std. dev
v_log    =      s_log.^2;

m_norm   =      log(m_log.^2./sqrt(v_log + m_log.^2));     % input parameter-1
s_norm   =      sqrt(log(v_log./m_log.^2 + 1));            % input parameter-2


%-----------------------Tu, Hu, Tl, Hl, L, Kw, ~ uniform----------------------------%

a_uni    =      [63070,  990,  63.1,  700,  1120,  9855];
b_uni    =      [115600, 1110,  116,  820,  1680,  12045];

m_uni    =      (a_uni + b_uni)./2;
s_uni    =      sqrt(1/12 * (b_uni - a_uni).^2);

a_uni    =      a_uni - m_uni * 0.4;           % [a1, a2, a3, a4, a5, a6]
b_uni    =      b_uni + m_uni * 0.4;           % [b1, b2, b3, b4, b5, b6]

m_uni    =      (a_uni + b_uni)./2;                    % inputs mean
s_uni    =      sqrt(1/12 * (b_uni - a_uni).^2);       % inputs std. dev




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Distribution parameters 

p1     =     [m_norm(1), a_uni(1:end)];
p2     =     [s_norm(1), b_uni(1:end)];



%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu       =      [m_log, m_uni];
sigma    =      [s_log, s_uni];








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Points and weights for all r.v.s

u_i_j = [];
w_i_j = [];
for i = 1:n

%              H_m_z     =      @(z) 8*z.^3 - 12*z;                                  % Hermite polynomial of degree m = 3
%     H_m_z     =      @(z) 32*z.^5 - 160*z.^3 + 120*z;                     % Hermite polynomial of degree m = 5
    H_m_z     =      @(z) 128*z.^7 - 1344*z.^5 + 3360*z.^3 - 1680*z;                     % Hermite polynomial of degree m = 5
%         z_j       =      roots([8, 0, -12, 0]);                               % points z_i_1,...,z_i_m
%     z_j       =      roots([32, 0, -160, 0, 120, 0]);
    z_j       =      roots([128, 0, -1344, 0, 3360, 0, -1680, 0]);   
    u_j       =      sqrt(2) * z_j;                                       % points u_i_1,...,u_i_m

    u_i_j     =      [u_i_j, u_j];                                        % points [u_1_1, u_2_1, ..., u_n_1; ...;u_1_m, u_2_m,...,u_n_m]

%     H_m1_z    =      @(z) 4*z.^2 - 2;                                     % Hermite polynomial of degree m-1
%     H_m1_z    =      @(z) 16*z.^4 - 48*z.^2 + 12;                                     % Hermite polynomial of degree m-1
    H_m1_z    =      @(z) 64*z.^6 - 480*z.^4 + 720*z.^2 - 120;                                     % Hermite polynomial of degree m-1
    value     =      H_m1_z(z_j);                                         % value of hermite polynomial of degree m-1 at points z_i_j
    W_j       =      (2^(m-1) * prod(1:m) * sqrt(pi))./(m^2 * value.^2);  % Weights for z
    w_j       =      W_j/sqrt(pi);                                        % weights u_i_1,...,u_i_m

    w_i_j     =      [w_i_j, w_j];                                         % weights [u_1_1, u_2_1,...,u_n_1;...;u_1_m, u_2_m,...,u_n_m]

end
u_ij  =  u_i_j'             % m points for all i=1,2,...,n

% [u_1_1, u_1_2, ..., u_1_m]
% [u_2_1, u_2_2, ..., u_2_m]
% .
% .
% .
% [u_n_1, u_n_2, ..., u_n_m]

w_ij  =  w_i_j'             % m weights for all i=1,2,...,n

% [w_1_1, w_1_2, ..., w_1_m]
% [w_2_1, w_2_2, ..., w_2_m]
% .
% .
% .
% [w_n_1, w_n_2, ..., w_n_m]   







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% T inverse transformation on u_ij

Tinv_u_ij = [];
for i = 1:n

    if(i==1)

       T_inv_u   =   @(u) exp(p1(i) + p2(i) * u);  % inverse rosenblatt transformation for lognormal r.v.s

       sam       =   T_inv_u(u_ij(i,:));         % [Tinv(u_i_1), Tinv(u_i_2),...,Tinv(u_i_m)]

    else

        T_inv_u  =   @(u) p1(i) + (p2(i) - p1(i)) * normcdf(u);       % rosenblatt transformation for uniform r.v.s

        sam      =   T_inv_u(u_ij(i,:)); 

    end
        
       Tinv_u_ij =   [Tinv_u_ij; sam];
end
Tinv_u_ij                                       % m samples for all i=1,2,...,n

% [Tinv(u_1_1), Tinv(u_1_2),...,Tinv(u_1_m))]
% [Tinv(u_2_1), Tinv(u_2_2),...,Tinv(u_2_m))]
% .
% .
% .
% [Tinv(u_n_1), Tinv(u_n_2),...,Tinv(u_n_m))]






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function evaluations

f_ij = [];
for i = 1:n
    all_mean = mu;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Samples formation for each i

    sample = [];
    for j = 1:m
        all_mean(i) = Tinv_u_ij(i,j);
        sample      = [sample; all_mean];
    end
    sample;  

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Function evaluations for each i
    
    f_i = [];
    for j = 1:m

        x        =      sample(j,:);

        rw       =      0.1;
        num      =      2 * pi * x(2) .* (x(3) - x(5));
        deno     =      log(x(1)./rw) .* (1 + 2*x(6).*x(2)./(log(x(1)./rw) .* rw.^2 .* x(7)) + x(2)./x(4));

        f        =      num./deno;
    
        f_i      =      [f_i, f];
    end

    f_ij = [f_ij; f_i];

end
f_ij

% [f(Tinv(u_1_1), mu(2),...,mu(n)),   f(Tin(u_1_2), mu(2),...,mu(n)),..., f(Tinv(u_1_m), mu(2),...,mu(n))]
% [f(mu(1), Tinv(u_2_1),...,mu(n)),   f(mu(1), Tinv(u_2_2),...,mu(n)),..., f(mu(1),Tinv(u_2_m),...,mu(n))]
% .
% .
% .
% [f(mu(1), mu(2),...,Tinv(u_n_1)),   f(mu(1), mu(2),...,Tinv(u_n_2)),..., f(mu(1), mu(2),...,Tinv(u_n_m))]





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean for each i - mu_i

all_mu_i = [];
for i = 1:n

    weights     =   w_ij(i,:);
    fun_value   =   f_ij(i,:);

    mu_i        =   sum(weights .* fun_value);

    all_mu_i    =   [all_mu_i, mu_i];

end
all_mu_i;

% [mu_1, mu_2, mu_3, mu_4, mu_5, mu_6, mu_7, mu_8]





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function value at mean

rw       =      0.1;
num      =      2 * pi * mu(2) .* (mu(3) - mu(5));
deno     =      log(mu(1)./rw) .* (1 + 2*mu(6).*mu(2)./(log(mu(1)./rw) .* rw.^2 .* mu(7)) + mu(2)./mu(4));
f_mu     =      num./deno;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean of Y

mu_Y    =    sum(all_mu_i) - (n-1)*f_mu






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Variance %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% variance for each i - sigma_i^2

all_var_i = [];
for i = 1:n

    weights     =   w_ij(i,:);
    fun_value   =   f_ij(i,:);

    var_i       =   sum(weights .* (fun_value - all_mu_i(i)).^2);

    all_var_i   =   [all_var_i, var_i];

end
all_var_i;

% [var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8]

var_Y    =    sum(all_var_i);
std_Y    =    sqrt(var_Y)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Variance %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Skewness %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% third moment for each i 

all_ske_i = [];
for i = 1:n

    weights     =   w_ij(i,:);
    fun_value   =   f_ij(i,:);

    ske_i       =   sum(weights .* (fun_value - all_mu_i(i)).^3);

    all_ske_i   =   [all_ske_i, ske_i];

end
all_ske_i;

% [thirdmom_1, thirdmom_2, thirdmom_3, thirdmom_4, thirdmom_5, thirdmom_6, thirdmom_7, thirdmom_8]

ske_Y    =    sum(all_ske_i)/std_Y^3

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Skewness %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Kurtosis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% fourth moment for each i 

all_kur_i = [];
for i = 1:n

    weights     =   w_ij(i,:);
    fun_value   =   f_ij(i,:);

    ske_i       =   sum(weights .* (fun_value - all_mu_i(i)).^4);

    all_kur_i   =   [all_kur_i, ske_i];

end
all_kur_i;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% first summation

sum_1    =    sum(all_kur_i);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% second summation

sum_2 = 0;
for i = 1:n
    for j = 1:n
        if(j>i)
            sum_2 = sum_2 + 6 * all_var_i(i) * all_var_i(j);
        end
    end
end
sum_2;

kur_Y = (sum_1 + sum_2)/std_Y^4


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Kurtosis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[mu_Y, std_Y, ske_Y, kur_Y]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 72.1021;
std_mcs  = 15.4828;
ske_mcs  = 0.3746;
kur_mcs  = 2.8801;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
 
mean_mcs = 75.2969;
std_mcs  = 58.5024;
ske_mcs  = 0.6612;
kur_mcs  = 3.6711;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
  
mean_mcs = 82.0959;
std_mcs  = 118.5638;
ske_mcs  = 1.0653;
kur_mcs  = 5.9195;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mu_Y)/mean_mcs)*100;
err_std  = ((std_mcs - std_Y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_Y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_Y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

