
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Borehole model

clear all
close all
clc


N   =   10^7;


%---------------------------lognormal------------------------------%

m_log    =      7.71;
s_log    =      1.0056*2;
v_log    =      s_log.^2;

m_norm   =      log(m_log.^2./sqrt(v_log + m_log.^2));
s_norm   =      sqrt(log(v_log./m_log.^2 + 1));

x1        =      lognrnd(m_norm(1), s_norm(1), [N,1]); % r

%-----------------------uniform----------------------------%

a_uni    =      [63070,  990,  63.1,  700,  1120,  9855];
b_uni    =      [115600, 1110,  116,  820,  1680,  12045];

m_uni    =      (a_uni + b_uni)./2;
v_uni    =      (b_uni - a_uni).^2./12;

a_uni    =      a_uni - m_uni * 0.4;
b_uni    =      b_uni + m_uni * 0.4;

new_m    =      (a_uni + b_uni)./2;
new_v    =      (b_uni - a_uni).^2./12;

x2       =      unifrnd(a_uni(1), b_uni(1), [N,1]);
x3       =      unifrnd(a_uni(2), b_uni(2), [N,1]);
x4       =      unifrnd(a_uni(3), b_uni(3), [N,1]);
x5       =      unifrnd(a_uni(4), b_uni(4), [N,1]);
x6       =      unifrnd(a_uni(5), b_uni(5), [N,1]);
x7       =      unifrnd(a_uni(6), b_uni(6), [N,1]);

rw       =      0.1;
num      =      2 * pi * x2 .* (x3 - x5);
deno     =      log(x1./rw) .* (1 + 2*x6.*x2./(log(x1./rw) .* rw.^2 .* x7) + x2./x4);

f        =      num./deno;

mean_f   =      mean(f)
std_f    =      std(f)
skew_f   =      skewness(f)
kur_f    =      kurtosis(f)



%histogram(f,80,'Normalization','pdf')
%[h, stats] = cdfplot(f)

% no  = f(f>0);          % no of terms greater than 2.2
% p_f = length(no)/N     % probability of failure

