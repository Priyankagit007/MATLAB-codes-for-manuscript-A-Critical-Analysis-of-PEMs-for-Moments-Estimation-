

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Borehole model

clear all
close all
clc




n         =      7;             % no. of input variables





%---------------------------lognormal------------------------------%

m_log    =      7.71;
s_log    =      1.0056*2;
v_log    =      s_log.^2;

m_norm   =      log(m_log.^2./sqrt(v_log + m_log.^2));
s_norm   =      sqrt(log(v_log./m_log.^2 + 1));

g_log    =      (exp(s_norm.^2) + 2) .* sqrt(exp(s_norm.^2) - 1);
G_log    =      exp(4*s_norm.^2) + 2*exp(3*s_norm.^2) + 3*exp(2*s_norm.^2) - 6 + 3;


%-----------------------uniform----------------------------%

a_uni    =      [63070,  990,  63.1,  700,  1120,  9855];
b_uni    =      [115600, 1110,  116,  820,  1680,  12045];

m_uni    =      (a_uni + b_uni)./2;
s_uni    =      sqrt(1/12 * (b_uni - a_uni).^2);
g_uni    =      zeros(1,6);
G_uni    =      repmat(-6/5 + 3, [1,6]);

a_uni    =      a_uni - m_uni * 0.4;
b_uni    =      b_uni + m_uni * 0.4;

m_uni    =      (a_uni + b_uni)./2;
s_uni    =      sqrt(1/12 * (b_uni - a_uni).^2);

%%%%%%%%%%%%%%%%%%%%%%%%

mu       =      [m_log, m_uni];
sigma    =      [s_log, s_uni];
gamma    =      [g_log, g_uni];
Gamma    =      [G_log, G_uni];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cov       =     diag(sigma.^2);         % independent







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Correlation matrix

rho       =     corrcov(cov);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha +-

alpha_p   =     (gamma  + sqrt(4 + gamma.^2))/2;
alpha_m   =     (-gamma + sqrt(4 + gamma.^2))/2;


alpha_pm  =     [alpha_p; alpha_m];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights +-

wp        =     alpha_m./(alpha_p + alpha_m);
wm        =     alpha_p./(alpha_p + alpha_m);

w_pm      =     [wp; wm];





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
beta      =     [1, -1];




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples


samples = [];
for i1 = 1:2
    sam1  =  mu(1) + beta(i1) * alpha_pm(i1,1) * sigma(1);
    
    for i2 = 1:2        
        sam2   =   mu(2) +  beta(i2) * alpha_pm(i2,2) * sigma(2);
        
        for i3 = 1:2            
            sam3   =   mu(3) +  beta(i3) * alpha_pm(i3,3) * sigma(3);
            
            for i4 = 1:2
                sam4      =    mu(4) +  beta(i4) * alpha_pm(i4,4) * sigma(4);

                for i5 = 1:2
                    sam5    =   mu(5)  +  beta(i5) * alpha_pm(i5,5) * sigma(5);

                    for i6 = 1:2
                        sam6    =    mu(6)  +  beta(i6) * alpha_pm(i6,6) * sigma(6);

                        for i7 = 1:2
                            sam7   =   mu(7)  +  beta(i7) * alpha_pm(i7,7) * sigma(7);
            
                            samples   =   [samples; sam1, sam2, sam3, sam4, sam5, sam6, sam7];
                        end
                    end
                end
            end
        end        
    end    
end
samples;










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function Values

L_sam = size(samples,1);

y = [];
for i = 1:L_sam
    
    x = samples(i,:);
   
    rw       =      0.1;
    num      =      2 * pi * x(2) .* (x(3) - x(5));
    deno     =      log(x(1)./rw) .* (1 + 2*x(6).*x(2)./(log(x(1)./rw) .* rw.^2 .* x(7)) + x(2)./x(4));

    f        =      num./deno;
    
    y = [y; f];
    
end
y;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights

%-----------Uncorrelated weights--------------%
W1 = [];
for i1 = 1:2
    w1  =  w_pm(i1,1);
    
    for i2 = 1:2
        w2  =  w_pm(i2,2);
        
        for i3 = 1:2
            w3   =  w_pm(i3,3);
            
            for i4 = 1:2
                w4   =   w_pm(i4,4);

                for i5 = 1:2
                    w5  =  w_pm(i5,5);

                    for i6 = 1:2
                        w6   =  w_pm(i6,6);

                        for i7 = 1:2
                            w7  =  w_pm(i7,7);
            
                            w    =  w1 * w2 * w3 * w4 * w5 * w6 * w7;            
                            W1   =  [W1; w];
                        end
                    end
                end
            end
        end
    end
end
W1;





%---------------rho_ij------------------%
rho_ij = [];
for i = 1:n-1
    
    vec     =     rho(i,i+1:end);
    rho_ij  =     [rho_ij, vec];
    
end
rho_ij;




%--------------denominator--------------%
pr = 1;
for i = 1:n

    pr   =    pr * (1 + (gamma(i)/2)^2);
    
end
Deno = sqrt(pr);




%----------------a_ij---------------%
aij    =    (rho_ij/2^n) / Deno;





%--------------Correlated weights---------------%
all_sign = [];
for i1 = 1:2
    sign1 = beta(i1);
    for i2 = 1:2
        sign2 = beta(i2);
        for i3 = 1:2
            sign3 = beta(i3);
            for i4 = 1:2
                sign4 = beta(i4);
                for i5 = 1:2
                    sign5 = beta(i5);
                    for i6 = 1:2
                        sign6 = beta(i6);
                        for i7 = 1:2
                            sign7 = beta(i7);
                            all_sign  = [all_sign; sign1, sign2, sign3, sign4, sign5, sign6, sign7];
                        end
                    end
                end
            end
        end
    end
end
all_sign;




C     =  nchoosek([1:n],2);
b     =  nchoosek(n,2);



%-------------Product of two signs--------------%
prod_sign_aij = [];
for i = 1:2^n
    
    vec   =   all_sign(i,:);   
    
    sign_aij = [];
    for j = 1:b
        
        k          =    C(j,:);
        prod       =    vec(k(1)) * vec(k(2));        
        sign_aij   =    [sign_aij, prod];
        
    end
    
    prod_sign_aij  =    [prod_sign_aij; sign_aij];
    
end
prod_sign_aij;

W2       =  prod_sign_aij .* aij;


%--------------Final weights-------------------%
Weights  =  sum([W1, W2],2);    % columnwise sum








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    mom     = sum(Weights .* y.^i);
    raw_mom = [raw_mom; mom];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

[mean_y, std_y, ske_y, kur_y]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 72.1021;
std_mcs  = 15.4828;
ske_mcs  = 0.3746;
kur_mcs  = 2.8801;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
 
mean_mcs = 75.2969;
std_mcs  = 58.5024;
ske_mcs  = 0.6612;
kur_mcs  = 3.6711;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
  
mean_mcs = 82.0959;
std_mcs  = 118.5638;
ske_mcs  = 1.0653;
kur_mcs  = 5.9195;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

