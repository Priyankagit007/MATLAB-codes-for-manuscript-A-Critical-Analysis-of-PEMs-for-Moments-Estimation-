
% Rivet

clc
clear all
close all

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Evans method
% 
% EM_1 = [-0.0014    0.0147  540.8312   -0.0094];
% EM_2 = [0.0000   -0.0000    1.1708   -0.0000]*10^3;
% EM_3 = [-0.0048   -0.0398  968.1027    0.0054];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FFNI method

FFNIM_1 = [-0.0014    0.0147   25.8909   -0.0118];
FFNIM_2 = [0.0068   -0.0090  -27.3522   -0.0269];
FFNIM_3 = [-0.0048   -0.0398   28.6617   -0.0137];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Harr method

HM_1 = [-0.0015    0.0079 -344.0484   23.7696];
HM_2 = [0.0067   -0.0173 -839.6243  -45.9067];
HM_3 = [-0.0048   -0.0483 -579.6975   29.6109];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Li method

LM_1 = [-0.0000   -0.0001   -1.3563    0.0095]*10^3;
LM_2 = [0.0069   -0.0105 -942.6977   12.4314];
LM_3 = [-0.0004    0.1189  370.9926   15.3413];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified Harr method

MHM_1 = [-0.0014    0.0112 -390.4930    2.9611];
MHM_2 = [0.0067   -0.0173 -839.6243  -45.9067];
MHM_3 = [-0.0051   -0.0605 -445.7198   13.7596];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified Rosenblueth method

MRM_1 = [-0.0037   -0.0769 -949.2902   69.7787];
MRM_2 = [0.0000   -0.0000   -1.0453    0.0708]*10^3;
MRM_3 = [-0.0019    0.0645 -198.5683   71.8225];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Zhao and Ono method

ZOM_1 = [-0.0014    0.0126  116.0447   -0.0135];
ZOM_2 = [0.0069   -0.0112  203.4131   -0.0304];
ZOM_3 = [-0.0046   -0.0386  200.3321   -0.0171];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rosenblueth method

RM_1 = [-0.0013    0.0168   30.3203   60.7076];
RM_2 = [0.0069   -0.0021 -130.7263   58.3504];
RM_3 = [-0.0045   -0.0255 -113.6466   56.0452];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DRM

DRM_1 = [-0.0014    0.0147   25.8909   -0.0118];
DRM_2 = [0.0068   -0.0090  -27.3522   -0.0269];
DRM_3 = [-0.0048   -0.0398   28.6617   -0.0137];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MEan

y1 = abs([RM_1(1) HM_1(1) MHM_1(1) LM_1(1) MRM_1(1) ZOM_1(1) FFNIM_1(1) DRM_1(1);  RM_2(1) HM_2(1) MHM_2(1) LM_2(1) MRM_2(1) ZOM_2(1) FFNIM_2(1) DRM_2(1); RM_3(1) HM_3(1) MHM_3(1) LM_3(1) MRM_3(1) ZOM_3(1) FFNIM_3(1) DRM_3(1)]);
y2 = abs([RM_1(2) HM_1(2) MHM_1(2) LM_1(2) MRM_1(2) ZOM_1(2) FFNIM_1(2) DRM_1(2);  RM_2(2) HM_2(2) MHM_2(2) LM_2(2) MRM_2(2) ZOM_2(2) FFNIM_2(2) DRM_2(2); RM_3(2) HM_3(2) MHM_3(2) LM_3(2) MRM_3(2) ZOM_3(2) FFNIM_3(2) DRM_3(2)]);
y3 = abs([RM_1(3) HM_1(3) MHM_1(3) LM_1(3) MRM_1(3) ZOM_1(3) FFNIM_1(3) DRM_1(3);  RM_2(3) HM_2(3) MHM_2(3) LM_2(3) MRM_2(3) ZOM_2(3) FFNIM_2(3) DRM_2(3); RM_3(3) HM_3(3) MHM_3(3) LM_3(3) MRM_3(3) ZOM_3(3) FFNIM_3(3) DRM_3(3)]);
y4 = abs([RM_1(4) HM_1(4) MHM_1(4) LM_1(4) MRM_1(4) ZOM_1(4) FFNIM_1(4) DRM_1(4);  RM_2(4) HM_2(4) MHM_2(4) LM_2(4) MRM_2(4) ZOM_2(4) FFNIM_2(4) DRM_2(4); RM_3(4) HM_3(4) MHM_3(4) LM_3(4) MRM_3(4) ZOM_3(4) FFNIM_3(4) DRM_3(4)]);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

color_matrix = [
    % 0.0 0.5 0.5; 
    0.0 0.8 0.8; 
    0.5 0.5 0.0;
    0.8 0.8 0.0; 
    0.9 0.54 0.0; 
    0.40 0.40 0.70; 
    0.60 0.40 0.80;
    0.6 0.10 0.10; 
    1.0 0.30 0.30  
];

% 1. Create a tiled chart layout
figure;
tcl = tiledlayout(2,2); % Adjust rows and columns as needed



% 2. Plot your data in different tiles
nexttile;
b1 = bar(y1, 'FaceColor', 'flat');
for k = 1:size(y1,2)
    b1(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'$\rho = -0.5$','$\rho = 0$', '$\rho = 0.5$'}, 'TickLabelInterpreter','latex');
ylabel('Relative error, $\mathcal{E}_{1}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)


nexttile;
b2 = bar(y2, 'FaceColor','flat');
for k = 1:size(y2,2)
    b2(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'$\rho = -0.5$','$\rho = 0$', '$\rho = 0.5$'}, 'TickLabelInterpreter','latex');
ylabel('Relative error, $\mathcal{E}_{2}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



nexttile;
b3 = bar(y3, 'FaceColor','flat');
for k = 1:size(y3,2)
    b3(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'$\rho = -0.5$','$\rho = 0$', '$\rho = 0.5$'}, 'TickLabelInterpreter','latex');
ylabel('Relative error, $\mathcal{E}_{3}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



nexttile;
b4 = bar(y4, 'FaceColor','flat');
for k = 1:size(y4,2)
    b4(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'$\rho = -0.5$','$\rho = 0$', '$\rho = 0.5$'}, 'TickLabelInterpreter','latex');
ylabel('Relative error, $\mathcal{E}_{4}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



% 3. Create a single legend for all plots
hL = legend(b1, 'RM ($\mathcal{N}$ = 32)', 'HM ($\mathcal{N}$ = 10)', 'MHM ($\mathcal{N}$ = 10)', 'LM ($\mathcal{N}$ = 21)', 'MRM ($\mathcal{N}$ = 21)', 'ZOM, v=3 ($\mathcal{N}$ = 11)', 'FFNIM ($\mathcal{N}$ = 243)', 'Trivariate DRM, v=3 ($\mathcal{N}$ = 131)', 'Location', 'northwest','Orientation','horizontal','NumColumns',4,'Interpreter','latex'); % You can specify an initial location here
set(gca,'FontName','Arial','linewidth',1.1)

% 4. Move the legend to the right side using the Layout property
hL.Layout.Tile = 'south';
hL.ItemTokenSize = [18 18];

%hL.Position = [0.9 0.7 0.2 0.2];  % adjust manually

set(gcf,'position',[100,100,650,500])
str = 'Prob_1_Rivet';
savePDF(str)

