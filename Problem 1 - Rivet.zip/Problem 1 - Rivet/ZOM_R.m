
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Rivet

clear all
close all
clc

n         =     5;
m         =     3;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

%                  d     h    K       D0      t
mu       =      [5,    20,  547.2,  5.1,    5];
sigma    =      [0.05,  0.3, 5.472,  0.0102, 0.01];

rh       =      0.5;
rho_ij   =      [rh, 0, 0, 0, 0, 0, 0, rh, 0, 0];


cov = [];
for i = 1:n
    
    vec         =    rho_ij(1:n-i) .* sigma(i) .* sigma(i+1:end);   
    k           =    [zeros(1,i-1), sigma(i)^2, vec];
    cov         =    [cov; k];    
    L           =    length(vec);    
    rho_ij      =    rho_ij(L+1:end);
    
end
cov;

di             =   diag(cov);
upper          =   triu(cov,1);                  % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
cov            =   upper + diag(di) + lower;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Rosenblatt transformation

%------------lam_2-------------%
row = [];
for i = 1:2
    col = [];
    for j = 1:2
        entry = cov(i,j);
        col   = [col, entry];
    end
    row = [row; col];
end
lam_2 = row
%------------lam_2-------------%



%------------cofactors of lam_2------------%
% lam_21_2 = cofactor of lam21 in lam_2

i = 2;
j = 1;

M          =   lam_2;
M(i,:)     =   [];
M(:,j)     =   [];
lam_21_2   =   (-1)^(i+j) * det(M);

% lam_22_2 = cofactor of lam22 in lam_2

i = 2;
j = 2;

M          =   lam_2;
M(i,:)     =   [];
M(:,j)     =   [];
lam_22_2   =   (-1)^(i+j) * det(M);
%------------cofactors of lam_2------------%






%-------------lam_3-------------%
row = [];
for i = 1:3
    col = [];
    for j = 1:3
        entry = cov(i,j);
        col   = [col, entry];
    end
    row = [row; col];
end
lam_3 = row
%-------------lam_3-------------%



%------------cofactors of lam_3------------%
% lam_31_3 = cofactor of lam31 in lam_3

i = 3;
j = 1;

M          =   lam_3;
M(i,:)     =   [];
M(:,j)     =   [];
lam_31_3   =   (-1)^(i+j) * det(M);

% lam_32_3 = cofactor of lam32 in lam_3

i = 3;
j = 2;

M          =   lam_3;
M(i,:)     =   [];
M(:,j)     =   [];
lam_32_3   =   (-1)^(i+j) * det(M);

% lam_33_3 = cofactor of lam33 in lam_3

i = 3;
j = 3;

M          =   lam_3;
M(i,:)     =   [];
M(:,j)     =   [];
lam_33_3   =   (-1)^(i+j) * det(M);
%------------cofactors of lam_3------------%





%-------------lam_4-------------%
row = [];
for i = 1:4
    col = [];
    for j = 1:4
        entry = cov(i,j);
        col   = [col, entry];
    end
    row = [row; col];
end
lam_4 = row
%-------------lam_4-------------%




%------------cofactors of lam_4------------%
% lam_41_4 = cofactor of lam41 in lam_4

i = 4;
j = 1;

M          =   lam_4;
M(i,:)     =   [];
M(:,j)     =   [];
lam_41_4   =   (-1)^(i+j) * det(M);

% lam_42_4 = cofactor of lam42 in lam_4

i = 4;
j = 2;

M          =   lam_4;
M(i,:)     =   [];
M(:,j)     =   [];
lam_42_4   =   (-1)^(i+j) * det(M);

% lam_43_4 = cofactor of lam43 in lam_4

i = 4;
j = 3;

M          =   lam_4;
M(i,:)     =   [];
M(:,j)     =   [];
lam_43_4   =   (-1)^(i+j) * det(M);

% lam_44_4 = cofactor of lam44 in lam_4

i = 4;
j = 4;

M          =   lam_4;
M(i,:)     =   [];
M(:,j)     =   [];
lam_44_4   =   (-1)^(i+j) * det(M);
%------------cofactors of lam_4------------%





%-------------lam_5-------------%
row = [];
for i = 1:5
    col = [];
    for j = 1:5
        entry = cov(i,j);
        col   = [col, entry];
    end
    row = [row; col];
end
lam_5 = row
%-------------lam_5-------------%




%------------cofactors of lam_5------------%
% lam_51_5 = cofactor of lam51 in lam_5

i = 5;
j = 1;

M          =   lam_5;
M(i,:)     =   [];
M(:,j)     =   [];
lam_51_5   =   (-1)^(i+j) * det(M);

% lam_52_5 = cofactor of lam52 in lam_5

i = 5;
j = 2;

M          =   lam_5;
M(i,:)     =   [];
M(:,j)     =   [];
lam_52_5   =   (-1)^(i+j) * det(M);

% lam_53_5 = cofactor of lam53 in lam_5

i = 5;
j = 3;

M          =   lam_5;
M(i,:)     =   [];
M(:,j)     =   [];
lam_53_5   =   (-1)^(i+j) * det(M);

% lam_54_5 = cofactor of lam54 in lam_5

i = 5;
j = 4;

M          =   lam_5;
M(i,:)     =   [];
M(:,j)     =   [];
lam_54_5   =   (-1)^(i+j) * det(M);

% lam_55_5 = cofactor of lam55 in lam_5

i = 5;
j = 5;

M          =   lam_5;
M(i,:)     =   [];
M(:,j)     =   [];
lam_55_5   =   (-1)^(i+j) * det(M);
%------------cofactors of lam_5------------%









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Points and weights for all r.v.s

u_i_j = [];
w_i_j = [];
for i = 1:n

    H_m_z     =      @(z) 8*z.^3 - 12*z;                                  % Hermite polynomial of degree m = 3
%     H_m_z     =      @(z) 32*z.^5 - 160*z.^3 + 120*z;                     % Hermite polynomial of degree m = 5
    z_j       =      roots([8, 0, -12, 0]);                               % points z_i_1,...,z_i_m
%     z_j       =      roots([32, 0, -160, 0, 120, 0]);
    u_j       =      sqrt(2) * z_j;                                       % points u_i_1,...,u_i_m

    u_i_j     =      [u_i_j, u_j];                                        % points [u_1_1, u_2_1, ..., u_n_1; ...;u_1_m, u_2_m,...,u_n_m]

    H_m1_z    =      @(z) 4*z.^2 - 2;                                     % Hermite polynomial of degree m-1
%     H_m1_z    =      @(z) 16*z.^4 - 48*z.^2 + 12;                                     % Hermite polynomial of degree m-1
    value     =      H_m1_z(z_j);                                         % value of hermite polynomial of degree m-1 at points z_i_j
    W_j       =      (2^(m-1) * prod(1:m) * sqrt(pi))./(m^2 * value.^2);  % Weights for z
    w_j       =      W_j/sqrt(pi);                                        % weights u_i_1,...,u_i_m

    w_i_j     =      [w_i_j, w_j];                                        % weights [u_1_1, u_2_1,...,u_n_1;...;u_1_m, u_2_m,...,u_n_m]

end
u_ij  =  u_i_j'             % m points for all i=1,2,...,n

% [u_1_1, u_1_2, ..., u_1_m]
% [u_2_1, u_2_2, ..., u_2_m]
% .
% .
% .
% [u_n_1, u_n_2, ..., u_n_m]

w_ij  =  w_i_j'             % m weights for all i=1,2,...,n

% [w_1_1, w_1_2, ..., w_1_m]
% [w_2_1, w_2_2, ..., w_2_m]
% .
% .
% .
% [w_n_1, w_n_2, ..., w_n_m]   









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function evaluations

f_ij = [];
for i = 1:n
    all_mean = repmat(0,[1,n]);        % means of standard normal r.v.s u_i's

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Samples formation for each i

    sample = [];
    for j = 1:m
        all_mean(i) = u_ij(i,j);
        sample      = [sample; all_mean];
    end
    sample;
    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Function evaluations for each i
    
    f_i = [];
    for j = 1:m

        u     =     sample(j,:);

        B1    =     u(2) * sqrt(det(lam_2)/lam_22_2) - (lam_21_2/lam_22_2) * sigma(1) * u(1);
        B2    =     u(3) * sqrt(det(lam_3)/lam_33_3) - (lam_31_3/lam_33_3) * sigma(1) * u(1) - (lam_32_3/lam_33_3) * B1;
        B3    =     u(4) * sqrt(det(lam_4)/lam_44_4) - (lam_41_4/lam_44_4) * sigma(1) * u(1) - (lam_42_4/lam_44_4) * B1 - (lam_43_4/lam_44_4) * B2;
        B4    =     u(5) * sqrt(det(lam_5)/lam_55_5) - (lam_51_5/lam_55_5) * sigma(1) * u(1) - (lam_52_5/lam_55_5) * B1 - (lam_53_5/lam_55_5) * B2 - (lam_54_5/lam_55_5) * B3;

        n_SHE =     0.15;
        H     =     2.2;
        s_max =     (mu(3) + B2) .* (log( ((mu(1) + sigma(1) * u(1))^2 .* (mu(2) + B1) - (mu(4) + B3)^2 .* (mu(5) + B4)) ./ (2 * H .* (mu(1) + sigma(1) * u(1)).^2) )).^n_SHE;
        f     =     582 - s_max; 

        f_i   =      [f_i, f];
    end

    f_ij = [f_ij; f_i];

end
f_ij

% [f(u_1_1), 0,...,0),   f(u_1_2, 0,...,0),..., f(u_1_m, 0,...,0)]
% [f(0, u_2_1,...,0),   f(0, u_2_2,...,0),..., f(0, u_2_m,...,0)]
% .
% .
% .
% [f(0, 0,...,u_n_1),   f(0, 0,...,u_n_2),..., f(0, 0,...,u_n_m)]








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean for each i - mu_i

all_mu_i = [];
for i = 1:n

    weights     =   w_ij(i,:);
    fun_value   =   f_ij(i,:);

    mu_i        =   sum(weights .* fun_value);

    all_mu_i    =   [all_mu_i, mu_i];

end
all_mu_i;

% [mu_1, mu_2, mu_3, mu_4, mu_5, mu_6, mu_7, mu_8]





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function value at mean

umu         =     repmat(0, [1,n]);      % means of standard normal r.v.s u_i's

B1          =     umu(2) * sqrt(det(lam_2)/lam_22_2) - (lam_21_2/lam_22_2) * sigma(1) * umu(1);
B2          =     umu(3) * sqrt(det(lam_3)/det(lam_33_3)) - (lam_31_3/lam_33_3) * sigma(1) * umu(1) - (lam_32_3/lam_33_3) * B1;
B3          =     umu(4) * sqrt(det(lam_4)/lam_44_4) - (lam_41_4/lam_44_4) * sigma(1) * umu(1) - (lam_42_4/lam_44_4) * B1 - (lam_43_4/lam_44_4) * B2;
B4          =     umu(5) * sqrt(det(lam_5)/lam_55_5) - (lam_51_5/lam_55_5) * sigma(1) * umu(1) - (lam_52_5/lam_55_5) * B1 - (lam_53_5/lam_55_5) * B2 - (lam_54_5/lam_55_5) * B3;

n_SHE       =     0.15;
H           =     2.2;
s_max       =     (mu(3) + B2) .* (log( ((mu(1) + sigma(1) * umu(1))^2 .* (mu(2) + B1) - (mu(4) + B3)^2 .* (mu(5) + B4)) ./ (2 * H .* (mu(1) + sigma(1) * umu(1)).^2) )).^n_SHE;
f_mu        =     582 - s_max; 


    




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean of Y

mu_Y    =    sum(all_mu_i) - (n-1)*f_mu









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Variance %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% variance for each i - sigma_i^2

all_var_i = [];
for i = 1:n

    weights     =   w_ij(i,:);
    fun_value   =   f_ij(i,:);

    var_i       =   sum(weights .* (fun_value - all_mu_i(i)).^2);

    all_var_i   =   [all_var_i, var_i];

end
all_var_i;

% [var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8]

var_Y    =    sum(all_var_i);
std_Y    =    sqrt(var_Y)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Variance %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Skewness %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% third moment for each i 

all_ske_i = [];
for i = 1:n

    weights     =   w_ij(i,:);
    fun_value   =   f_ij(i,:);

    ske_i       =   sum(weights .* (fun_value - all_mu_i(i)).^3);

    all_ske_i   =   [all_ske_i, ske_i];

end
all_ske_i;

% [thirdmom_1, thirdmom_2, thirdmom_3, thirdmom_4, thirdmom_5, thirdmom_6, thirdmom_7, thirdmom_8]

ske_Y    =    sum(all_ske_i)/std_Y^3

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Skewness %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Kurtosis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% fourth moment for each i 

all_kur_i = [];
for i = 1:n

    weights     =   w_ij(i,:);
    fun_value   =   f_ij(i,:);

    ske_i       =   sum(weights .* (fun_value - all_mu_i(i)).^4);

    all_kur_i   =   [all_kur_i, ske_i];

end
all_kur_i;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% first summation

sum_1    =    sum(all_kur_i);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% second summation

sum_2 = 0;
for i = 1:n
    for j = 1:n
        if(j>i)
            sum_2 = sum_2 + 6 * all_var_i(i) * all_var_i(j);
        end
    end
end
sum_2;

kur_Y = (sum_1 + sum_2)/std_Y^4


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Kurtosis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 18.7524;
% std_mcs  = 5.8177;
% ske_mcs  = -0.0026;
% kur_mcs  = 2.9996;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 18.7629;
% std_mcs  = 5.8286;
% ske_mcs  = -0.0015;
% kur_mcs  = 2.9991;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 18.7697;
std_mcs  = 5.8392;
ske_mcs  = -0.0024;
kur_mcs  = 2.9995;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mu_Y)/mean_mcs)*100;
err_std  = ((std_mcs - std_Y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_Y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_Y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

