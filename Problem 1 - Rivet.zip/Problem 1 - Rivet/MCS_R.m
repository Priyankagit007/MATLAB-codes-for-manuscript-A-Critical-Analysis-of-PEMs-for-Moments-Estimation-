

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Rivet

clear all
close all
clc

N        =      10^7;
n        =      5;

%                d     h    K       D0      t
mu       =      [5,    20,  547.2,  5.1,    5];
sigma    =      [0.05,  0.3, 5.472,  0.0102, 0.01];

rh       =      0.5;
rho_ij   =      [rh, 0, 0, 0, 0, 0, 0, rh, 0, 0];



cov = [];
for i = 1:n
    
    vec         =    rho_ij(1:n-i) .* sigma(i) .* sigma(i+1:end);   
    k           =    [zeros(1,i-1), sigma(i)^2, vec];
    cov         =    [cov; k];    
    L           =    length(vec);    
    rho_ij      =    rho_ij(L+1:end);
    
end
cov;

di             =   diag(cov);
upper          =   triu(cov,1);                  % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
cov            =   upper + diag(di) + lower;

x              =   mvnrnd(mu, cov, N);

d              =   x(:,1);
h              =   x(:,2);
K              =   x(:,3);
D0             =   x(:,4);
t              =   x(:,5);

n_SHE          =   0.15;
H              =   2.2;

s_max          =   K .* (log( (d.^2 .* h - D0.^2 .* t) ./ (2 * H .* d.^2) )).^n_SHE;

f              =   582 - s_max;

% f              =   (pi/4) * (d.^2 .* h - D0.^2 .* t)./(2 * H) .* s_max;

mean_f         =   mean(f)
std_f          =   std(f)
skew_f         =   skewness(f)
kur_f          =   kurtosis(f)
