
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Rivet

clear all
close all
clc

n         =     5;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

%                  d     h    K       D0      t
mu_c       =      [5,    20,  547.2,  5.1,    5];
sigma_c    =      [0.05,  0.3, 5.472,  0.0102, 0.01];
gamma_c    =      zeros(1,n);
Gamma_c    =      repmat(3,[1,n]);

rh       =      0.5;
rho_ij   =      [rh, 0, 0, 0, 0, 0, 0, rh, 0, 0];


cov = [];
for i = 1:n
    
    vec         =    rho_ij(1:n-i) .* sigma_c(i) .* sigma_c(i+1:end);   
    k           =    [zeros(1,i-1), sigma_c(i)^2, vec];
    cov         =    [cov; k];    
    L           =    length(vec);    
    rho_ij      =    rho_ij(L+1:end);
    
end
cov;

di             =   diag(cov);
upper          =   triu(cov,1);                  % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
cov            =   upper + diag(di) + lower;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Rosenblatt transformation

mu1  =  mu_c(1);
mu2  =  mu_c(2);
mu3  =  mu_c(3);
mu4  =  mu_c(4);
mu5  =  mu_c(5);

s1   =  sigma_c(1);
s2   =  sigma_c(2);
s3   =  sigma_c(3);
s4   =  sigma_c(4);
s5   =  sigma_c(5);

lam11  =  cov(1,1);
lam12  =  cov(1,2);
lam13  =  cov(1,3);
lam14  =  cov(1,4);
lam15  =  cov(1,5);

lam21  =  cov(2,1);
lam22  =  cov(2,2);
lam23  =  cov(2,3);
lam24  =  cov(2,4);
lam25  =  cov(2,5);

lam31  =  cov(3,1);
lam32  =  cov(3,2);
lam33  =  cov(3,3);
lam34  =  cov(3,4);
lam35  =  cov(3,5);

lam41  =  cov(4,1);
lam42  =  cov(4,2);
lam43  =  cov(4,3);
lam44  =  cov(4,4);
lam45  =  cov(4,5);

lam51  =  cov(5,1);
lam52  =  cov(5,2);
lam53  =  cov(5,3);
lam54  =  cov(5,4);
lam55  =  cov(5,5);


lam_2  =  [lam11, lam12;
           lam21, lam22];

lam_3  =  [lam11, lam12, lam13; 
           lam21, lam22, lam23; 
           lam31, lam32, lam33];

lam_4  =  [lam11, lam12, lam13, lam14; 
           lam21, lam22, lam23, lam24;
           lam31, lam32, lam33, lam34;
           lam41, lam42, lam43, lam44];

lam_5  =  [lam11, lam12, lam13, lam14, lam15;
           lam21, lam22, lam23, lam24, lam25;
           lam31, lam32, lam33, lam34, lam35;
           lam41, lam42, lam43, lam44, lam45;
           lam51, lam52, lam53, lam54, lam55];

lam_31_3    =      det([lam12, lam13; lam22, lam23]);
lam_32_3    =      -det([lam11, lam13; lam21, lam23]);
lam_33_3    =      det(lam_2);

lam_41_4    =      -det([lam12, lam13, lam14; lam22, lam23, lam24; lam32, lam33, lam34]);
lam_42_4    =       det([lam11, lam13, lam14; lam21, lam23, lam24; lam31, lam33, lam34]);
lam_43_4    =      -det([lam11, lam12, lam14; lam21, lam22, lam24; lam31, lam32, lam34]);
lam_44_4    =       det(lam_3);

lam_51_5    =       det([lam12, lam13, lam14, lam15; lam22, lam23, lam24, lam25; lam32, lam33, lam34, lam35; lam42, lam43, lam44, lam45]);
lam_52_5    =      -det([lam11, lam13, lam14, lam15; lam21, lam23, lam24, lam25; lam31, lam33, lam34, lam35; lam41, lam43, lam44, lam45]);
lam_53_5    =       det([lam11, lam12, lam14, lam15; lam21, lam22, lam24, lam25; lam31, lam32, lam34, lam35; lam41, lam42, lam44, lam45]);
lam_54_5    =      -det([lam11, lam12, lam13, lam15; lam21, lam22, lam23, lam25; lam31, lam32, lam33, lam35; lam41, lam42, lam43, lam45]);
lam_55_5    =       det(lam_4);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input statistical moments of independent r.v - Y1, Y2, ...

mu       =     zeros(1,n);
sigma    =     repmat(1,[1,n]);
gamma    =     zeros(1,n);
Gamma    =     repmat(3,[1,n]);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha 

alpha_1      =     (gamma - sqrt(4 * Gamma - 3 * gamma.^2))/2;
alpha_2      =     zeros(1, n);
alpha_3      =     (gamma + sqrt(4 * Gamma - 3 * gamma.^2))/2;


alpha_x1     =     [alpha_1(1), alpha_2(1), alpha_3(1)];
alpha_x2     =     [alpha_1(2), alpha_2(2), alpha_3(2)];
alpha_x3     =     [alpha_1(3), alpha_2(3), alpha_3(3)];
alpha_x4     =     [alpha_1(4), alpha_2(4), alpha_3(4)];
alpha_x5     =     [alpha_1(5), alpha_2(5), alpha_3(5)];








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights

w1   =   ((4 * Gamma - 3 * gamma.^2) + gamma .* sqrt(4 * Gamma - 3 * gamma.^2)) ./ (2 * (4 * Gamma - 3 * gamma.^2) .* (Gamma - gamma.^2));
w2   =   (Gamma - gamma.^2 - 1) ./ (Gamma - gamma.^2);
w3   =   ((4 * Gamma - 3 * gamma.^2) - gamma .* sqrt(4 * Gamma - 3 * gamma.^2)) ./ (2 * (4 * Gamma - 3 * gamma.^2) .* (Gamma - gamma.^2));


w_x1  =  [w1(1), w2(1), w3(1)];
w_x2  =  [w1(2), w2(2), w3(2)];
w_x3  =  [w1(3), w2(3), w3(3)];
w_x4  =  [w1(4), w2(4), w3(4)];
w_x5  =  [w1(5), w2(5), w3(5)];



w  =  [];
for i1 = 1:3    
    w_1 = w_x1(i1);    
    
    for i2 = 1:3       
        w_2 = w_x2(i2);       
        
        for i3 = 1:3            
            w_3 = w_x3(i3); 
            
            for i4 = 1:3
                w_4 = w_x4(i4);
                
                for i5 = 1:3
                    w_5 = w_x5(i5);                    
            
                    we   =  w_1 * w_2 * w_3 * w_4 * w_5;
                    w    =  [w; we];
                end
            end      
        end        
    end    
end
w;





 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples

samples  =  [];
for i1 = 1:3
    vec1 = mu(1) + alpha_x1(i1) * sigma(1);
    
    for i2 = 1:3        
        vec2 = mu(2) + alpha_x2(i2) * sigma(2);
        
        for i3 = 1:3
            vec3 = mu(3) + alpha_x3(i3) * sigma(3);
            
            for i4 = 1:3
                vec4 = mu(4) + alpha_x4(i4) * sigma(4);
                
                for i5 = 1:3
                    vec5 = mu(5) + alpha_x5(i5) * sigma(5);
                                       
                    s          =   [vec1,  vec2,  vec3, vec4, vec5];            
                    samples    =   [samples; s];
                end
            end           
        end        
    end    
end
samples;









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L = size(samples,1);

y = [];
for i = 1:L
    
    z           =     samples(i,:);   
    
    B1          =     z(2) * sqrt(det(lam_2)/lam11) + (lam12/lam11) * s1 * z(1);
    B2          =     z(3) * sqrt(det(lam_3)/det(lam_2)) - (lam_31_3/lam_33_3) * s1 * z(1) - (lam_32_3/lam_33_3) * B1;
    B3          =     z(4) * sqrt(det(lam_4)/det(lam_3)) - (lam_41_4/lam_44_4) * s1 * z(1) - (lam_42_4/lam_44_4) * B1 - (lam_43_4/lam_44_4) * B2;
    B4          =     z(5) * sqrt(det(lam_5)/det(lam_4)) - (lam_51_5/lam_55_5) * s1 * z(1) - (lam_52_5/lam_55_5) * B1 - (lam_53_5/lam_55_5) * B2 - (lam_54_5/lam_55_5) * B3;

    n_SHE   =   0.15;
    H       =   2.2;
    s_max   =   (mu3 + B2) .* (log( ((mu1 + s1 * z(1))^2 .* (mu2 + B1) - (mu4 + B3)^2 .* (mu5 + B4)) ./ (2 * H .* (mu1 + s1 * z(1)).^2) )).^n_SHE;
    f              =   582 - s_max;    
    y       =     [y; f];
    
end
y;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m  =  4;

raw_mom = [];
for i = 1:m
    
    mom     = sum(w .* y.^i);
    raw_mom = [raw_mom; mom];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
% 
% mean_mcs = 18.7524;
% std_mcs  = 5.8177;
% ske_mcs  = -0.0026;
% kur_mcs  = 2.9996;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 18.7629;
% std_mcs  = 5.8286;
% ske_mcs  = -0.0015;
% kur_mcs  = 2.9991;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 18.7697;
std_mcs  = 5.8392;
ske_mcs  = -0.0024;
kur_mcs  = 2.9995;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]
