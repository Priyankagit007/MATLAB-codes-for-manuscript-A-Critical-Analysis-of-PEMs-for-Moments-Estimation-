
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Rivet

clear all
close all
clc


%%%%%%%%%%%%%%%%%%%
% no of inputs

n       =    5;



%%%%%%%%%%%%%%%%%%%%%%%%%
% no of samples

N       =    3;




%%%%%%%%%%%%%%%%%%%%%%
% no of output moments

m       =    4;


%%%%%%%%%%%%%%%%%%%%
% s-variate

s       =    3;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

%                  d     h    K       D0      t
mu_c       =      [5,    20,  547.2,  5.1,    5];
sigma_c    =      [0.05,  0.3, 5.472,  0.0102, 0.01];

rh       =      0.5;
rho_ij   =      [rh, 0, 0, 0, 0, 0, 0, rh, 0, 0];

cov = [];
for i = 1:n
    
    vec         =    rho_ij(1:n-i) .* sigma_c(i) .* sigma_c(i+1:end);   
    k           =    [zeros(1,i-1), sigma_c(i)^2, vec];
    cov         =    [cov; k];    
    L           =    length(vec);    
    rho_ij      =    rho_ij(L+1:end);
    
end
cov;

di             =   diag(cov);
upper          =   triu(cov,1);                  % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
cov            =   upper + diag(di) + lower;
  





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Rosenblatt transformation

mu1  =  mu_c(1);
mu2  =  mu_c(2);
mu3  =  mu_c(3);
mu4  =  mu_c(4);
mu5  =  mu_c(5);


s1   =  sigma_c(1);
s2   =  sigma_c(2);
s3   =  sigma_c(3);
s4   =  sigma_c(4);
s5   =  sigma_c(5);


lam11  =  cov(1,1);
lam12  =  cov(1,2);
lam13  =  cov(1,3);
lam14  =  cov(1,4);
lam15  =  cov(1,5);

lam21  =  cov(2,1);
lam22  =  cov(2,2);
lam23  =  cov(2,3);
lam24  =  cov(2,4);
lam25  =  cov(2,5);


lam31  =  cov(3,1);
lam32  =  cov(3,2);
lam33  =  cov(3,3);
lam34  =  cov(3,4);
lam35  =  cov(3,5);


lam41  =  cov(4,1);
lam42  =  cov(4,2);
lam43  =  cov(4,3);
lam44  =  cov(4,4);
lam45  =  cov(4,5);


lam51  =  cov(5,1);
lam52  =  cov(5,2);
lam53  =  cov(5,3);
lam54  =  cov(5,4);
lam55  =  cov(5,5);

lam_2  =  [lam11, lam12;
           lam21, lam22];

lam_3  =  [lam11, lam12, lam13; 
           lam21, lam22, lam23; 
           lam31, lam32, lam33];

lam_4  =  [lam11, lam12, lam13, lam14; 
           lam21, lam22, lam23, lam24;
           lam31, lam32, lam33, lam34;
           lam41, lam42, lam43, lam44];

lam_5  =  [lam11, lam12, lam13, lam14, lam15;
           lam21, lam22, lam23, lam24, lam25;
           lam31, lam32, lam33, lam34, lam35;
           lam41, lam42, lam43, lam44, lam45;
           lam51, lam52, lam53, lam54, lam55];

lam_31_3    =      det([lam12, lam13; lam22, lam23]);
lam_32_3    =      -det([lam11, lam13; lam21, lam23]);
lam_33_3    =      det(lam_2);

lam_41_4    =      -det([lam12, lam13, lam14; lam22, lam23, lam24; lam32, lam33, lam34]);
lam_42_4    =       det([lam11, lam13, lam14; lam21, lam23, lam24; lam31, lam33, lam34]);
lam_43_4    =      -det([lam11, lam12, lam14; lam21, lam22, lam24; lam31, lam32, lam34]);
lam_44_4    =       det(lam_3);

lam_51_5    =       det([lam12, lam13, lam14, lam15; lam22, lam23, lam24, lam25; lam32, lam33, lam34, lam35; lam42, lam43, lam44, lam45]);
lam_52_5    =      -det([lam11, lam13, lam14, lam15; lam21, lam23, lam24, lam25; lam31, lam33, lam34, lam35; lam41, lam43, lam44, lam45]);
lam_53_5    =       det([lam11, lam12, lam14, lam15; lam21, lam22, lam24, lam25; lam31, lam32, lam34, lam35; lam41, lam42, lam44, lam45]);
lam_54_5    =      -det([lam11, lam12, lam13, lam15; lam21, lam22, lam23, lam25; lam31, lam32, lam33, lam35; lam41, lam42, lam43, lam45]);
lam_55_5    =       det(lam_4);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input statistical moments of independent r.v - Y1, Y2, ...

mu       =     zeros(1,n);
sigma    =     repmat(1,[1,n]);










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% input moments mu_j,i for each x_j

syms muu sigmaa t

mgf   =   exp(muu * t + 0.5 * sigmaa^2 * t^2);

mom = [];
for i = 0:2*N-1
    
    di   =   diff(mgf, t, i);
    
    mo   =   vpa(subs(di, t, 0));
    
    mom  =   [mom; mo];
    
end
mom;


mu_0 = repmat(1,[1,n]);
mu_1 = mu;
mu_2 = mu.^2 + sigma.^2;
mu_3 = mu.^3 + 3 * mu .* sigma.^2;
mu_4 = mu.^4 + 6 * mu.^2 .* sigma.^2 + 3 * sigma.^4;
mu_5 = mu.^5 + 10 * mu.^3 .* sigma.^2 + 15 * mu .* sigma.^4;
mu_6 = mu.^6 + 15 * mu.^4 .* sigma.^2 + 45 * mu.^2 .* sigma.^4 + 15 * sigma.^6;
mu_7 = mu.^7 + 21 * mu.^5 .* sigma.^2 + 105 * mu.^3 .* sigma.^4 + 105 .* mu .* sigma.^6;
mu_8 = mu.^8 + 28 * mu.^6 .* sigma.^2 + 210 * mu.^4 .* sigma.^4 + 420 .* mu.^2 .* sigma.^6 + 105 * sigma.^8;
mu_9 = mu.^9 + 36 * mu.^7 .* sigma.^2 + 378 * mu.^5 .* sigma.^4 + 1260 * mu.^3 .* sigma.^6 + 945 * mu .* sigma.^8;

moments = [mu_0; mu_1; mu_2; mu_3; mu_4; mu_5; mu_6; mu_7; mu_8; mu_9];












%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights: w_j,i and Points: x_j,i

points  = [];
weights = [];

for j = 1:n                            % for each j = 1, 2, 3, ... , n
    
    moments_j   =   moments(:,j);      % moments of x_j = x1, x2,...
    
    
    
    
    
    
    
    %------------------------%
    % LHS matrix of moments
    
    LHS = [];    
    for i = 1:N
        
        vec     =   moments_j(i:N+i-1);
        
        
        row = [];        
        for k = 1:length(vec)
            
            row   =   [row, (-1)^(k-1) * vec(end-k+1)];
            
        end
        
        Row   =   row;        
        LHS   =   [LHS; Row];
        
            
    end    
    LHS;
    
    
    
    
    
    %------------------------------%
    % RHS column matrix of moments
    
    RHS    =    moments_j(N+1:2*N);
    
    
    
    
    
    
    
    %------------------------------%
    % r_j,1 ; r_j,2, r_j,3 ; ...
    
    r_j    =    linsolve(LHS, RHS);
    
    
    
    
    
    
    %-------------------------%
    % x_j,1 ; x_j,2 ; x_j,3  
    
    coeff = 1;    
    for k = 1:length(r_j)
        
        coeff    =   [coeff, (-1)^k * r_j(k)];
        
    end
    
    x_j    =   roots(coeff);    
    points = [points, x_j];
    
    
    
    
    %-----------------------------%
    % Denominators of each w_j,i
    
    deno = [];
    for i = 1:N
        
        pr   =   1;
        
        for k = 1:N
            if (k~=i)                
                pr    =    pr * (x_j(i) - x_j(k));
            end            
        end
        
        deno    =    [deno; pr];
        
    end
    deno;
    
    
    
    
    
    
    
    %--------------------------------------%
    % moments in numerator of each w_j,i
    
    num_mu  =  flip(moments_j(1:N))';
    
    for i = 1:length(num_mu)
        
        if (rem(i,2)==0)
            
            num_mu(i)   =   - num_mu(i);
            
        end
        
    end    
    num_mu;
    
    
    
    
    
    
    
    
    %----------------------------------%
    % q_j,ik in numerators of w_j,i
    
    q_ik = [];
    
    for i = 1:N
        
        
        
        q0  =  1;
        
        q   =  [];       
        for k = 1:N-1
            
            q_k   =   r_j(k) - x_j(i) * q0;
            q0    =   q_k;
            q     =   [q; q0];
            
        end
        
        
        
        
        q_ik   =   [q_ik, q];
        
    end
            
    num_q   =   [repmat(1, [1,N]); q_ik]';   
    
    
    
    
    
    
    
    
    
    
    %----------------------------%
    % numerator in w_j,i
    
    num   =   sum(num_mu .* num_q, 2);
    
    
    
    
    %---------------------------%
    % Weights w_j,i
    
    w_j       =   num./deno;
    
    weights   =   [weights, w_j];
        
end

points    =   points;
weights   =   weights;








for i = 1:s
    
    nCs(i) = nchoosek(n,i);
    
end
nCs;

max_nCs  =  max(nCs);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculating all expectations & their powers

all_exp = [];
for i = 1:s
    
    C = nchoosek([1:n], i);
    
    % E[Z(x1)],         E[Z(x2)],         E[Z(x3)]                             i = 1
    % E[Z(x1, x2)],     E[Z(x1, x3)],     E[Z(x2,x3)]                          i = 2
    % E[Z(x1, x2, x3)], E[Z(x1, x2, x4)], E[Z(x1, x3, x4)], E[Z(x2, x3, x4)]   i = 3
    
    
    
    
    
    
    %---------------------------------------------------------------------%
    Exp_j_m = [];
    
    for j = 1:length(C)
        
        vec = C(j,:);
        
        % i = 1
        % E[Z(x1)]  j = 1
        % E[Z(x2)]  j = 2
        % E[Z(x3)]  j = 3
        
        % i = 2
        % E[Z(x1, x2)]  j = 1
        % E[Z(x1, x3)]  j = 2
        % E[Z(x2, x3)]  j = 3
        
        % i = 3
        % E[Z(x1, x2, x3)]  j = 1
        % E[Z(x1, x2, x4)]  j = 1
        % E[Z(x1, x3, x4)]  j = 1
        % E[Z(x2, x3, x4)]  j = 1
        
        
        
        
        
        
        
        %--------Collection of weights & points---------%
        
        Ws   = [];
        x_js = [];
        for k = 1:length(vec)
            
            col         =     vec(k);
            
            wj_call     =     weights(:,col);            
            Ws          =     [Ws, wj_call];
            
            xj_call     =     points(:,col);
            x_js        =     [x_js, xj_call];
            
        end
        
        Ws;
        
        x_js;
        
        %--------Collection of weights & points---------%
        
        
        
        
        
        
        %------------------Product of weights--------------%
        prod_w   =   1;
        
        L        =   length(vec);

        for i1 = 1:L
            
            w_call   =   Ws(:,i1);
            
            
            
            
            new_w  = [];
            for i2 = 1:N                      % no. of quad points
                
                w          =   w_call(i2);
                
                
                rep_w      =   repmat(w, [N^(L-i1), 1]);
                
                new_w      =   [new_w; rep_w];
                
                rep_new_w  =   repmat(new_w, [N^(i1-1), 1]);
                 
            end
            
            rep_new_w;
            
            
            
            
            
            prod_w    =   prod_w .* rep_new_w;
            
        end
        final_w       =   prod_w;
        %------------------Product of weights--------------%
  
        
        
        
        
        
        
        
        
        
        %----------------------samples-----------------------%
        %-----------------------------------------%
        final_xj = [];
        for i1 = 1:length(vec)
            
            xj_call   =   x_js(:,i1);
            
            
            
            
            new_xj = [];
            for i2 = 1:N                     % no. of quad points
                
                xj          =   xj_call(i2);
                
                
                rep_xj      =   repmat(xj, [N^(L-i1), 1]);
                
                new_xj      =   [new_xj; rep_xj];
                
                rep_new_xj  =   repmat(new_xj, [N^(i1-1), 1]);
                 
            end
            
            
            
         
            final_xj = [final_xj, rep_new_xj];
                   
        end
        
        final_xj;
        %---------------------------------------%
        %--------------------------------------%
        L2       =     size(final_xj,1);
        
        sample   =     mu;
        
        samples = [];
        for i1 = 1:L2
            
            row_call           =     final_xj(i1,:);
            
            
            
            for i2 = 1:L
                
                position             =    vec(i2);
                
                entry_call           =    row_call(i2);
                
                sample(position)     =    entry_call;
                
            end
            
            
            
            samples = [samples; sample];
            
        end
        samples;       
        %-------------------------------------%
        %----------------------------samples----------------------%
        
        
        
        
        
        %----------------function----------------------%
        
        final_y = [];
        for k = 1:L2

            z           =     samples(k,:);
            
            B1          =     z(2) * sqrt(det(lam_2)/lam11) + (lam12/lam11) * s1 * z(1);
            B2          =     z(3) * sqrt(det(lam_3)/det(lam_2)) - (lam_31_3/lam_33_3) * s1 * z(1) - (lam_32_3/lam_33_3) * B1;
            B3          =     z(4) * sqrt(det(lam_4)/det(lam_3)) - (lam_41_4/lam_44_4) * s1 * z(1) - (lam_42_4/lam_44_4) * B1 - (lam_43_4/lam_44_4) * B2;
            B4          =     z(5) * sqrt(det(lam_5)/det(lam_4)) - (lam_51_5/lam_55_5) * s1 * z(1) - (lam_52_5/lam_55_5) * B1 - (lam_53_5/lam_55_5) * B2 - (lam_54_5/lam_55_5) * B3;


            n_SHE   =   0.15;
    
            H       =   2.2;
    
            s_max   =   (mu3 + B2) .* (log( ((mu1 + s1 * z(1))^2 .* (mu2 + B1) - (mu4 + B3)^2 .* (mu5 + B4)) ./ (2 * H .* (mu1 + s1 * z(1)).^2) )).^n_SHE;
    
            f              =   582 - s_max;       
            
            final_y     =     [final_y; f];
            
        end
        final_y;
        
        %----------------function----------------------%
        
        
        
        
        
        
        
        
        %-----------------Expectations ^ m------------------------%
        M = [1:m];
        
        Exp_1 = [];
        for k = 1:m
            
            Exp_j      =   sum(final_w .* final_y.^k);
            
            Exp_1      =   [Exp_1; Exp_j];
            
        end
        Exp_1;
        %-----------------Expectations ^ m------------------------%
        
        
        
        
        
        Exp_j_m = [Exp_j_m, Exp_1];
        
    end  %----- j
    Exp_j_m;
    %-----------------------------------------------------------------------%
    
    
     
        
    %----------collection of all exp---------------%
    if (s>1)
        no_col    =  max_nCs - nchoosek(n,i);
        zeromat   =  zeros(m, no_col);
        Exp_j_m   =  [Exp_j_m, zeromat];
    end

        
    all_exp         =  [all_exp; Exp_j_m];
    %----------collection of all exp---------------%
    
end %------ i
all_exp;

% E[Z(x1)],      E[Z(x2)],      E[Z(x3)]
% E[Z(x1)]^2,    E[Z(x2)]^2,    E[Z(x3)]^2

% E[Z(x1,x2)],   E[Z(x1,x3)],   E[Z(x2,x3)]
% E[Z(x1,x2)]^2, E[Z(x1,x3)]^2, E[Z(x2,x3)]^2








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Z(mu) = y(mu), y(mu)^2, ..., y(mu)^m

B1          =     mu(2) * sqrt(det(lam_2)/lam11) + (lam12/lam11) * s1 * mu(1);
B2          =     mu(3) * sqrt(det(lam_3)/det(lam_2)) - (lam_31_3/lam_33_3) * s1 * mu(1) - (lam_32_3/lam_33_3) * B1;
B3          =     mu(4) * sqrt(det(lam_4)/det(lam_3)) - (lam_41_4/lam_44_4) * s1 * mu(1) - (lam_42_4/lam_44_4) * B1 - (lam_43_4/lam_44_4) * B2;
B4          =     mu(5) * sqrt(det(lam_5)/det(lam_4)) - (lam_51_5/lam_55_5) * s1 * mu(1) - (lam_52_5/lam_55_5) * B1 - (lam_53_5/lam_55_5) * B2 - (lam_54_5/lam_55_5) * B3;

n_SHE   =   0.15;
H       =   2.2;
s_max   =   (mu3 + B2) .* (log( ((mu1 + s1 * mu(1))^2 .* (mu2 + B1) - (mu4 + B3)^2 .* (mu5 + B4)) ./ (2 * H .* (mu1 + s1 * mu(1)).^2) )).^n_SHE;
y_mean              =   582 - s_max;       
for i = 1:m
    
    z_mean(i)    =    y_mean^i;
    
end

z_mean  =  z_mean';








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Raw Moments of y(x)

raw_mom = [];
for i = 1:m
    
    
    Exp_2       =     all_exp(i:m:end,:);
    
    
    %--------------------------------------------%
    SUM = 0;
    for j = 0:s
        
        b       =    (-1)^j * nchoosek(n-s+j-1,j);
        
        if (j==s)
            
            E   =    z_mean(i);
            
        else
            
            E   =    sum(Exp_2(end-j,:));
            
        end
        
        SUM     =    SUM + (b*E);
        
    end
    %-------------------------------------------%
    
    
    
    raw_mom        =  [raw_mom; SUM];
        
    
end
raw_mom;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Central moments of y(x)

mean_y = raw_mom(1)

var_y  = raw_mom(2) - mean_y^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 18.7524;
% std_mcs  = 5.8177;
% ske_mcs  = -0.0026;
% kur_mcs  = 2.9996;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 18.7629;
% std_mcs  = 5.8286;
% ske_mcs  = -0.0015;
% kur_mcs  = 2.9991;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 18.7697;
std_mcs  = 5.8392;
ske_mcs  = -0.0024;
kur_mcs  = 2.9995;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

