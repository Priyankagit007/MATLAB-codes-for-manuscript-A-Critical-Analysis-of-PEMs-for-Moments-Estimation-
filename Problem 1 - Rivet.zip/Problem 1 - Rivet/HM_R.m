
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Rivet

clear all
close all
clc

n     =  5;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

%                d     h    K       D0      t
mu       =      [5,    20,  547.2,  5.1,    5];
sigma    =      [0.05,  0.3, 5.472,  0.0102, 0.01];
gamma    =      zeros(1,n);

rh       =      0.5;
rho_ij   =      [rh, 0, 0, 0, 0, 0, 0, rh, 0, 0];

cov = [];
for i = 1:n
    
    vec         =    rho_ij(1:n-i) .* sigma(i) .* sigma(i+1:end);   
    k           =    [zeros(1,i-1), sigma(i)^2, vec];
    cov         =    [cov; k];    
    L           =    length(vec);    
    rho_ij      =    rho_ij(L+1:end);
    
end
cov;

di             =   diag(cov);
upper          =   triu(cov,1);                  % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
cov            =   upper + diag(di) + lower;

rho            =   corrcov(cov);                   % corerlation matrix






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eigenvectors & Eigenvalues of correlation matrix

[eig_vec,eig_val]    =    eig(rho);         % eignvectors & eigenvalues

V                    =    eig_vec;          % eigenvectors
lambda               =    diag(eig_val);    % eigenvalues





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Diagonal matrix of standard deviations

sq_D  =  diag(sigma);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples

samples  = [];
for i = 1:n
    
    xi_p     =   mu + sqrt(n) * (sq_D * V(:,i))';
    xi_m     =   mu - sqrt(n) * (sq_D * V(:,i))';
    
    samples  =   [samples; xi_p; xi_m];
    
end
samples;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L = size(samples,1);

y = [];
for i = 1:L
    
    x       =   samples(i,:);

    n_SHE   =   0.15;
    H       =   2.2;
    s_max   =   x(3) .* (log( (x(1).^2 .* x(2) - x(4).^2 .* x(5)) ./ (2 * H .* x(1).^2) )).^n_SHE;
    f              =   582 - s_max;    
    y       =   [y; f];
    
end
y;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    new_y = y.^i;
    
    mom = 0;
    for j = 1:n
        
        mom     = mom + lambda(j) * (new_y(2*j-1) + new_y(2*j))/2;
        
    end
    
    raw_mom = [raw_mom; mom/sum(lambda)];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 18.7524;
% std_mcs  = 5.8177;
% ske_mcs  = -0.0026;
% kur_mcs  = 2.9996;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 18.7629;
% std_mcs  = 5.8286;
% ske_mcs  = -0.0015;
% kur_mcs  = 2.9991;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 18.7697;
std_mcs  = 5.8392;
ske_mcs  = -0.0024;
kur_mcs  = 2.9995;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]
