
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Rivet

clear all
close all
clc

n         =    5;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

%                d     h    K       D0      t
mu       =      [5,    20,  547.2,  5.1,    5];
sigma    =      [0.05,  0.3, 5.472,  0.0102, 0.01];
gamma    =      zeros(1,n);
Gamma    =      repmat(3,[1,n]);

rh       =      -0.5;
rho_ij   =      [rh, 0, 0, 0, 0, 0, 0, rh, 0, 0];



cov = [];
for i = 1:n
    
    vec         =    rho_ij(1:n-i) .* sigma(i) .* sigma(i+1:end);   
    k           =    [zeros(1,i-1), sigma(i)^2, vec];
    cov         =    [cov; k];    
    L           =    length(vec);    
    rho_ij      =    rho_ij(L+1:end);
    
end
cov;

di             =   diag(cov);
upper          =   triu(cov,1);                  % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
cov            =   upper + diag(di) + lower;
  

rho       =      corrcov(cov);







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha +-

alpha_p   =    (gamma + sqrt(4 * Gamma - 3 * gamma.^2))/2;
alpha_m   =    (gamma - sqrt(4 * Gamma - 3 * gamma.^2))/2;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% weights +-

w_p       =    1./(alpha_p .* (alpha_p - alpha_m));
w_m       =    1./(alpha_m .* (alpha_m - alpha_p));
w0        =    1 - w_p - w_m;










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% samples  

%----------------samples xi--------------------%
e  =  eye(n,n);

sam_1 = [];
for i = 1:n
    
    xi_p    =    mu + alpha_p .* sigma .* e(i,:);
    xi_m    =    mu + alpha_m .* sigma .* e(i,:);
    
    sam_1   =    [sam_1; xi_p; xi_m];
    
end
sam_1;




%------------------samples (xi,xj)------------------%
b  =  nchoosek(n,2);
C  =  nchoosek([1:n],2);


sam_2 = [];
for i = 1:b
    
    k           =   C(i,:);    
    xi_p_xj_p   =   mu + alpha_p .* sigma .* e(k(1),:) + alpha_p .* sigma .* e(k(2),:);    
    sam_2       =   [sam_2; xi_p_xj_p];
    
end
sam_2;

samples  =  [mu; sam_1; sam_2];









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L = size(samples,1);

y = [];
for i = 1:L
    
    x = samples(i,:);

    n_SHE   =   0.15;
    H       =   2.2;
    s_max   =   x(3) .* (log( (x(1).^2 .* x(2) - x(4).^2 .* x(5)) ./ (2 * H .* x(1).^2) )).^n_SHE;
    f              =   582 - s_max;    
    y = [y; f];
    
end
y;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Delta

rho_ij = [];
for i = 1:n-1
    
    row     =   rho(i,i+1:end);    
    rho_ij  =   [rho_ij, row];
    
end
rho_ij;



alpha_ij = [];
for i = 1:b
    
    row       =   C(i,:);    
    v         =   alpha_p(row(1)) * alpha_p(row(2));    
    alpha_ij  =   [alpha_ij, v];
    
end
alpha_ij;



delta_ij  =   rho_ij./alpha_ij;
Wpp       =   delta_ij;



del_matrix = [];
for i = 1:n
    
    vec         =    delta_ij(1:n-i);    
    k           =    [zeros(1,i-1), 1, vec];
    del_matrix  =    [del_matrix; k];    
    L           =    length(vec);    
    delta_ij    =    delta_ij(L+1:end);
    
end
del_matrix;


upper          =   triu(del_matrix,1);           % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
del_matrix     =   upper + eye(n,n) + lower;


delta_i  =  sum(del_matrix, 2);
delta    =  sum(delta_i);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Final weights

W0  =  1 - 3*n/2 + delta/2 + sum(w0);

Wp  =  w_p - delta_i' + 1;

Wm  =  w_m;








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    new_y    =  y.^i;
          
    mom      =  W0 * new_y(1) + sum(Wp .* new_y(2:2:2*n+1)') + sum(Wm .* new_y(3:2:2*n+1)') + sum(Wpp .* new_y(2*n+2:end)');
        
    raw_mom  =  [raw_mom; mom];
        
end
raw_mom;       
        

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 18.7524;
std_mcs  = 5.8177;
ske_mcs  = -0.0026;
kur_mcs  = 2.9996;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
% 
% mean_mcs = 18.7629;
% std_mcs  = 5.8286;
% ske_mcs  = -0.0015;
% kur_mcs  = 2.9991;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 18.7697;
% std_mcs  = 5.8392;
% ske_mcs  = -0.0024;
% kur_mcs  = 2.9995;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]
