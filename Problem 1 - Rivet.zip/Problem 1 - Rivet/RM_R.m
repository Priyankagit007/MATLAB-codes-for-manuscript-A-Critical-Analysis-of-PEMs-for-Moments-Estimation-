
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Rivet

clear all
close all
clc

n         =    5;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

%                d     h    K       D0      t
mu       =      [5,    20,  547.2,  5.1,    5];
sigma    =      [0.05,  0.3, 5.472,  0.0102, 0.01];
gamma    =      zeros(1,n);
Gamma    =      repmat(3,[1,n]);

rh       =      0.5;
rho_ij   =      [rh, 0, 0, 0, 0, 0, 0, rh, 0, 0];

cov = [];
for i = 1:n
    
    vec         =    rho_ij(1:n-i) .* sigma(i) .* sigma(i+1:end);   
    k           =    [zeros(1,i-1), sigma(i)^2, vec];
    cov         =    [cov; k];    
    L           =    length(vec);    
    rho_ij      =    rho_ij(L+1:end);
    
end
cov;

di             =   diag(cov);
upper          =   triu(cov,1);                  % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
cov            =   upper + diag(di) + lower;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Correlation matrix

rho       =     corrcov(cov);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha +-

alpha_p   =     (gamma  + sqrt(4 + gamma.^2))/2;
alpha_m   =     (-gamma + sqrt(4 + gamma.^2))/2;


alpha_pm  =     [alpha_p; alpha_m];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights +-

wp        =     alpha_m./(alpha_p + alpha_m);
wm        =     alpha_p./(alpha_p + alpha_m);

w_pm      =     [wp; wm];





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
beta      =     [1, -1];




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples


samples = [];
for i1 = 1:2
    sam1 = mu(1) + beta(i1) * alpha_pm(i1,1) * sigma(1);
    
    for i2 = 1:2        
        sam2 = mu(2) +  beta(i2) * alpha_pm(i2,2) * sigma(2);
        
        for i3 = 1:2            
            sam3 = mu(3) +  beta(i3) * alpha_pm(i3,3) * sigma(3);
            
            for i4 = 1:2
                sam4 = mu(4) + beta(i4) * alpha_pm(i4,4) * sigma(4);
                
                for i5 = 1:2
                    sam5 = mu(5) + beta(i5) * alpha_pm(i5,5) * sigma(5);
                                        
                    samples   =   [samples; sam1, sam2, sam3, sam4, sam5];
                end
            end           
        end        
    end    
end
samples;










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function Values

L = size(samples,1);

y = [];
for i = 1:L
    
    x = samples(i,:);

    n_SHE   =   0.15;
    H       =   2.2;
    s_max   =   x(3) .* (log( (x(1).^2 .* x(2) - x(4).^2 .* x(5)) ./ (2 * H .* x(1).^2) )).^n_SHE;
    f              =   582 - s_max;    
    y = [y; f];
    
end
y;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights

%-----------Uncorrelated weights--------------%
W1 = [];
for i1 = 1:2
    w1 = w_pm(i1,1);
    
    for i2 = 1:2
        w2 = w_pm(i2,2);
        
        for i3 = 1:2
            w3 = w_pm(i3,3);
            
            for i4 = 1:2
                w4 = w_pm(i4,4);
                
                for i5 = 1:2
                    w5 = w_pm(i5,5);
                            
                    w    =  w1 * w2 * w3 * w4 * w5;            
                    W1   =  [W1; w];
                end
            end
        end
    end
end
W1;





%---------------rho_ij------------------%
rho_ij = [];
for i = 1:n-1
    
    vec     =     rho(i,i+1:end);
    rho_ij  =     [rho_ij, vec];
    
end
rho_ij;




%--------------denominator--------------%
pr = 1;
for i = 1:n

    pr   =    pr * (1 + (gamma(i)/2)^2);
    
end
Deno = sqrt(pr);




%----------------a_ij---------------%
aij    =    (rho_ij/2^n) / Deno;





%--------------Correlated weights---------------%
all_sign = [];
for i1 = 1:2
    sign1 = beta(i1);
    for i2 = 1:2
        sign2 = beta(i2);
        for i3 = 1:2
            sign3 = beta(i3);
            for i4 = 1:2
                sign4 = beta(i4);
                for i5 = 1:2
                    sign5 = beta(i5);            
                    all_sign  = [all_sign; sign1, sign2, sign3, sign4, sign5];
                end
            end
        end
    end
end
all_sign;




C     =  nchoosek([1:n],2);
b     =  nchoosek(n,2);



%-------------Product of two signs--------------%
prod_sign_aij = [];
for i = 1:2^n
    
    vec   =   all_sign(i,:);   
    
    sign_aij = [];
    for j = 1:b
        
        k          =    C(j,:);
        prod       =    vec(k(1)) * vec(k(2));        
        sign_aij   =    [sign_aij, prod];
        
    end
    
    prod_sign_aij  =    [prod_sign_aij; sign_aij];
    
end
prod_sign_aij;

W2       =  prod_sign_aij .* aij;


%--------------Final weights-------------------%
Weights  =  sum([W1, W2],2);    % columnwise sum








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    mom     = sum(Weights .* y.^i);
    raw_mom = [raw_mom; mom];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 18.7524;
% std_mcs  = 5.8177;
% ske_mcs  = -0.0026;
% kur_mcs  = 2.9996;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 18.7629;
% std_mcs  = 5.8286;
% ske_mcs  = -0.0015;
% kur_mcs  = 2.9991;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 18.7697;
std_mcs  = 5.8392;
ske_mcs  = -0.0024;
kur_mcs  = 2.9995;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

