
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Supported I-beam

clear all
close all
clc

n         =    8;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu        =      [6070, 120, 72, 170000, 2.3, 2.3, 0.16, 0.26];
sigma     =      [200, 6, 6, 4760, 1/24, 1/24, 1/48, 1/48]*2;
gamma     =      zeros(1, n);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cov       =      diag(sigma.^2);
rho       =      corrcov(cov);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha +-

alpha_p   =    (gamma  + sqrt(4 + gamma.^2))/2;
alpha_m   =    (-gamma + sqrt(4 + gamma.^2))/2;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% weights +-

w_p       =    alpha_m ./ (alpha_p + alpha_m);
w_m       =    alpha_p ./ (alpha_p + alpha_m);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% samples  

%---------------samples xi--------------------%
e  =  eye(n,n);

sam_1 = [];
for i = 1:n
    
    xi_p    =    mu + alpha_p .* sigma .* e(i,:);
    xi_m    =    mu - alpha_m .* sigma .* e(i,:);
    
    sam_1   =    [sam_1; xi_p; xi_m];
    
end
sam_1;



%---------------samples xi xj-----------------%
b  =  nchoosek(n,2);
C  =  nchoosek([1:n],2);


sam_2 = [];
for i = 1:b
    
    row         =   C(i,:);    
    xi_p_xj_p   =   mu + alpha_p .* sigma .* e(row(1),:) + alpha_p .* sigma .* e(row(2),:);    
    sam_2       =   [sam_2; xi_p_xj_p];
    
end
sam_2;

samples  =  [mu; sam_1; sam_2];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L_sam = size(samples,1);

y = [];
for i = 1:L_sam
    
    x = samples(i,:);
   
    P     =   x(1);
    L     =   x(2);
    a     =   x(3);
    S     =   x(4);
    d     =   x(5);
    bf    =   x(6);
    tw    =   x(7);
    tf    =   x(8);
    
    I     =   (bf .* d.^3 - (bf - tw) .* (d - 2 * tf).^3)/12;
    s_max =   P .* a .* (L - a) .* d ./ (2 * L .* I);
    f     =   s_max - S;
    
    y = [y; f];
    
end
y;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Delta

rho_ij = [];
for i = 1:n-1
    
    row     =   rho(i,i+1:end);    
    rho_ij  =   [rho_ij, row];
    
end
rho_ij;



alpha_ij = [];
for i = 1:b
    
    row       =   C(i,:);    
    v         =   alpha_p(row(1)) * alpha_p(row(2));    
    alpha_ij  =   [alpha_ij, v];
    
end
alpha_ij;


delta_ij  =   rho_ij./alpha_ij;
Wpp       =   delta_ij;



del_matrix = [];
for i = 1:n
    
    vec         =    delta_ij(1:n-i);    
    m           =    [zeros(1,i-1), 1, vec];    
    del_matrix  =    [del_matrix; m];    
    Lv          =    length(vec);    
    delta_ij    =    delta_ij(Lv+1:end);
    
end
del_matrix;


upper          =   triu(del_matrix,1);           % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
del_matrix     =   upper + eye(n,n) + lower;



delta_i  =  sum(del_matrix,2);
delta    =  sum(delta_i);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Final Weights

W0  =  1 - 3*n/2 + delta/2;

Wp  =  w_p - delta_i' + 1;

Wm  =  w_m;









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    new_y    =  y.^i;
          
    mom      =  W0 * new_y(1) + sum(Wp .* new_y(2:2:2*n+1)') + sum(Wm .* new_y(3:2:2*n+1)') + sum(Wpp .* new_y(2*n+2:end)');
        
    raw_mom  =  [raw_mom; mom];
        
end
raw_mom;       
        

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = -1.8765 * 10^4;
% std_mcs  = 8.7708 * 10^3;
% ske_mcs  = -0.0505;
% kur_mcs  = 3.0774;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = -1.9818 * 10^4;
% std_mcs  = 1.7921 * 10^4;
% ske_mcs  = -0.1141;
% kur_mcs  = 3.3377;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = -2.4128 * 10^4;
std_mcs  = 3.9098 * 10^4;
ske_mcs  = -0.3315;
kur_mcs  = 4.7322;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]
