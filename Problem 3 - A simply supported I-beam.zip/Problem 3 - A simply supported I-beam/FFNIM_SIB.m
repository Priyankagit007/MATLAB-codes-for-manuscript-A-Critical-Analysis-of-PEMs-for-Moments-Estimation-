
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Supported I-beam


clear all
close all
clc

n         =     8;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu        =      [6070, 120, 72, 170000, 2.3, 2.3, 0.16, 0.26];
sigma     =      [200, 6, 6, 4760, 1/24, 1/24, 1/48, 1/48]*2;
gamma     =      zeros(1, n);
Gamma     =      repmat(3, [1,n]);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha 

alpha_1      =     (gamma - sqrt(4 * Gamma - 3 * gamma.^2))/2;
alpha_2      =     zeros(1, n);
alpha_3      =     (gamma + sqrt(4 * Gamma - 3 * gamma.^2))/2;


alpha_x1     =     [alpha_1(1), alpha_2(1), alpha_3(1)];
alpha_x2     =     [alpha_1(2), alpha_2(2), alpha_3(2)];
alpha_x3     =     [alpha_1(3), alpha_2(3), alpha_3(3)];
alpha_x4     =     [alpha_1(4), alpha_2(4), alpha_3(4)];
alpha_x5     =     [alpha_1(5), alpha_2(5), alpha_3(5)];
alpha_x6     =     [alpha_1(6), alpha_2(6), alpha_3(6)];
alpha_x7     =     [alpha_1(7), alpha_2(7), alpha_3(7)];
alpha_x8     =     [alpha_1(8), alpha_2(8), alpha_3(8)];





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights

w1   =   ((4 * Gamma - 3 * gamma.^2) + gamma .* sqrt(4 * Gamma - 3 * gamma.^2)) ./ (2 * (4 * Gamma - 3 * gamma.^2) .* (Gamma - gamma.^2));
w2   =   (Gamma - gamma.^2 - 1) ./ (Gamma - gamma.^2);
w3   =   ((4 * Gamma - 3 * gamma.^2) - gamma .* sqrt(4 * Gamma - 3 * gamma.^2)) ./ (2 * (4 * Gamma - 3 * gamma.^2) .* (Gamma - gamma.^2));


w_x1  =  [w1(1), w2(1), w3(1)];
w_x2  =  [w1(2), w2(2), w3(2)];
w_x3  =  [w1(3), w2(3), w3(3)];
w_x4  =  [w1(4), w2(4), w3(4)];
w_x5  =  [w1(5), w2(5), w3(5)];
w_x6  =  [w1(6), w2(6), w3(6)];
w_x7  =  [w1(7), w2(7), w3(7)];
w_x8  =  [w1(8), w2(8), w3(8)];


w  =  [];
for i1 = 1:3    
    w_1   =   w_x1(i1);
    
    for i2 = 1:3        
        w_2    =    w_x2(i2);
        
        for i3 = 1:3            
            w_3    =   w_x3(i3);
            
            for i4 = 1:3
                w_4   =   w_x4(i4);

                for i5 = 1:3
                    w_5   =   w_x5(i5);

                    for i6 = 1:3
                        w_6   =   w_x6(i6);

                        for i7 = 1:3
                            w_7  =  w_x7(i7);

                            for i8 = 1:3
                                w_8  =  w_x8(i8);
            
                                we     =   w_1 * w_2 * w_3 * w_4 * w_5 * w_6 * w_7 * w_8;            
                                w      =   [w; we];
                            end
                        end

                    end
                end
            end            
        end        
    end    
end
w;






 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples

samples  =  [];
for i1 = 1:3    
    vec1   =   mu(1)  +  alpha_x1(i1) * sigma(1);
    
    for i2 = 1:3        
        vec2    =    mu(2)  +  alpha_x2(i2) * sigma(2);
        
        for i3 = 1:3            
            vec3   =   mu(3)   +   alpha_x3(i3) * sigma(3);
            
            for i4 = 1:3
                vec4       =  mu(4)   +  alpha_x4(i4) * sigma(4);

                for i5 = 1:3
                    vec5   =   mu(5)  +  alpha_x5(i5) * sigma(5);

                    for i6 = 1:3
                        vec6   =   mu(6)   +  alpha_x6(i6) * sigma(6);

                        for i7 = 1:3
                            vec7   =   mu(7)  +  alpha_x7(i7) * sigma(7);

                            for i8 = 1:3
                                vec8   =   mu(8)  +  alpha_x8(i8) * sigma(8);
            
                                s          =   [vec1,  vec2,  vec3, vec4, vec5, vec6, vec7, vec8];            
                                samples    =   [samples; s];
                            end
                        end
                    end
                end
            end
        end        
    end
end
samples;









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L_sam = size(samples,1);

y = [];
for i = 1:L_sam
    
    x = samples(i,:);
    
    P     =   x(1);
    L     =   x(2);
    a     =   x(3);
    S     =   x(4);
    d     =   x(5);
    bf    =   x(6);
    tw    =   x(7);
    tf    =   x(8);
    
    I     =   (bf .* d.^3 - (bf - tw) .* (d - 2 * tf).^3)/12;
    s_max =   P .* a .* (L - a) .* d ./ (2 * L .* I);
    f     =   s_max - S;
    
    y = [y; f];
    
end
y;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m  =  4;

raw_mom = [];
for i = 1:m
    
    mom     = sum(w .* y.^i);
    raw_mom = [raw_mom; mom];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = -1.8765 * 10^4;
% std_mcs  = 8.7708 * 10^3;
% ske_mcs  = -0.0505;
% kur_mcs  = 3.0774;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = -1.9818 * 10^4;
% std_mcs  = 1.7921 * 10^4;
% ske_mcs  = -0.1141;
% kur_mcs  = 3.3377;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = -2.4128 * 10^4;
std_mcs  = 3.9098 * 10^4;
ske_mcs  = -0.3315;
kur_mcs  = 4.7322;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]
