
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Supported I-beam


clear all
close all
clc

n      =  8;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu        =      [6070, 120, 72, 170000, 2.3, 2.3, 0.16, 0.26];
sigma     =      [200, 6, 6, 4760, 1/24, 1/24, 1/48, 1/48]*2;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cov      =     diag(sigma.^2);       
rho      =     corrcov(cov);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eigenvectors & Eigenvalues of correlation matrix

[eig_vec, eig_val]   =    eig(rho);

V                    =    eig_vec;         % eigenvectors
lambda               =    diag(eig_val);   % eigenvalues





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Root of diagonal matrix of eigenvalues

sq_Delta   =    sqrt(eig_val);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Root of diagonal matrix of standard deviations

sq_D       =    diag(sigma);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples

e   =   eye(n,n);

samples  = [];
for i = 1:n
    
    xi_p     =   mu + sqrt(n) * (sq_D * V(:,i))' * sq_Delta(i,i);
    xi_m     =   mu - sqrt(n) * (sq_D * V(:,i))' * sq_Delta(i,i);

    
    samples  =   [samples; xi_p; xi_m];
    
end
samples;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L_sam = size(samples,1);

y = [];
for i = 1:L_sam
    
    x = samples(i,:);
    
    P     =   x(1);
    L     =   x(2);
    a     =   x(3);
    S     =   x(4);
    d     =   x(5);
    bf    =   x(6);
    tw    =   x(7);
    tf    =   x(8);
    
    I     =   (bf .* d.^3 - (bf - tw) .* (d - 2 * tf).^3)/12;
    s_max =   P .* a .* (L - a) .* d ./ (2 * L .* I);
    f     =   s_max - S;
    
    y = [y; f];
    
end
y;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    new_y = y.^i;
    
    mom = 0;
    for j = 1:n
        
        mom     = mom + (new_y(2*j-1) + new_y(2*j))/2;
        
    end
    
    raw_mom = [raw_mom; mom/n];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = -1.8765 * 10^4;
% std_mcs  = 8.7708 * 10^3;
% ske_mcs  = -0.0505;
% kur_mcs  = 3.0774;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = -1.9818 * 10^4;
% std_mcs  = 1.7921 * 10^4;
% ske_mcs  = -0.1141;
% kur_mcs  = 3.3377;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = -2.4128 * 10^4;
std_mcs  = 3.9098 * 10^4;
ske_mcs  = -0.3315;
kur_mcs  = 4.7322;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]
