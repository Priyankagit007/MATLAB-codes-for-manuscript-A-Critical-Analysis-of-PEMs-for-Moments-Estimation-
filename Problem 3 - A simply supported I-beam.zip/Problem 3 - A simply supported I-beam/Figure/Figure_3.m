
% Supported I-beam

clear all
close all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Evans method

% EM_1 = [-0.0016    0.0090 -233.5360   -0.5495];
% EM_2 = [-0.0041    0.0341 -202.7833   -1.2612];
% EM_3 = [0.0005    0.4430 -123.6021    4.3783];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FFNI method

FFNIM_1 = [-0.0016    0.0080    3.4310    0.6538];
FFNIM_2 = [-0.0043    0.0189    4.2784    3.1009];
FFNIM_3 = [-0.0087    0.2004    7.1513   14.8450];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Harr method

HM_1 = [0.0061   -0.7066  -84.5191   30.0889];
HM_2 = [0.1167   -2.7495  -52.7638   29.7096];
HM_3 = [1.8170   -9.8141   28.8602   38.5266];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Li method

LM_1 = [0.0030    0.2315  177.5931   74.2738];
LM_2 = [0.0662    0.9189  167.6253   75.2269];
LM_3 = [0.9592    3.8867  144.3779   79.9079];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified Harr method

MHM_1 = [0.0061   -0.7066  -84.5191   30.0889];
MHM_2 = [0.1167   -2.7495  -52.7638   29.7096];
MHM_3 = [1.8170   -9.8141   28.8602   38.5266];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified Rosenblueth method

MRM_1 = [0.0017    0.6073  284.3413   91.3101];
MRM_2 = [0.0469    2.3916  262.6337   91.3125];
MRM_3 = [0.6832    9.3251  210.4510   92.0288];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Zhao and Ono method

ZOM_1 = [0.0030    0.2833   -5.4126    2.3420];
ZOM_2 = [0.0662    1.1229    9.5869    9.5124];
ZOM_3 = [0.9887    4.3986   40.4442   26.7734];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rosenblueth method

RM_1 = [-0.0029    0.3848  113.2148   19.6800];
RM_2 = [-0.0230    1.5086  109.9220   26.6992];
RM_3 = [-0.2530    5.9065  101.5397   50.2665];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DRM

DRM_1 = [-0.0016    0.0090    3.1885    0.0124];
DRM_2 = [-0.0041    0.0341    3.9130    0.8694];
DRM_3 = [0.0255    0.2139    2.8208   -0.9180];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MEan

y1 = abs([RM_1(1) HM_1(1) MHM_1(1) LM_1(1) MRM_1(1) ZOM_1(1) FFNIM_1(1) DRM_1(1);  RM_2(1) HM_2(1) MHM_2(1) LM_2(1) MRM_2(1) ZOM_2(1) FFNIM_2(1) DRM_2(1); RM_3(1) HM_3(1) MHM_3(1) LM_3(1) MRM_3(1) ZOM_3(1) FFNIM_3(1) DRM_3(1)]);
y2 = abs([RM_1(2) HM_1(2) MHM_1(2) LM_1(2) MRM_1(2) ZOM_1(2) FFNIM_1(2) DRM_1(2);  RM_2(2) HM_2(2) MHM_2(2) LM_2(2) MRM_2(2) ZOM_2(2) FFNIM_2(2) DRM_2(2); RM_3(2) HM_3(2) MHM_3(2) LM_3(2) MRM_3(2) ZOM_3(2) FFNIM_3(2) DRM_3(2)]);
y3 = abs([RM_1(3) HM_1(3) MHM_1(3) LM_1(3) MRM_1(3) ZOM_1(3) FFNIM_1(3) DRM_1(3);  RM_2(3) HM_2(3) MHM_2(3) LM_2(3) MRM_2(3) ZOM_2(3) FFNIM_2(3) DRM_2(3); RM_3(3) HM_3(3) MHM_3(3) LM_3(3) MRM_3(3) ZOM_3(3) FFNIM_3(3) DRM_3(3)]);
y4 = abs([RM_1(4) HM_1(4) MHM_1(4) LM_1(4) MRM_1(4) ZOM_1(4) FFNIM_1(4) DRM_1(4);  RM_2(4) HM_2(4) MHM_2(4) LM_2(4) MRM_2(4) ZOM_2(4) FFNIM_2(4) DRM_2(4); RM_3(4) HM_3(4) MHM_3(4) LM_3(4) MRM_3(4) ZOM_3(4) FFNIM_3(4) DRM_3(4)]);









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

color_matrix = [
    % 0.0 0.5 0.5; 
    0.0 0.8 0.8; 
    0.5 0.5 0.0;
    0.8 0.8 0.0; 
    0.9 0.54 0.0; 
    0.40 0.40 0.70; 
    0.60 0.40 0.80;
    0.6 0.10 0.10; 
    1.0 0.30 0.30  
];

% 1. Create a tiled chart layout
figure;
tcl = tiledlayout(2,2); % Adjust rows and columns as needed



% 2. Plot your data in different tiles
nexttile;
b1 = bar(y1, 'FaceColor', 'flat');
for k = 1:size(y1,2)
    b1(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'Case 1','Case 2', 'Case 3'});
ylabel('Relative error, $\mathcal{E}_{1}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)


nexttile;
b2 = bar(y2, 'FaceColor','flat');
for k = 1:size(y2,2)
    b2(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'Case 1','Case 2', 'Case 3'});
ylabel('Relative error, $\mathcal{E}_{2}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



nexttile;
b3 = bar(y3, 'FaceColor','flat');
for k = 1:size(y3,2)
    b3(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'Case 1','Case 2', 'Case 3'});
ylabel('Relative error, $\mathcal{E}_{3}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



nexttile;
b4 = bar(y4, 'FaceColor','flat');
for k = 1:size(y4,2)
    b4(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'Case 1','Case 2', 'Case 3'});
ylabel('Relative error, $\mathcal{E}_{4}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



% 3. Create a single legend for all plots
hL = legend(b1, 'RM ($\mathcal{N}$ = 256)', 'HM ($\mathcal{N}$ = 16)', 'MHM ($\mathcal{N}$ = 16)', 'LM ($\mathcal{N}$ = 17)', 'MRM ($\mathcal{N}$ = 17)', 'ZOM, v=3, 5 ($\mathcal{N}$ = 17, 33)', 'FFNIM ($\mathcal{N}$ = 6561)', 'Bivariate DRM, v=3, 4 ($\mathcal{N}$ = 129, 481)', 'Location', 'south','Orientation','horizontal','NumColumns',4,'Interpreter','latex'); % You can specify an initial location here
set(gca,'FontName','Arial','linewidth',1.1)

% 4. Move the legend to the right side using the Layout property
hL.Layout.Tile = 'south';
hL.ItemTokenSize = [12 12];


set(gcf,'position',[100,100,650,500])
str = 'Prob_3_supp_I_beam';
savePDF(str)

