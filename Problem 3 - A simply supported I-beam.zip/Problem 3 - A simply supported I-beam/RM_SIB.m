
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Supported I-beam

clear all
close all
clc

n         =     8;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu        =      [6070, 120, 72, 170000, 2.3, 2.3, 0.16, 0.26];
sigma     =      [200, 6, 6, 4760, 1/24, 1/24, 1/48, 1/48]*2;
gamma     =      zeros(1, n);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cov       =     diag(sigma.^2);         % independent







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Correlation matrix

rho       =     corrcov(cov);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha +-

alpha_p   =     (gamma  + sqrt(4 + gamma.^2))/2;
alpha_m   =     (-gamma + sqrt(4 + gamma.^2))/2;


alpha_pm  =     [alpha_p; alpha_m];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights +-

wp        =     alpha_m./(alpha_p + alpha_m);
wm        =     alpha_p./(alpha_p + alpha_m);

w_pm      =     [wp; wm];





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
beta      =     [1, -1];




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples


samples = [];
for i1 = 1:2
    sam1  =  mu(1) + beta(i1) * alpha_pm(i1,1) * sigma(1);
    
    for i2 = 1:2        
        sam2   =   mu(2) +  beta(i2) * alpha_pm(i2,2) * sigma(2);
        
        for i3 = 1:2            
            sam3   =   mu(3) +  beta(i3) * alpha_pm(i3,3) * sigma(3);
            
            for i4 = 1:2
                sam4      =    mu(4) +  beta(i4) * alpha_pm(i4,4) * sigma(4);

                for i5 = 1:2
                    sam5    =   mu(5)  +  beta(i5) * alpha_pm(i5,5) * sigma(5);

                    for i6 = 1:2
                        sam6    =    mu(6)  +  beta(i6) * alpha_pm(i6,6) * sigma(6);

                        for i7 = 1:2
                            sam7   =   mu(7)  +  beta(i7) * alpha_pm(i7,7) * sigma(7);

                            for i8 = 1:2
                                sam8   =   mu(8)  +  beta(i8) * alpha_pm(i8,8) * sigma(8);
            
                                samples   =   [samples; sam1, sam2, sam3, sam4, sam5, sam6, sam7, sam8];
                            end
                        end
                    end
                end
            end
        end        
    end    
end
samples;










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function Values

L_sam = size(samples,1);

y = [];
for i = 1:L_sam
    
    x = samples(i,:);
   
    P     =   x(1);
    L     =   x(2);
    a     =   x(3);
    S     =   x(4);
    d     =   x(5);
    bf    =   x(6);
    tw    =   x(7);
    tf    =   x(8);
    
    I     =   (bf .* d.^3 - (bf - tw) .* (d - 2 * tf).^3)/12;
    s_max =   P .* a .* (L - a) .* d ./ (2 * L .* I);
    f     =   s_max - S;  
    
    y = [y; f];
    
end
y;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights

%-----------Uncorrelated weights--------------%
W1 = [];
for i1 = 1:2
    w1  =  w_pm(i1,1);
    
    for i2 = 1:2
        w2  =  w_pm(i2,2);
        
        for i3 = 1:2
            w3   =  w_pm(i3,3);
            
            for i4 = 1:2
                w4   =   w_pm(i4,4);

                for i5 = 1:2
                    w5  =  w_pm(i5,5);

                    for i6 = 1:2
                        w6   =  w_pm(i6,6);

                        for i7 = 1:2
                            w7  =  w_pm(i7,7);

                            for i8 = 1:2
                                w8  =  w_pm(i8,8);
            
                                w    =  w1 * w2 * w3 * w4 * w5 * w6 * w7 * w8;            
                                W1   =  [W1; w];
                            end
                        end
                    end
                end
            end
        end
    end
end
W1;





%---------------rho_ij------------------%
rho_ij = [];
for i = 1:n-1
    
    vec     =     rho(i,i+1:end);
    rho_ij  =     [rho_ij, vec];
    
end
rho_ij;




%--------------denominator--------------%
pr = 1;
for i = 1:n

    pr   =    pr * (1 + (gamma(i)/2)^2);
    
end
Deno = sqrt(pr);




%----------------a_ij---------------%
aij    =    (rho_ij/2^n) / Deno;





%--------------Correlated weights---------------%
all_sign = [];
for i1 = 1:2
    sign1 = beta(i1);
    for i2 = 1:2
        sign2 = beta(i2);
        for i3 = 1:2
            sign3 = beta(i3);
            for i4 = 1:2
                sign4 = beta(i4);
                for i5 = 1:2
                    sign5 = beta(i5);
                    for i6 = 1:2
                        sign6 = beta(i6);
                        for i7 = 1:2
                            sign7 = beta(i7);
                            for i8 = 1:2
                                sign8 = beta(i8);
                                all_sign  = [all_sign; sign1, sign2, sign3, sign4, sign5, sign6, sign7, sign8];
                            end
                        end
                    end
                end
            end
        end
    end
end
all_sign;




C     =  nchoosek([1:n],2);
b     =  nchoosek(n,2);



%-------------Product of two signs--------------%
prod_sign_aij = [];
for i = 1:2^n
    
    vec   =   all_sign(i,:);   
    
    sign_aij = [];
    for j = 1:b
        
        k          =    C(j,:);
        prod       =    vec(k(1)) * vec(k(2));        
        sign_aij   =    [sign_aij, prod];
        
    end
    
    prod_sign_aij  =    [prod_sign_aij; sign_aij];
    
end
prod_sign_aij;

W2       =  prod_sign_aij .* aij;


%--------------Final weights-------------------%
Weights  =  sum([W1, W2],2);    % columnwise sum








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    mom     = sum(Weights .* y.^i);
    raw_mom = [raw_mom; mom];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = -1.8765 * 10^4;
% std_mcs  = 8.7708 * 10^3;
% ske_mcs  = -0.0505;
% kur_mcs  = 3.0774;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = -1.9818 * 10^4;
% std_mcs  = 1.7921 * 10^4;
% ske_mcs  = -0.1141;
% kur_mcs  = 3.3377;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = -2.4128 * 10^4;
std_mcs  = 3.9098 * 10^4;
ske_mcs  = -0.3315;
kur_mcs  = 4.7322;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]
