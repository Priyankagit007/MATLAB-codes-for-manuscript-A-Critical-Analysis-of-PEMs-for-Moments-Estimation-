
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Supported I-beam 

clear all
close all
clc


n        =      8;
N        =      10^7;

mu       =      [6070, 120, 72, 170000, 2.3, 2.3, 0.16, 0.26];
sigma    =      [200, 6, 6, 4760, 1/24, 1/24, 1/48, 1/48]/2;

P              =   normrnd(mu(1), sigma(1), [N,1]);
L              =   normrnd(mu(2), sigma(2), [N,1]);
a              =   normrnd(mu(3), sigma(3), [N,1]);
S              =   normrnd(mu(4), sigma(4), [N,1]);
d              =   normrnd(mu(5), sigma(5), [N,1]);
bf             =   normrnd(mu(6), sigma(6), [N,1]);
tw             =   normrnd(mu(7), sigma(7), [N,1]);
tf             =   normrnd(mu(8), sigma(8), [N,1]);

I              =   (bf .* d.^3 - (bf - tw) .* (d - 2 * tf).^3)/12;
s_max          =   P .* a .* (L - a) .* d ./ (2 * L .* I);
f              =   s_max - S;

mean_f         =   mean(f)
std_f          =   std(f)
skew_f         =   skewness(f)
kur_f          =   kurtosis(f)

