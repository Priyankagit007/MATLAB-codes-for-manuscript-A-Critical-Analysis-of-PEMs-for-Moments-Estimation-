%% Modified Li method (2002) normal distribution

clear all
close all
clc

%------------------------Grid discretization-------------------------%

L_min   =    0;
L_max   =    600;
delL    =    20;
I_L     =    (L_max - L_min)/delL;
L_b     =    L_min : delL : L_max; 
L_m     =    L_min+delL/2 : delL : L_max-delL/2;



W_min   =    0;
W_max   =    300;
delW    =    10;
I_W     =    (W_max - W_min)/delW;
W_b     =    W_min : delW : W_max;
W_m     =    W_min+delW/2 : delW : W_max-delW/2;

[L, W]        =      meshgrid(L_m, W_m);
%------------------------Grid discretization-------------------------%


n_I         =     6;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu        =    [35.83 1.11 76.94 1.25 exp(23.72) 0.036];
sigma     =    mu *5/100;

gamma     =    zeros(1,n_I);
cov       =    diag(sigma.^2);
rho       =    corrcov(cov);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha +-

alpha_p   =    (gamma  + sqrt(4 + gamma.^2))/2;
alpha_m   =    (-gamma + sqrt(4 + gamma.^2))/2;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% weights +-

w_p       =    alpha_m ./ (alpha_p + alpha_m);
w_m       =    alpha_p ./ (alpha_p + alpha_m);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% samples  

%---------------samples xi--------------------%
e  =  eye(n_I,n_I);

sam_1 = [];
for i = 1:n_I
    
    xi_p    =    mu + alpha_p .* sigma .* e(i,:);
    xi_m    =    mu - alpha_m .* sigma .* e(i,:);
    
    sam_1   =    [sam_1; xi_p; xi_m];
    
end
sam_1;



%---------------samples xi xj-----------------%
b  =  nchoosek(n_I,2);
C  =  nchoosek([1:n_I],2);


sam_2 = [];
for i = 1:b
    
    row         =   C(i,:);    
    xi_p_xj_p   =   mu + alpha_p .* sigma .* e(row(1),:) + alpha_p .* sigma .* e(row(2),:);    
    sam_2       =   [sam_2; xi_p_xj_p];
    
end
sam_2;

samples  =  [mu; sam_1; sam_2];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function Values

L_sam          =      size(samples,1);
tfinal         =      60;
delt           =      0.005;              % delta_t

tspan          =      [0 : delt : tfinal];
new_tspan      =      [0 : 1 : tfinal];




newMU43_W = [];
for k = 1:L_sam
    
    clc
    disp('Sample-->')
    disp(k)
    
    A1  = samples(k, 1);
    B1  = samples(k, 2);
    A2  = samples(k, 3);
    B2  = samples(k, 4);
    kJ1 = samples(k, 5);
    kJ2 = samples(k, 6);



    [MU43_W]     =    CR5(A1, B1, A2, B2, kJ1, kJ2, L, W, I_W, I_L, tfinal, delt, delL, delW, W_m);

    newMU43_W    =   [newMU43_W, MU43_W];
end

newMU43_W_UQ     =   newMU43_W(1 : 200 : end, :);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Delta

rho_ij = [];
for i = 1:n_I-1
    
    row     =   rho(i,i+1:end);    
    rho_ij  =   [rho_ij, row];
    
end
rho_ij;



alpha_ij = [];
for i = 1:b
    
    row       =   C(i,:);    
    v         =   alpha_p(row(1)) * alpha_p(row(2));    
    alpha_ij  =   [alpha_ij, v];
    
end
alpha_ij;


delta_ij  =   rho_ij./alpha_ij;
Wpp       =   delta_ij;



del_matrix = [];
for i = 1:n_I
    
    vec         =    delta_ij(1:n_I-i);    
    m           =    [zeros(1,i-1), 1, vec];    
    del_matrix  =    [del_matrix; m];    
    L           =    length(vec);    
    delta_ij    =    delta_ij(L+1:end);
    
end
del_matrix;


upper          =   triu(del_matrix,1);           % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
del_matrix     =   upper + eye(n_I,n_I) + lower;



delta_i  =  sum(del_matrix,2);
delta    =  sum(delta_i);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Final Weights

W0  =  1 - 3*n_I/2 + delta/2;

Wp  =  w_p - delta_i' + 1;

Wm  =  w_m;









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 2;

mean_W43 = [];
var_W43  = [];
std_W43  = [];
for j = 1:length(new_tspan)

    Y = newMU43_W_UQ(j,:);

    raw_mom = [];
    for i = 1:m
    
        new_Y    =  Y.^i;
          
        mom      =  W0 * new_Y(1) + sum(Wp .* new_Y(2:2:2*n_I+1)) + sum(Wm .* new_Y(3:2:2*n_I+1)) + sum(Wpp .* new_Y(2*n_I+2:end));
        
        raw_mom  =  [raw_mom; mom];
        
    end
    raw_mom;       
        

    mean_Y = raw_mom(1);
    var_Y  = raw_mom(2) - raw_mom(1)^2;
    std_Y    =   sqrt(var_Y);

    mean_W43 = [mean_W43; mean_Y];
    var_W43  = [var_W43;  var_Y];
    std_W43  = [std_W43;  std_Y];

end

mean_W43_end = mean_W43(end)
var_W43_end  = var_W43(end)
std_W43_end  = std_W43(end)




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

figure(1)

plot(new_tspan, mean_W43);
title('Modified Rosenblueth method');
xlabel('Time (min)');
ylabel('Mean (Particle Mean Width, \mum)');

figure(2)

plot(new_tspan, std_W43);
title("Modified Rosenblueth method");
ylabel('Time (min)');
ylabel('Standard deviation (Particle Mean Width, \mum)');

