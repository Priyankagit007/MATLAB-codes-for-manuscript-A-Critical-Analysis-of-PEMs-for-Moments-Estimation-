%% Modified Harr method (Chang et al. 1995) normal distribution

clear all
close all
clc

%------------------------Grid discretization-------------------------%

L_min   =    0;
L_max   =    600;
delL    =    20;
I_L     =    (L_max - L_min)/delL;
L_b     =    L_min : delL : L_max; 
L_m     =    L_min+delL/2 : delL : L_max-delL/2;



W_min   =    0;
W_max   =    300;
delW    =    10;
I_W     =    (W_max - W_min)/delW;
W_b     =    W_min : delW : W_max;
W_m     =    W_min+delW/2 : delW : W_max-delW/2;

[L, W]        =      meshgrid(L_m, W_m);
%------------------------Grid discretization-------------------------%


n_I         =     6;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu        =    [35.83 1.11 76.94 1.25 exp(23.72) 0.036];
sigma     =    mu * 5/100;

cov    =  diag(sigma.^2);       
rho    =  corrcov(cov);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eigenvectors & Eigenvalues of correlation matrix

[eig_vec, eig_val]   =    eig(rho);

V                    =    eig_vec;         % eigenvectors
lambda               =    diag(eig_val);   % eigenvalues





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Root of diagonal matrix of eigenvalues

sq_Delta   =    sqrt(eig_val);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Root of diagonal matrix of standard deviations

sq_D       =    diag(sigma);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples

e   =   eye(n_I,n_I);

samples  = [];
for i = 1:n_I
    
    xi_p     =   mu + sqrt(n_I) * (sq_D * V(:,i))' * sq_Delta(i,i);
    xi_m     =   mu - sqrt(n_I) * (sq_D * V(:,i))' * sq_Delta(i,i);

    
    samples  =   [samples; xi_p; xi_m];
    
end
samples;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function Values

L_sam          =      size(samples,1);
tfinal         =      60;
delt           =      0.005;              % delta_t

tspan          =      [0 : delt : tfinal];
new_tspan      =      [0 : 1 : tfinal];



newMU43_W = [];
for k = 1:L_sam
    
    clc
    disp('Sample-->')
    disp(k)
    
    A1  = samples(k, 1);
    B1  = samples(k, 2);
    A2  = samples(k, 3);
    B2  = samples(k, 4);
    kJ1 = samples(k, 5);
    kJ2 = samples(k, 6);



    [MU43_W]     =    CR5(A1, B1, A2, B2, kJ1, kJ2, L, W, I_W, I_L, tfinal, delt, delL, delW, W_m);

    newMU43_W    =   [newMU43_W, MU43_W];
end

newMU43_W_UQ     =   newMU43_W(1 : 200 : end, :);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 2;

mean_W43 = [];
var_W43  = [];
std_W43  = [];
for k = 1:length(new_tspan)

    Y = newMU43_W_UQ(k,:);


    raw_mom = [];
    for i = 1:m
    
        new_Y = Y.^i;
    
        mom = 0;
        for j = 1:n_I
        
            mom     = mom + (new_Y(2*j-1) + new_Y(2*j))/2;
        
        end
    
        raw_mom = [raw_mom; mom/n_I];
    
    end
    raw_mom;

    mean_Y = raw_mom(1);
    var_Y  = raw_mom(2) - raw_mom(1)^2;
    std_Y  = sqrt(var_Y);

    mean_W43 = [mean_W43; mean_Y];
    var_W43  = [var_W43;  var_Y];
    std_W43  = [std_W43;  std_Y];

end

mean_W43_end = mean_W43(end)
var_W43_end  = var_W43(end)
std_W43_end  = std_W43(end)




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

figure(1)

plot(new_tspan, mean_W43);
title('Modified Harr method');
xlabel('Time (min)');
ylabel('Mean (Particle Mean Width, \mum)');

figure(2)

plot(new_tspan, std_W43);
title("Modified Harr method");
ylabel('Time (min)');
ylabel('Standard deviation (Particle Mean Width, \mum)');


