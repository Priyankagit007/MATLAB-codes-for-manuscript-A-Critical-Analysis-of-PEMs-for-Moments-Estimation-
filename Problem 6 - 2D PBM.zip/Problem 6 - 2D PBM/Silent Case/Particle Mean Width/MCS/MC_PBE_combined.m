%% Experiment:- 0.5 C/min US = 50AMP

%% Monte Carlo


clc
clear all
close all



%------------------------Grid discretization-------------------------%

L_min   =    0;
L_max   =    600;
delL    =    20;
I_L     =    (L_max - L_min)/delL;
L_b     =    L_min : delL : L_max; 
L_m     =    L_min+delL/2 : delL : L_max-delL/2;



W_min   =    0;
W_max   =    300;
delW    =    10;
I_W     =    (W_max - W_min)/delW;
W_b     =    W_min : delW : W_max;
W_m     =    W_min+delW/2 : delW : W_max-delW/2;

[L, W]        =      meshgrid(L_m, W_m);
%------------------------Grid discretization-------------------------%




%--------------------------Parameter samples------------------------------%

N         =    10000;



m_A1      =    35.83;
m_B1      =    1.11;
m_A2      =    76.94;
m_B2      =    1.25;
m_kJ1     =    exp(23.72);
m_kJ2     =    0.036;



s_A1      =    m_A1 * 5/100;
s_B1      =    m_B1 * 5/100;
s_A2      =    m_A2 * 5/100;
s_B2      =    m_B2 * 5/100;
s_kJ1     =    m_kJ1 * 5/100;
s_kJ2     =    m_kJ2 * 5/100;


A1_sam    =    normrnd(m_A1,        s_A1,          [N,1]);
B1_sam    =    normrnd(m_B1,        s_B1,          [N,1]);
A2_sam    =    normrnd(m_A2,        s_A2,          [N,1]);
B2_sam    =    normrnd(m_B2,        s_B2,          [N,1]);
kJ1_sam   =    normrnd(m_kJ1,       s_kJ1,         [N,1]);      
kJ2_sam   =    normrnd(m_kJ2,       s_kJ2,         [N,1]);


%--------------------------Parameter samples------------------------------%








%------------------------concentration-------------------------%

tfinal         =      60;
delt           =      0.005;              % delta_t

tspan          =      [0 : delt : tfinal];
new_tspan      =      [0 : 1 : tfinal];





newMU43_W = [];
for k = 1:N
    
    clc
    disp('Sample-->')
    disp(k)
    
    A1  = A1_sam(k);
    B1  = B1_sam(k);
    A2  = A2_sam(k);
    B2  = B2_sam(k);
    kJ1 = kJ1_sam(k);
    kJ2 = kJ2_sam(k);


    [MU43_W]     =    CR5(A1, B1, A2, B2, kJ1, kJ2, L, W, I_W, I_L, tfinal, delt, delL, delW, W_m);

    newMU43_W    =   [newMU43_W, MU43_W];
end

newMU43_W_UQ     =   newMU43_W(1 : 200 : end, :);

%------------------------concentration-------------------------%



      





%---------------------------Uncertainty analysis--------------------------%
mean_W43  =  [];
var_W43   =  [];
std_W43   =  [];
Lower_W      =  [];
Upper_W      =  [];
for i = 1 : length(new_tspan)
    
    vec              =     newMU43_W_UQ(i,:);
    
    m_mu43_W         =     mean(vec);
    v_mu43_W         =     var(vec);
    s_mu43_W         =     std(vec);

    
    mean_W43         =    [mean_W43; m_mu43_W];
    var_W43          =    [var_W43;  v_mu43_W];
    std_W43          =    [std_W43;  s_mu43_W];
     
    lower_W          =    quantile(vec, 0.025);
    upper_W          =    quantile(vec, 0.975);
    
    Lower_W          =    [Lower_W; lower_W];
    Upper_W          =    [Upper_W; upper_W];
     
end
mean_W_end = mean_W43(end)
var_W_end  = var_W43(end)
std_W_end  = std_W43(end)

%---------------------------Uncertainty analysis--------------------------%










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

figure(1)

plot(new_tspan, mean_W43);
hold on
title('Monte Carlo method');
xlabel('Time (min)');
ylabel('Mean (Particle Mean Width, \mum)');

figure(2)

plot(new_tspan, std_W43);
hold on
title('Monte Carlo method');
xlabel('Time (min)');
ylabel('Standard deviation (Particle Mean Width, \mum)');



toc

disp(toc)





