%% Rosenblueth method (1975) (normal distribution)

clear all
close all
clc
%------------------------Grid discretization-------------------------%

L_min   =    0;
L_max   =    600;
delL    =    20;
I_L     =    (L_max - L_min)/delL;
L_b     =    L_min : delL : L_max; 
L_m     =    L_min+delL/2 : delL : L_max-delL/2;



W_min   =    0;
W_max   =    300;
delW    =    10;
I_W     =    (W_max - W_min)/delW;
W_b     =    W_min : delW : W_max;
W_m     =    W_min+delW/2 : delW : W_max-delW/2;

[L, W]        =      meshgrid(L_m, W_m);



%%%%%%%%%%%%%%%%%%%%%%
n_I         =     6;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu        =    [35.83 1.11 76.94 1.25 exp(23.72) 0.036];
sigma     =    mu * 5/ 100;

cov       =     diag(sigma.^2);         % independent
gamma     =     zeros(1,n_I);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Correlation matrix

rho       =     corrcov(cov);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha +-

alpha_p   =     (gamma  + sqrt(4 + gamma.^2))/2;
alpha_m   =     (-gamma + sqrt(4 + gamma.^2))/2;


alpha_pm  =     [alpha_p; alpha_m];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights +-

wp        =     alpha_m./(alpha_p + alpha_m);
wm        =     alpha_p./(alpha_p + alpha_m);

w_pm      =     [wp; wm];





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
beta      =     [1, -1];




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples


samples = [];
for i1 = 1:2
    sam1  =  mu(1) + beta(i1) * alpha_pm(i1,1) * sigma(1);
    
    for i2 = 1:2        
        sam2   =   mu(2) +  beta(i2) * alpha_pm(i2,2) * sigma(2);
        
        for i3 = 1:2            
            sam3   =   mu(3) +  beta(i3) * alpha_pm(i3,3) * sigma(3);

            for i4 = 1:2            
                sam4   =   mu(4) +  beta(i4) * alpha_pm(i4,4) * sigma(4);

                for i5 = 1:2            
                    sam5   =   mu(5) +  beta(i5) * alpha_pm(i5,5) * sigma(5);

                    for i6 = 1:2            
                        sam6   =   mu(6) +  beta(i6) * alpha_pm(i6,6) * sigma(6);
                        samples   =   [samples; sam1, sam2, sam3, sam4, sam5, sam6];
                    end
                end             
            end
        end        
    end    
end
samples;










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function Values

L_sam          =      size(samples,1);
tfinal         =      60;
delt           =      0.005;              % delta_t

tspan          =      [0 : delt : tfinal];
new_tspan      =      [0 : 1 : tfinal];



newMU43_W = [];
for k = 1:L_sam
    
    clc
    disp('Sample-->')
    disp(k)
    
    A1  = samples(k, 1);
    B1  = samples(k, 2);
    A2  = samples(k, 3);
    B2  = samples(k, 4);
    kJ1 = samples(k, 5);
    kJ2 = samples(k, 6);



    [MU43_W]     =    CR5(A1, B1, A2, B2, kJ1, kJ2, L, W, I_W, I_L, tfinal, delt, delL, delW, W_m);

    newMU43_W    =   [newMU43_W, MU43_W];
end

newMU43_W_UQ     =   newMU43_W(1 : 200 : end, :);









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights

%-----------Uncorrelated weights--------------%
W1 = [];
for i1 = 1:2
    w1  =  w_pm(i1,1);
    
    for i2 = 1:2
        w2  =  w_pm(i2,2);
        
        for i3 = 1:2
            w3   =  w_pm(i3,3);

            for i4 = 1:2
                w4   =  w_pm(i4,4);

                for i5 = 1:2
                    w5  =  w_pm(i5,5);

                    for i6 = 1:2
                        w6   =  w_pm(i6,6);
                        
                        w    =  w1 * w2 * w3 * w4 * w5 * w6 ;            
                        W1   =  [W1; w];
                    end
                end
            end
        end
    end
end
W1;





%---------------rho_ij------------------%
rho_ij = [];
for i = 1:n_I-1
    
    vec     =     rho(i,i+1:end);
    rho_ij  =     [rho_ij, vec];
    
end
rho_ij;




%--------------denominator--------------%
pr = 1;
for i = 1:n_I

    pr   =    pr * (1 + (gamma(i)/2)^2);
    
end
Deno = sqrt(pr);




%----------------a_ij---------------%
aij    =    (rho_ij/2^n_I) / Deno;





%--------------Correlated weights---------------%
all_sign = [];
for i1 = 1:2
    sign1 = beta(i1);
    for i2 = 1:2
        sign2 = beta(i2);
        for i3 = 1:2
            sign3 = beta(i3);
            for i4 = 1:2
                sign4 = beta(i4);
                for i5 = 1:2
                    sign5 = beta(i5);
                    for i6 = 1:2
                        sign6 = beta(i6);
                        all_sign  = [all_sign; sign1, sign2, sign3, sign4, sign5, sign6];
                    end
                end
            end
        end
    end
end
all_sign;




C     =  nchoosek([1:n_I],2);
b     =  nchoosek(n_I,2);



%-------------Product of two signs--------------%
prod_sign_aij = [];
for i = 1:2^n_I
    
    vec   =   all_sign(i,:);   
    
    sign_aij = [];
    for j = 1:b
        
        k          =    C(j,:);
        prod       =    vec(k(1)) * vec(k(2));        
        sign_aij   =    [sign_aij, prod];
        
    end
    
    prod_sign_aij  =    [prod_sign_aij; sign_aij];
    
end
prod_sign_aij;

W2       =  prod_sign_aij .* aij;


%--------------Final weights-------------------%

Weights  =  sum([W1, W2],2);    % columnwise sum







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 2;

mean_W43 = [];
var_W43  = [];
std_W43  = [];
for j = 1:length(new_tspan)

    Y = newMU43_W_UQ(j,:);

    raw_mom = [];
    for i = 1:m
    
        mom     = sum(Weights .* Y'.^i);
        raw_mom = [raw_mom; mom];
    
    end
    raw_mom;

    mean_Y = raw_mom(1);
    var_Y  = raw_mom(2) - raw_mom(1)^2;
    std_Y  = sqrt(var_Y);

    mean_W43 = [mean_W43; mean_Y];
    var_W43  = [var_W43;  var_Y];
    std_W43  = [std_W43;  std_Y];

end

mean_W43_end = mean_W43(end)
var_W43_end  = var_W43(end)
std_W43_end  = std_W43(end)




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

figure(1)

plot(new_tspan, mean_W43);
title('Rosenblueth method');
xlabel('Time (min)');
ylabel('Mean (Particle Mean Width, \mum)');

figure(2)

plot(new_tspan, std_W43);
title("Rosenblueth method");
ylabel('Time (min)');
ylabel('Standard deviation (Particle Mean Width, \mum)');

