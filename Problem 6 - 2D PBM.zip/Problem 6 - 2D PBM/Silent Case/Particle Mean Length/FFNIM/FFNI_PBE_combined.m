%% Full Factorial Numerical Integration (symmetric-normal)


clear all
close all
clc
tic
%------------------------Grid discretization-------------------------%

L_min   =    0;
L_max   =    600;
delL    =    20;
I_L     =    (L_max - L_min)/delL;
L_b     =    L_min : delL : L_max; 
L_m     =    L_min+delL/2 : delL : L_max-delL/2;



W_min   =    0;
W_max   =    300;
delW    =    10;
I_W     =    (W_max - W_min)/delW;
W_b     =    W_min : delW : W_max;
W_m     =    W_min+delW/2 : delW : W_max-delW/2;

[L, W]        =      meshgrid(L_m, W_m);
%------------------------Grid discretization-------------------------%


n_I         =     6;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu        =    [35.83 1.11 76.94 1.25 exp(23.72) 0.036];
sigma     =    mu * 5/100;

gamma     =     zeros(1, n_I);
Gamma     =     [3, 3, 3, 3, 3, 3];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha 

alpha_1      =     (gamma - sqrt(4 * Gamma - 3 * gamma.^2))/2;
alpha_2      =     zeros(1, n_I);
alpha_3      =     (gamma + sqrt(4 * Gamma - 3 * gamma.^2))/2;


alpha_x1    =     [alpha_1(1), alpha_2(1), alpha_3(1)];
alpha_x2    =     [alpha_1(2), alpha_2(2), alpha_3(2)];
alpha_x3    =     [alpha_1(3), alpha_2(3), alpha_3(3)];
alpha_x4    =     [alpha_1(4), alpha_2(4), alpha_3(4)];
alpha_x5    =     [alpha_1(5), alpha_2(5), alpha_3(5)];
alpha_x6    =     [alpha_1(6), alpha_2(6), alpha_3(6)];








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights

w1   =   ((4 * Gamma - 3 * gamma.^2) + gamma .* sqrt(4 * Gamma - 3 * gamma.^2)) ./ (2 * (4 * Gamma - 3 * gamma.^2) .* (Gamma - gamma.^2));
w2   =   (Gamma - gamma.^2 - 1) ./ (Gamma - gamma.^2);
w3   =   ((4 * Gamma - 3 * gamma.^2) - gamma .* sqrt(4 * Gamma - 3 * gamma.^2)) ./ (2 * (4 * Gamma - 3 * gamma.^2) .* (Gamma - gamma.^2));


w_x1  =  [w1(1), w2(1), w3(1)];
w_x2  =  [w1(2), w2(2), w3(2)];
w_x3  =  [w1(3), w2(3), w3(3)];
w_x4  =  [w1(4), w2(4), w3(4)];
w_x5  =  [w1(5), w2(5), w3(5)];
w_x6  =  [w1(6), w2(6), w3(6)];



w  =  [];
for i1 = 1:3    
    w_1   =   w_x1(i1);
    
    for i2 = 1:3        
        w_2    =    w_x2(i2);
        
        for i3 = 1:3            
            w_3    =   w_x3(i3);

            for i4 = 1:3            
                w_4    =   w_x4(i4); 

                for i5 = 1:3            
                    w_5    =   w_x5(i5); 

                    for i6 = 1:3            
                        w_6    =   w_x6(i6); 

                        we     =   w_1 * w_2 * w_3 * w_4 * w_5 * w_6 ;
                        w      =   [w; we];

                    end
                end
            end           
        end        
    end    
end
w;






 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples

samples  =  [];
for i1 = 1:3    
    vec1   =   mu(1)  +  alpha_x1(i1) * sigma(1);
    
    for i2 = 1:3        
        vec2    =    mu(2)  +  alpha_x2(i2) * sigma(2);
        
        for i3 = 1:3            
            vec3   =   mu(3)   +   alpha_x3(i3) * sigma(3);

            for i4 = 1:3
                vec4       =   mu(4)   +   alpha_x4(i4) * sigma(4);

                for i5 = 1:3
                    vec5       =   mu(5)   +   alpha_x5(i5) * sigma(5);

                    for i6 = 1:3
                        vec6       =   mu(6)   +   alpha_x6(i6) * sigma(6);

                
                        s          =   [vec1,  vec2,  vec3, vec4,  vec5,  vec6];            
                        samples    =   [samples; s];
                
                    end
                end
            end            
        end        
    end
end
samples;









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function Values

L_sam          =      size(samples,1);
tfinal         =      60;
delt           =      0.005;              % delta_t

tspan          =      [0 : delt : tfinal];
new_tspan      =      [0 : 1 : tfinal];





newMU43_L = [];
for k = 1:L_sam
    
    clc
    disp('Sample-->')
    disp(k)
    
    A1  = samples(k, 1);
    B1  = samples(k, 2);
    A2  = samples(k, 3);
    B2  = samples(k, 4);
    kJ1 = samples(k, 5);
    kJ2 = samples(k, 6);


          [MU43_L]     =    CR5(A1, B1, A2, B2, kJ1, kJ2, L, W, I_W, I_L, tfinal, delt, delL, delW, L_m);

    newMU43_L    =   [newMU43_L, MU43_L];
end

newMU43_L_UQ     =   newMU43_L(1 : 200 : end, :);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m  =  2;

mean_L43 = [];
var_L43  = [];
std_L43  = [];
for j = 1:length(new_tspan)

    Y = newMU43_L_UQ(j,:);


    raw_mom = [];
    for i = 1:m
    
        mom     = sum(w .* Y'.^i);
        raw_mom = [raw_mom; mom];
    
    end
    raw_mom;

    mean_Y = raw_mom(1);
    var_Y  = raw_mom(2) - raw_mom(1)^2;
    std_Y  = sqrt(var_Y);

    mean_L43 = [mean_L43; mean_Y];
    var_L43  = [var_L43;  var_Y];
    std_L43  = [std_L43;  std_Y];

end

mean_L43_end = mean_L43(end)
var_L43_end  = var_L43(end)
std_L43_end  = std_L43(end)






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

figure(1)

plot(new_tspan, mean_L43);
title('Full Factorial Numerical Integration method');
xlabel('Time (min)');
ylabel('Mean (Particle Mean Length, \mum)');

figure(2)

plot(new_tspan, std_L43);
title("Full Factorial Numerical Integration method");
ylabel('Standard deviation (Particle Mean Length, \mum)');
xlabel('Time (min)');


toc