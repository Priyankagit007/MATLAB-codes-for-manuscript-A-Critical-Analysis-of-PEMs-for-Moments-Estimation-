%% Experiment:- 0.5 C/min US = 50AMP

%% Monte Carlo


clc
clear all
close all

tic

%------------------------Grid discretization-------------------------%

L_min   =    0;
L_max   =    600;
delL    =    20;
I_L     =    (L_max - L_min)/delL;
L_b     =    L_min : delL : L_max; 
L_m     =    L_min+delL/2 : delL : L_max-delL/2;



W_min   =    0;
W_max   =    300;
delW    =    10;
I_W     =    (W_max - W_min)/delW;
W_b     =    W_min : delW : W_max;
W_m     =    W_min+delW/2 : delW : W_max-delW/2;

[L, W]        =      meshgrid(L_m, W_m);
%------------------------Grid discretization-------------------------%




%--------------------------Parameter samples------------------------------%

N         =    10000;


m_A1      =    35.83;
m_B1      =    1.11;
m_A2      =    76.94;
m_B2      =    1.25;
m_kJ1     =    exp(23.72);
m_kJ2     =    0.036;



s_A1      =    m_A1 * 5/100;
s_B1      =    m_B1 * 5/100;
s_A2      =    m_A2 * 5/100;
s_B2      =    m_B2 * 5/100;
s_kJ1     =    m_kJ1 * 5/100;
s_kJ2     =    m_kJ2 * 5/100;


A1_sam    =    normrnd(m_A1,        s_A1,          [N,1]);
B1_sam    =    normrnd(m_B1,        s_B1,          [N,1]);
A2_sam    =    normrnd(m_A2,        s_A2,          [N,1]);
B2_sam    =    normrnd(m_B2,        s_B2,          [N,1]);
kJ1_sam   =    normrnd(m_kJ1,       s_kJ1,         [N,1]);      
kJ2_sam   =    normrnd(m_kJ2,       s_kJ2,         [N,1]);


%--------------------------Parameter samples------------------------------%








%------------------------concentration-------------------------%

tfinal         =      60;
delt           =      0.005;              % delta_t

tspan          =      [0 : delt : tfinal];
new_tspan      =      [0 : 1 : tfinal];





newMU43_L = [];
for k = 1:N
    
    clc
    disp('Sample-->')
    disp(k)
    
    A1  = A1_sam(k);
    B1  = B1_sam(k);
    A2  = A2_sam(k);
    B2  = B2_sam(k);
    kJ1 = kJ1_sam(k);
    kJ2 = kJ2_sam(k);


    [MU43_L]     =    CR5(A1, B1, A2, B2, kJ1, kJ2, L, W, I_W, I_L, tfinal, delt, delL, delW, L_m);

    newMU43_L    =   [newMU43_L, MU43_L];
end

newMU43_L_UQ     =   newMU43_L(1 : 200 : end, :);

%------------------------concentration-------------------------%



      





%---------------------------Uncertainty analysis--------------------------%
mean_MU43_L  =  [];
var_MU43_L   =  [];
std_MU43_L   =  [];
Lower_L      =  [];
Upper_L      =  [];
for i = 1 : length(new_tspan)
    
    vec              =     newMU43_L_UQ(i,:);
    
    m_mu43_L         =     mean(vec);
    v_mu43_L         =     var(vec);
    s_mu43_L         =     std(vec);

    
    mean_MU43_L      =    [mean_MU43_L; m_mu43_L];
    var_MU43_L       =    [var_MU43_L;  v_mu43_L];
    std_MU43_L       =    [std_MU43_L;  s_mu43_L];
    
    lower_L          =    quantile(vec, 0.025);
    upper_L          =    quantile(vec, 0.975);
    
    Lower_L          =    [Lower_L; lower_L];
    Upper_L          =    [Upper_L; upper_L];
     
end
mean_L_end = mean_MU43_L(end)
var_L_end  = var_MU43_L(end)
std_L_end  = std_MU43_L(end)

%---------------------------Uncertainty analysis--------------------------%









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

figure(1)

plot(new_tspan, mean_MU43_L);
title('Monte Carlo method');
xlabel('Time (min)');
ylabel('Mean (Particle Mean Length, \mum)');

figure(2)

plot(new_tspan, std_MU43_L);
title('Monte Carlo method');
xlabel('Time (min)');
ylabel('Standard deviation (Particle Mean Length, \mum)');



toc



