%% Zhao and Ono (symmetric-normal)


clear all
close all
clc
tic
%------------------------Grid discretization-------------------------%

L_min   =    0;
L_max   =    600;
delL    =    20;
I_L     =    (L_max - L_min)/delL;
L_b     =    L_min : delL : L_max; 
L_m     =    L_min+delL/2 : delL : L_max-delL/2;



W_min   =    0;
W_max   =    300;
delW    =    10;
I_W     =    (W_max - W_min)/delW;
W_b     =    W_min : delW : W_max;
W_m     =    W_min+delW/2 : delW : W_max-delW/2;

[L, W]        =      meshgrid(L_m, W_m);
%------------------------Grid discretization-------------------------%


n_I         =     6;
m           =     3;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu        =    [35.83 1.11 76.94 1.25 exp(23.72) 0.036];
sigma     =    mu * 15/100;








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Points and weights for all r.v.s

u_i_j = [];
w_i_j = [];
for i = 1:n_I

    H_m_z     =      @(z) 8*z.^3 - 12*z;                                  % Hermite polynomial of degree m = 3
    z_j       =      roots([8, 0, -12, 0]);                               % points z_i_1,...,z_i_m
    u_j       =      sqrt(2) * z_j;                                       % points u_i_1,...,u_i_m

    u_i_j     =      [u_i_j, u_j];                                        % points [u_1_1, u_2_1, ..., u_n_1; ...;u_1_m, u_2_m,...,u_n_m]

    H_m1_z    =      @(z) 4*z.^2 - 2;                                     % Hermite polynomial of degree m-1
    value     =      H_m1_z(z_j);                                         % value of hermite polynomial of degree m-1 at points z_i_j
    W_j       =      (2^(m-1) * prod(1:m) * sqrt(pi))./(m^2 * value.^2);  % Weights for z
    w_j       =      W_j/sqrt(pi);                                        % weights u_i_1,...,u_i_m

    w_i_j     =      [w_i_j, w_j];                                        % weights [u_1_1, u_2_1,...,u_n_1;...;u_1_m, u_2_m,...,u_n_m]

end
u_ij  =  u_i_j';             % m points for all i=1,2,...,n

% [u_1_1, u_1_2, ..., u_1_m]
% [u_2_1, u_2_2, ..., u_2_m]
% .
% .
% .
% [u_n_1, u_n_2, ..., u_n_m]

w_ij  =  w_i_j';             % m weights for all i=1,2,...,n

% [w_1_1, w_1_2, ..., w_1_m]
% [w_2_1, w_2_2, ..., w_2_m]
% .
% .
% .
% [w_n_1, w_n_2, ..., w_n_m]                           









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% T inverse transformation on u_ij

Tinv_u_ij = [];
for i = 1:n_I

    T_inv_u   =   @(u) mu(i) + sigma(i) * u;  % define inverse rosenblatt transformation for normal r.v.s

    sam       =   T_inv_u(u_ij(i,:));         % [Tinv(u_i_1), Tinv(u_i_2),...,Tinv(u_i_m)]
        
    Tinv_u_ij =   [Tinv_u_ij; sam];
end
Tinv_u_ij;                                       % m samples for all i=1,2,...,n

% [Tinv(u_1_1), Tinv(u_1_2),...,Tinv(u_1_m))]
% [Tinv(u_2_1), Tinv(u_2_2),...,Tinv(u_2_m))]
% .
% .
% .
% [Tinv(u_n_1), Tinv(u_n_2),...,Tinv(u_n_m))]









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function value at mean

tfinal         =      60;
delt           =      0.005;              % delta_t

tspan          =      [0 : delt : tfinal];
new_tspan      =      [0 : 1 : tfinal];

A1     =   mu(1);
B1     =   mu(2);
A2     =   mu(3);
B2     =   mu(4);
kJ1    =   mu(5);
kJ2    =   mu(6);
            
f_mu     =    CR5(A1, B1, A2, B2, kJ1, kJ2, L, W, I_W, I_L, tfinal, delt, delL, delW, L_m);
f_mu     =    f_mu(1 : 200 : end, :);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Moments calculation

all_mu_i = [];
all_var_i = [];
all_ske_i = [];
for i = 1:n_I
    all_mean = mu;

    disp('Variable-->')
    disp(i)




    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Samples formation for each i=1 to n

    sample = [];
    for j = 1:m
        all_mean(i) = Tinv_u_ij(i,j);
        sample      = [sample; all_mean];
    end
    sample; 

    % Tinv(u_1_1), mu(2),...,mu(n)  
    % .
    % .
    % .
    % Tinv(u_1_m), mu(2),...,mu(n)





    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Function evaluations for each i=1,2,...,n
    
    newMU43_L = [];
    for j = 1:m

        x      =   sample(j,:);
    
        A1     =   x(1);
        B1     =   x(2);
        A2     =   x(3);
        B2     =   x(4);
        kJ1    =   x(5);
        kJ2    =   x(6);
            
        [MU43_L]     =    CR5(A1, B1, A2, B2, kJ1, kJ2, L, W, I_W, I_L, tfinal, delt, delL, delW, L_m);

        newMU43_L    =   [newMU43_L, MU43_L];

    end
    newMU43_L_UQ     =   newMU43_L(1 : 200 : end, :);

    % f(Tinv(u_1_1), mu(2),...,mu(n), t_0)      f(Tinv(u_1_2), mu(2),...,mu(n), t_0)  ...    f(Tinv(u_1_m), mu(2),...,mu(n), t_0)
    % .
    % .
    % .
    % f(Tinv(u_1_1), mu(2),...,mu(n), t_end)      f(Tinv(u_1_2), mu(2),...,mu(n), t_end)  ...    f(Tinv(u_1_m), mu(2),...,mu(n), t_end)






    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Mean for each i=1,2,...,n

    weights      =     w_ij(i,:);                 
    fun_value    =     newMU43_L_UQ;           

    mu_i         =     sum(weights .* fun_value, 2);   
    all_mu_i     =     [all_mu_i, mu_i];               

    % mu_1(t_0)   mu_2(t_0) ...  mu_n(t_0)
    % .
    % .
    % .
    % mu_1(t_end)   mu_2(t_end) ...  mu_n(t_end)





    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Mean of Length

    if (i==n_I)

       mu_Y    =    sum(all_mu_i,2) - (n_I-1)*f_mu;  % mean of concentration from t_0 to t_end

    end





    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Variance for each i=1,2,...,n

    weights     =   w_ij(i,:);
    fun_value   =   newMU43_L_UQ;

    var_i       =   sum(weights .* (fun_value - mu_i).^2, 2);
    all_var_i   =   [all_var_i, var_i];

    % var_1(t_0)   var_2(t_0) ...  var_n(t_0)
    % .
    % .
    % .
    % var_1(t_end)   var_2(t_end) ...  var_n(t_end)





    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Variance of Length

    if (i==n_I)
        var_Y    =    sum(all_var_i, 2);
        std_Y    =    sqrt(var_Y);
    end


end
mean_L43   =   mu_Y;
var_L43    =   var_Y;
std_L43    =   std_Y;

mean_L43_end   =   mean_L43(end)
var_L43_end    =   var_L43(end)
std_L43_end    =   std_L43(end)









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

figure(1)

plot(new_tspan', mean_L43);
title('Zhao and Ono method');
xlabel('Time (min)');
ylabel('Mean (Particle Mean Length, \mum)');

figure(2)

plot(new_tspan', std_L43);
title("Zhao and Ono method");
xlabel('Time (min)');
ylabel('Standard deviation (Particle Mean Length, \mum)');


