%% Experiment:- 0.5 C/min no US

function [MU43_L] = CR5(A1, B1, A2, B2, kJ1, kJ2, L, W, I_W, I_L, tfinal, delt, delL, delW, L_m)









%----------- Solvent and Solute properties-------------%

Roc     =   1400*10^3;         % gm/m3           density of solute

mliq    =   200;               % gm              mass of liquid

Roliq   =   1.03e6;            % gm/m3           density of solvent

VV      =   mliq/Roliq;        % m3              vol of liquid

R       =   8.314;             % J/(mol K)       gas constant

ee      =   1e-10;             % epsilon

%----------- Solvent and Solute properties-------------%








%-----------------Initial condition for n(L,t) and C(t)------------------%             

n          =      zeros(I_W, I_L);         % Initial condition (matrix form)  % no. per \mu m

n_dummy    =      zeros(I_W+3, I_L+3);     % dummy cells are addded

H          =      zeros(I_W, I_L);         % initial condition (matrix form) for n_ij (taken for B)

H(1,1)     =      1;                       % first entry of the matrix is 1           (taken for B)

C0         =      ((0.001368571428571).*(50+273.15).^2+(-0.781636285714319).*(50+273.15)+(1.125849746500052e+02))/100; % initial concentration

%-----------------Initial condition for n(L,t) and C(t)------------------%







%---------------------solution of PBE-----------------------------%

Vol_cell       =      L .*W * 10;        % vol of each cell

C              =      C0;                % for t = 0

MU43_L         =      [];

for t = 0 : delt : tfinal
    
%     clc
%     disp('CR-0.3')
%     disp('Time-->' )
%     disp(t)
    
    T     =    (50 - 0.5 * t) + 273.15;


    C_star       =      ((0.001368571428571).*T.^2 + (-0.781636285714319).*T + (1.125849746500052e+02))/100;      % saturation concentration
    S            =      C/C_star;  

    % conidition for crystllization
    if S<1
       S  =  1;
    else
       S  =  S;
    end

    G_L          =      A2  .*  (S-1).^B2;                               % growth rate along length
    G_W          =      A1  .*  (S-1).^B1;                               % growth rate along width
    
    Tot_vol      =      sum(sum(n .* Vol_cell * delL * delW));                    % no. \mu m^3  % total volume of particles
       
    B_P          =      kJ1 * exp(-kJ2./(log(real(S))).^2);
    
    
    if S<1
        G_L   =   0;
        G_W   =   0;
        B_P   =   0;
    end
    
    B  =  B_P;


    C       =    C0 - (Roc/Roliq) * Tot_vol * 10^(-18);  % g/g
    
    
    %---------------------Discretization-----------------------% 
    for i = 3 : I_W+2
        
        for j = 3 : I_L+2
                   
            r_p_L       =   (n_dummy(i,j+1) - n_dummy(i,j)   + ee) / (n_dummy(i,j)   - n_dummy(i,j-1) + ee);
            r_m_L       =   (n_dummy(i,j)   - n_dummy(i,j-1) + ee) / (n_dummy(i,j-1) - n_dummy(i,j-2) + ee);
            
            r_p_W       =   (n_dummy(i+1,j) - n_dummy(i,j)   + ee) / (n_dummy(i,j)   - n_dummy(i-1,j) + ee);
            r_m_W       =   (n_dummy(i,j)   - n_dummy(i-1,j) + ee) / (n_dummy(i-1,j) - n_dummy(i-2,j) + ee);
            
            phi_p_L     =   max(0, min(2*r_p_L, min((1/3)+(2/3)*r_p_L, 2)));
            phi_m_L     =   max(0, min(2*r_m_L, min((1/3)+(2/3)*r_m_L, 2)));
            
            phi_p_W     =   max(0, min(2*r_p_W, min((1/3)+(2/3)*r_p_W, 2)));
            phi_m_W     =   max(0, min(2*r_m_W, min((1/3)+(2/3)*r_m_W, 2)));
            
            G_n_p_L     =   G_L  *  (n_dummy(i,j)   + 0.5 * phi_p_L * (n_dummy(i,j)   - n_dummy(i,j-1)));
            G_n_m_L     =   G_L  *  (n_dummy(i,j-1) + 0.5 * phi_m_L * (n_dummy(i,j-1) - n_dummy(i,j-2)));
            
            G_n_p_W     =   G_W  *  (n_dummy(i,j)   + 0.5 * phi_p_W * (n_dummy(i,j)   - n_dummy(i-1,j)));
            G_n_m_W     =   G_W  *  (n_dummy(i-1,j) + 0.5 * phi_m_W * (n_dummy(i-1,j) - n_dummy(i-2,j)));
            
            GL(i,j)     =   G_n_p_L - G_n_m_L;
            GW(i,j)     =   G_n_p_W - G_n_m_W;
            
            n(i-2, j-2) =   n(i-2, j-2) + delt .* (H(i-2, j-2) * B/(delL * delW)  -  (GL(i,j)./delL)  -  (GW(i,j)./delW));
            
            n(i-2, j-2) =   max(0, n(i-2, j-2));  % to get nij positive
            
        end
        
    end
            
    %---------------------Discretization-----------------------% 

    
    
    
    
    % Updating n_dummy
    n_dummy                      =       zeros(I_W+3, I_L+3);   
    n_dummy(3:I_W+2, 3:I_L+2)    =       n;

    
   n_L_t      =    sum(n);



    mu43_L     =    sum(n_L_t .* L_m .* delL) ./ sum(n_L_t .* delL);
    MU43_L     =    [MU43_L; mu43_L];

end


end







