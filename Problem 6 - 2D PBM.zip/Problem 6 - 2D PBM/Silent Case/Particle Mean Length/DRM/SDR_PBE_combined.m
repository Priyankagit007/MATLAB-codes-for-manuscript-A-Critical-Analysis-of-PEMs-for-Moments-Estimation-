%% Experiment:- 0.5 C/min US = 50AMP

%% Dimension reduction


clc
clear all
close all
tic


%------------------------Grid discretization-------------------------%

L_min   =    0;
L_max   =    600;
delL    =    20;
I_L     =    (L_max - L_min)/delL;
L_b     =    L_min : delL : L_max; 
L_m     =    L_min+delL/2 : delL : L_max-delL/2;



W_min   =    0;
W_max   =    300;
delW    =    10;
I_W     =    (W_max - W_min)/delW;
W_b     =    W_min : delW : W_max;
W_m     =    W_min+delW/2 : delW : W_max-delW/2;

[L, W]        =      meshgrid(L_m, W_m);
%------------------------Grid discretization-------------------------%




%%%%%%%%%%%%%%%%%%%
% no of inputs

n_I       =    6;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% no of quadrature points (samples)

N       =    4;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments


mu        =    [35.83 1.11 76.94 1.25 exp(23.72) 0.036];
sigma     =    mu * 5/100;




%%%%%%%%%%%%%%%%%%%%%%
% no of output moments

m       =    2;


%%%%%%%%%%%%%%%%%%%%
% s-variate

s       =    5;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% input moments mu_j,i for each x_j

syms muu sigmaa tt

mgf   =   exp(muu * tt + 0.5 * sigmaa^2 * tt^2);

mom = [];
for i = 0:2*N-1
    
    di   =   diff(mgf, tt, i);
    
    mo   =   vpa(subs(di, tt, 0));
    
    mom  =   [mom; mo];
    
end
mom;


mu_0 = repmat(1,[1,n_I]);
mu_1 = mu;
mu_2 = mu.^2 + sigma.^2;
mu_3 = mu.^3 + 3 * mu .* sigma.^2;
mu_4 = mu.^4 + 6 * mu.^2 .* sigma.^2 + 3 * sigma.^4;
mu_5 = mu.^5 + 10 * mu.^3 .* sigma.^2 + 15 * mu .* sigma.^4;
mu_6 = mu.^6 + 15 * mu.^4 .* sigma.^2 + 45 * mu.^2 .* sigma.^4 + 15 * sigma.^6;
mu_7 = mu.^7 + 21 * mu.^5 .* sigma.^2 + 105 * mu.^3 .* sigma.^4 + 105 .* mu .* sigma.^6;
mu_8 = mu.^8 + 28 * mu.^6 .* sigma.^2 + 210 * mu.^4 .* sigma.^4 + 420 .* mu.^2 .* sigma.^6 + 105 * sigma.^8;
mu_9 = mu.^9 + 36 * mu.^7 .* sigma.^2 + 378 * mu.^5 .* sigma.^4 + 1260 * mu.^3 .* sigma.^6 + 945 * mu .* sigma.^8;
mu_10= mu.^10 + 45 * mu.^8 .* sigma.^2 + 630 * mu.^6 .* sigma.^4 + 3150 * mu.^4 .* sigma.^6 + 4725 * mu.^2 .* sigma.^8 + 945 * sigma.^10;
mu_11= mu.^11 + 55 * mu.^9 .* sigma.^2 + 990 * mu.^7 .* sigma.^4 + 6930 * mu.^5 .* sigma.^6 + 17325 * mu.^3 .* sigma.^8 + 10395 * mu .* sigma.^10;
mu_12= mu.^12 + 66 * mu.^10 .* sigma.^2 + 1485 * mu.^8 .* sigma.^4 + 13860 * mu.^6 .* sigma.^6 + 51975 * mu.^4 .* sigma.^8 + 62370 * mu.^2 .* sigma.^10 + 10395 .* sigma.^12;
mu_13= mu.^13 + 78 * mu.^11 .* sigma.^2 + 2145 * mu.^9 .* sigma.^4 + 25740 * mu.^7 .* sigma.^6 + 135135 * mu.^5 .* sigma.^8 + 270270 * mu.^3 .* sigma.^10 + 135135 * mu .* sigma.^12;
mu_14= mu.^14 + 91 * mu.^12 .* sigma.^2 + 3003 * mu.^10 .* sigma.^4 + 45045 * mu.^8 .* sigma.^6 + 315315 * mu.^6 .* sigma.^8 + 945945 * mu.^4 .* sigma.^10 + 945945 * mu.^2 .* sigma.^12 + 135135 * sigma.^14;
mu_15= mu.^15 + 105 * mu.^13 .* sigma.^2 + 4095 * mu.^11 .* sigma.^4 + 75075 * mu.^9 .* sigma.^6 + 675675 * mu.^7 .* sigma.^8 + 2837835 * mu.^5 .* sigma.^10 + 4729725 * mu.^3 .* sigma.^12 + 2027025 * mu .* sigma.^14;
mu_16= mu.^16 + 120 * mu.^14 .* sigma.^2 + 5460 * mu.^12 .* sigma.^4 + 120120 * mu.^10 .* sigma.^6 + 1351350 * mu.^8 .* sigma.^8 + 7567560 * mu.^6 .* sigma.^10 + 18918900 * mu.^4 .* sigma.^12 + 16216200 * mu.^2 .* sigma.^14 + 2027025 * sigma.^16;
mu_17= mu.^17 + 136 * mu.^15 .* sigma.^2 + 7140 * mu.^13 .* sigma.^4 + 185640 * mu.^11 .* sigma.^6 + 2552550 * mu.^9 .* sigma.^8 + 18378360 * mu.^7 .* sigma.^10 + 64324260 * mu.^5 .* sigma.^12 + 91891800 * mu.^3 .* sigma.^14 + 34459425 * mu .* sigma.^16;

moments = [mu_0; mu_1; mu_2; mu_3; mu_4; mu_5; mu_6; mu_7; mu_8; mu_9; mu_10; mu_11; mu_12; mu_13; mu_14; mu_15; mu_16; mu_17];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights: w_j,i and Points: x_j,i

points  = [];
weights = [];

for j = 1:n_I                            % for each j = 1, 2, 3, ... , n
    
    moments_j   =   moments(:,j);      % moments of x_j = x1, x2,...
    
    
    
    
    
    
    
    %------------------------%
    % LHS matrix of moments
    
    LHS = [];    
    for i = 1:N
        
        vec     =   moments_j(i:N+i-1);
        
        
        row = [];        
        for k = 1:length(vec)
            
            row   =   [row, (-1)^(k-1) * vec(end-k+1)];
            
        end
        
        Row   =   row;        
        LHS   =   [LHS; Row];
        
            
    end    
    LHS;
    
    
    
    
    
    %------------------------------%
    % RHS column matrix of moments
    
    RHS    =    moments_j(N+1:2*N);
    
    
    
    
    
    
    
    %------------------------------%
    % r_j,1 ; r_j,2, r_j,3 ; ...
    
    r_j    =    linsolve(LHS, RHS);
    
    
    
    
    
    
    %-------------------------%
    % x_j,1 ; x_j,2 ; x_j,3  
    
    coeff = 1;    
    for k = 1:length(r_j)
        
        coeff    =   [coeff, (-1)^k * r_j(k)];
        
    end
    
    x_j    =   roots(coeff);    
    points = [points, x_j];
    
    
    
    
    %-----------------------------%
    % Denominators of each w_j,i
    
    deno = [];
    for i = 1:N
        
        pr   =   1;
        
        for k = 1:N
            if (k~=i)                
                pr    =    pr * (x_j(i) - x_j(k));
            end            
        end
        
        deno    =    [deno; pr];
        
    end
    deno;
    
    
    
    
    
    
    
    %--------------------------------------%
    % moments in numerator of each w_j,i
    
    num_mu  =  flip(moments_j(1:N))';
    
    for i = 1:length(num_mu)
        
        if (rem(i,2)==0)
            
            num_mu(i)   =   - num_mu(i);
            
        end
        
    end    
    num_mu;
    
    
    
    
    
    
    
    
    %----------------------------------%
    % q_j,ik in numerators of w_j,i
    
    q_ik = [];
    
    for i = 1:N
        
        
        
        q0  =  1;
        
        q   =  [];       
        for k = 1:N-1
            
            q_k   =   r_j(k) - x_j(i) * q0;
            q0    =   q_k;
            q     =   [q; q0];
            
        end
        
        
        
        
        q_ik   =   [q_ik, q];
        
    end
            
    num_q   =   [repmat(1, [1,N]); q_ik]';   
    
    
    
    
    
    
    
    
    
    
    %----------------------------%
    % numerator in w_j,i
    
    num   =   sum(num_mu .* num_q, 2);
    
    
    
    
    %---------------------------%
    % Weights w_j,i
    
    w_j       =   num./deno;
    
    weights   =   [weights, w_j];
        
end

points    =   points;
weights   =   weights;






for i = 1:s
    
    nCs(i) = nchoosek(n_I,i);
    
end
nCs;

max_nCs  =  max(nCs);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculating all expectations & their powers

all_exp_t_1 = [];        % for mean
all_exp_t_2 = [];        % for variance
for i = 1:s
    
    
    C = nchoosek([1:n_I], i);
    
    % E[Z(x1)],         E[Z(x2)],         E[Z(x3)]                             i = 1
    % E[Z(x1, x2)],     E[Z(x1, x3)],     E[Z(x2,x3)]                          i = 2
    % E[Z(x1, x2, x3)], E[Z(x1, x2, x4)], E[Z(x1, x3, x4)], E[Z(x2, x3, x4)]   i = 3
    
    
    
    
    
    
    %---------------------------------------------------------------------%
    Exp_j_1 = [];
    Exp_j_2 = [];
    for j = 1:length(C)
        
        clc
        disp('i---->')
        disp(i)
        
        disp('j---->')
        disp(j)
        
        vec = C(j,:);
        
        % i = 1
        % E[Z(x1)]  j = 1
        % E[Z(x2)]  j = 2
        % E[Z(x3)]  j = 3
        
        % i = 2
        % E[Z(x1, x2)]  j = 1
        % E[Z(x1, x3)]  j = 2
        % E[Z(x2, x3)]  j = 3
        
        % i = 3
        % E[Z(x1, x2, x3)]  j = 1
        % E[Z(x1, x2, x4)]  j = 1
        % E[Z(x1, x3, x4)]  j = 1
        % E[Z(x2, x3, x4)]  j = 1
        
        
        
        
        
        
        
        %--------Collection of weights & points---------%
        
        Ws   = [];
        x_js = [];
        for k = 1:length(vec)
            
            col         =     vec(k);
            
            wj_call     =     weights(:,col);            
            Ws          =     [Ws, wj_call];
            
            xj_call     =     points(:,col);
            x_js        =     [x_js, xj_call];
            
        end
        
        Ws;
        
        x_js;
        
        %--------Collection of weights & points---------%
        
        
        
        
        
        
        %------------------Product of weights--------------%
        prod_w   =   1;
        
        L1        =   length(vec);

        for i1 = 1:L1
            
            w_call   =   Ws(:,i1);
            
            
            
            
            new_w  = [];
            for i2 = 1:N                      % no. of quad points
                
                w          =   w_call(i2);
                
                
                rep_w      =   repmat(w, [N^(L1-i1), 1]);
                
                new_w      =   [new_w; rep_w];
                
                rep_new_w  =   repmat(new_w, [N^(i1-1), 1]);
                 
            end
            
            rep_new_w;
            
            
            
            
            
            prod_w    =   prod_w .* rep_new_w;
            
        end
        final_w       =   prod_w;
        %------------------Product of weights--------------%
  
        
        
        
        
        
        
        
        
        
        %----------------------samples-----------------------%
        %-----------------------------------------%
        final_xj = [];
        for i1 = 1:length(vec)
            
            xj_call   =   x_js(:,i1);
            
            
            
            
            new_xj = [];
            for i2 = 1:N                     % no. of quad points
                
                xj          =   xj_call(i2);
                
                
                rep_xj      =   repmat(xj, [N^(L1-i1), 1]);
                
                new_xj      =   [new_xj; rep_xj];
                
                rep_new_xj  =   repmat(new_xj, [N^(i1-1), 1]);
                 
            end
            
            
            
         
            final_xj = [final_xj, rep_new_xj];
                   
        end
        
        final_xj;
        %---------------------------------------%
        %--------------------------------------%
        L2       =     size(final_xj,1);
        
        sample   =     mu;
        
        samples = [];
        for i1 = 1:L2
            
            row_call           =     final_xj(i1,:);
            
            
            
            for i2 = 1:L1
                
                position             =    vec(i2);
                
                entry_call           =    row_call(i2);
                
                sample(position)     =    entry_call;
                
            end
            
            
            
            samples = [samples; sample];
            
        end
        samples;      
        %-------------------------------------%
        %----------------------------samples----------------------%
        
        
        
        
        
        %------------------------Model evaluation-------------------------%

        tfinal         =      60;
        delt           =      0.005;              % delta_t

        tspan          =      [0 : delt : tfinal];
        new_tspan      =      [0 : 1 : tfinal];


        


        newMU43_L = [];
        for k = 1:L2
    
%             clc
%             disp('Sample-->')
%             disp(k)
    
            A1  = samples(k,1);
            B1  = samples(k,2);
            A2  = samples(k,3);
            B2  = samples(k,4);
            kJ1 = samples(k,5);
            kJ2 = samples(k,6);


          [MU43_L]     =    CR5(A1, B1, A2, B2, kJ1, kJ2, L, W, I_W, I_L, tfinal, delt, delL, delW, L_m);

          newMU43_L    =   [newMU43_L, MU43_L];
        end

        newMU43_L_UQ     =   newMU43_L(1 : 200 : end, :);

        %------------------------Model evaluation-------------------------%


         
        



        
        %------------------------Expectations & powers at all times---------------------------%

        Exp_1_t = [];
        Exp_2_t = [];
        for i1 = 1:length(new_tspan)

            final_y   =    newMU43_L_UQ(i1,:)';

            Exp_1     =    sum(final_w .* final_y.^1);      % for mean
            Exp_2     =    sum(final_w .* final_y.^2);      % for variance
       
            Exp_1_t   =    [Exp_1_t; Exp_1];                % for mean at all time 
            Exp_2_t   =    [Exp_2_t; Exp_2];                % for mean at all time

        end
        Exp_1_t;       % E[Z(x1, ... , t)]
        Exp_2_t;       % E[Z(x1, ... , t)]^2

        %------------------------Expectations & powers at all times---------------------------%



           
        
        Exp_j_1 = [Exp_j_1, Exp_1_t];
        Exp_j_2 = [Exp_j_2, Exp_2_t];
        
    end  %----- j
    Exp_j_1;
    Exp_j_2;
    %-----------------------------------------------------------------------%
    
    
     
        
    %----------collection of all exp---------------%
    if (s>1)
        
        no_col    =  max_nCs - nchoosek(n_I,i);
        zeromat   =  zeros(length(new_tspan), no_col);

        Exp_j_1   =  [Exp_j_1, zeromat];          % for mean
        Exp_j_2   =  [Exp_j_2, zeromat];          % for variance

    end

    all_exp_t_1         =  [all_exp_t_1; Exp_j_1];            % for mean
    all_exp_t_2         =  [all_exp_t_2; Exp_j_2];            % for variance

    %----------collection of all exp---------------%
    
end %------ i
all_exp_t_1;             % for mean
all_exp_t_2;             % for variance


% all_exp_t_1 
% E[Z(x1, t)],         E[Z(x2, t)],         E[Z(x3, t)] ,....
% E[Z(x1, x2, t)]      E[Z(x1, x3, t)]      E[Z(x1, x4, t)] ,...
% E[Z(x1, x2, x3, t)]  E[Z(z1, z2, z4, t)]  E[Z(x1, x2, x5, t)], ....


% all_exp_t_2 
% E[Z(x1, t)]^2,         E[Z(x2, t)]^2,         E[Z(x3, t)]^2 ,....
% E[Z(x1, x2, t)]^2      E[Z(x1, x3, t)]^2      E[Z(x1, x4, t)]^2 ,...
% E[Z(x1, x2, x3, t)]^2  E[Z(z1, z2, z4, t)]^2  E[Z(x1, x2, x5, t)]^2, ....









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Z(mu) = y(mu), y(mu)^2, ..., y(mu)^m

tfinal         =      60;
delt           =      0.005;              % delta_t

tspan          =      [0 : delt : tfinal];
new_tspan      =      [0 : 1 : tfinal];




A1  = mu(1);
B1  = mu(2);
A2  = mu(3);
B2  = mu(4);
kJ1 = mu(5);
kJ2 = mu(6);



newMU43_L      =      CR5(A1, B1, A2, B2, kJ1, kJ2, L, W, I_W, I_L, tfinal, delt, delL, delW, L_m);


newMU43_L_UQ   =      newMU43_L(1 : 200 : end);


y_mean         =      newMU43_L_UQ;


%----------------------------------%
z_mean_1       =      y_mean;         % E[Z(mu)]
z_mean_2       =      y_mean.^2;      % E[Z(mu)^2]








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean

mean_y = [];
for k = 1:length(new_tspan)

    Exp  =  all_exp_t_1(k : length(new_tspan) : end, :);

    %--------------------------------------------%
        SUM = 0;
        for j = 0:s
        
            b       =    (-1)^j * nchoosek(n_I-s+j-1,j);
        
            if (j==s)
            
               E   =    z_mean_1(k);
            
            else
            
               E   =    sum(Exp(end-j,:));
            
            end
        
            SUM     =    SUM + (b*E);
        
        end
        %-------------------------------------------%

        mean_y  =  [mean_y; SUM];
end
mean_y;









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
% Variance

raw_mom_2 = [];
for k = 1:length(new_tspan)

    Exp  =  all_exp_t_2(k : length(new_tspan) : end, :);

    %--------------------------------------------%
        SUM = 0;
        for j = 0:s
        
            b       =    (-1)^j * nchoosek(n_I-s+j-1,j);
        
            if (j==s)
            
               E   =    z_mean_2(k);
            
            else
            
               E   =    sum(Exp(end-j,:));
            
            end
        
            SUM     =    SUM + (b*E);
        
        end
        %-------------------------------------------%

        raw_mom_2  =  [raw_mom_2; SUM];
end
raw_mom_2;
    
var_y  =  raw_mom_2 - mean_y.^2;
std_y  =  sqrt(var_y);


mean_y_end  =  mean_y(end)
var_y_end   =  var_y(end)
std_y_end   =  std_y(end)




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

figure(1)

plot(new_tspan, mean_y);
title('Dimension Reduction method');
xlabel('Time (min)');
ylabel('Mean (Particle Mean Length, \mum)');

figure(2)

plot(new_tspan, std_y);
title('Dimension Reduction method');
xlabel('Time (min)');
ylabel('Standard deviation (Particle Mean Length, \mum)');


toc

