clear all
close all
clc

%% silent - case 5% variation


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Particle mean width

f5  =  xlsread('mean_5_width.xlsx');

monte_mean_width        =  f5(2:2:end,1);
rosen_mean_width        =  f5(2:2:end,3);
harr_mean_width         =  f5(2:2:end,4);
li_mean_width           =  f5(2:2:end,5);
modiharr_mean_width     =  f5(2:2:end,6);
modirosen_mean_width    =  f5(2:2:end,7);
ffni_mean_width         =  f5(2:2:end,8);
sdr_mean_width          =  f5(2:2:end,9);
zhao_mean_width         =  f5(2:2:end,12);


f6  =  xlsread('var_5_width.xlsx');

monte_var_width        =  f6(2:2:end,1);
rosen_var_width        =  f6(2:2:end,3);
harr_var_width         =  f6(2:2:end,4);
li_var_width           =  f6(2:2:end,5);
modiharr_var_width     =  f6(2:2:end,6);
modirosen_var_width    =  f6(2:2:end,7);
ffni_var_width         =  f6(2:2:end,8);
sdr_var_width          =  f6(2:2:end,9);
zhao_var_width         =  f6(2:2:end,12);


monte_std_width        =  sqrt(monte_var_width);
rosen_std_width        =  sqrt(rosen_var_width);
harr_std_width         =  sqrt(harr_var_width);
li_std_width           =  sqrt(li_var_width);
modiharr_std_width     =  sqrt(modiharr_var_width);
modirosen_std_width    =  sqrt(modirosen_var_width);
ffni_std_width         =  sqrt(ffni_var_width);
sdr_std_width          =  sqrt(sdr_var_width);
zhao_std_width         =  sqrt(zhao_var_width);


rosen_meanerror_width        =  abs((monte_mean_width - rosen_mean_width)./monte_mean_width)*100;
harr_meanerror_width         =  abs((monte_mean_width  - harr_mean_width)./monte_mean_width)*100;
li_meanerror_width           =  abs((monte_mean_width  - li_mean_width)./monte_mean_width)*100;
modiharr_meanerror_width     =  abs((monte_mean_width  - modiharr_mean_width)./monte_mean_width)*100;
modirosen_meanerror_width    =  abs((monte_mean_width - modirosen_mean_width)./monte_mean_width)*100;
ffni_meanerror_width         =  abs((monte_mean_width  - ffni_mean_width)./monte_mean_width)*100;
sdr_meanerror_width          =  abs((monte_mean_width  - sdr_mean_width)./monte_mean_width)*100;
zhao_meanerror_width         =  abs((monte_mean_width  - zhao_mean_width)./monte_mean_width)*100;

rosen_stderror_width        =  abs((monte_std_width - rosen_std_width)./monte_std_width)*100;
harr_stderror_width         =  abs((monte_std_width  - harr_std_width)./monte_std_width)*100;
li_stderror_width           =  abs((monte_std_width  - li_std_width)./monte_std_width)*100;
modiharr_stderror_width     =  abs((monte_std_width  - modiharr_std_width)./monte_std_width)*100;
modirosen_stderror_width    =  abs((monte_std_width - modirosen_std_width)./monte_std_width)*100;
ffni_stderror_width         =  abs((monte_std_width  - ffni_std_width)./monte_std_width)*100;
sdr_stderror_width          =  abs((monte_std_width  - sdr_std_width)./monte_std_width)*100;
zhao_stderror_width         =  abs((monte_std_width  - zhao_std_width)./monte_std_width)*100;


tspan = [2:2:60];


figure;


%------------------------Plotting------------------------------%

subplot(4,2,1)

plot(tspan, rosen_meanerror_width, 'Marker', 'o', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.6350 0.0780 0.1840]); % g
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-0.1 2]);
yticks([0 2]);
yticklabels({'0','2'});

subplot(4,2,2)

plot(tspan, harr_meanerror_width, 'Marker', '*', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0 0.4470 0.7410]); % gamma
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-0.1 2]);
yticks([0 2]);
yticklabels({'0','2'});

subplot(4,2,3)

plot(tspan, modiharr_meanerror_width, '-', 'Marker', 'x', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.9 0.1 0.3410]); % gamma
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-0.1 2]);
yticks([0 2]);
yticklabels({'0','2'});

subplot(4,2,4)

plot(tspan, li_meanerror_width, '-', 'Marker', 'square', 'MarkerSize', 5,'LineWidth', 1.2, 'Color', [0.9290 0.6940 0.1250]); % eta
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-0.1 2]);
yticks([0 2]);
yticklabels({'0','2'});

subplot(4,2,5)

plot(tspan, modirosen_meanerror_width, '--', 'Marker', 'o', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.4940 0.1840 0.5560]); % alpha
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-0.1 2]);
yticks([0 2]);
yticklabels({'0','2'});

subplot(4,2,6)

plot(tspan, zhao_meanerror_width, '--', 'Marker', '*', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.1010 0.4450 0.1330]); % nu_0
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-0.1 2]);
yticks([0 2]);
yticklabels({'0','2'});

subplot(4,2,7)

plot(tspan, ffni_meanerror_width, '--', 'Marker', 'x', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.4660 0.6740 0.1880]); % beta
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-0.1 2]);
yticks([0 2]);
yticklabels({'0','2'});

subplot(4,2,8)

plot(tspan, sdr_meanerror_width, '--', 'Marker', 'square', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.3010 0.7450 0.9330]); % nu_0
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-0.1 2]);
yticks([0 2]);
yticklabels({'0','2'});


% Create invisible axes
han = axes(gcf,'visible','off');
han.XLabel.Visible = 'on';
han.YLabel.Visible = 'on';
han.Title.Visible = 'on';

x1 = xlabel(han,{'Time (min)', '(a)'}, 'Interpreter', 'latex', 'FontSize', 20);
y1 = ylabel(han,'Relative error, $\mathcal{E}_{1}$ (\%)', 'Interpreter', 'latex','FontSize',20);
t1 = title(han,'Particle mean width','FontSize',20,'FontWeight','bold','Interpreter','latex');

% Increase distance between x-axis and xlabel
ax = gca;
ax.XLabel.Units = 'normalized';
ax.XLabel.Position(2) = -0.04;   % Move xlabel downward

set(gcf,'position',[100,100,750,800])
str = 'widthmeanerror_5_silent';
savePDF_width(str)
%------------------------Plotting------------------------------%



















figure;





















%------------------------Plotting------------------------------%

subplot(4,2,1)

plot(tspan, rosen_stderror_width, 'Marker', 'o', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.6350 0.0780 0.1840]); % g
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,2)

plot(tspan, harr_stderror_width, 'Marker', '*', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0 0.4470 0.7410]); % gamma
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,3)

plot(tspan, modiharr_stderror_width, '-', 'Marker', 'x', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.9 0.1 0.3410]); % gamma
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,4)

plot(tspan, li_stderror_width, '-', 'Marker', 'square', 'MarkerSize', 5,'LineWidth', 1.2, 'Color', [0.9290 0.6940 0.1250]); % eta
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,5)

plot(tspan, modirosen_stderror_width, '--', 'Marker', 'o', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.4940 0.1840 0.5560]); % alpha
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,6)

plot(tspan, zhao_stderror_width, '--', 'Marker', '*', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.1010 0.4450 0.1330]); % nu_0
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,7)

plot(tspan, ffni_stderror_width, '--', 'Marker', 'x', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.4660 0.6740 0.1880]); % beta
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,8)

plot(tspan, sdr_stderror_width, '--', 'Marker', 'square', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.3010 0.7450 0.9330]); % nu_0
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

% Create invisible axes
han = axes(gcf,'visible','off');
han.XLabel.Visible = 'on';
han.YLabel.Visible = 'on';

x1 = xlabel(han,{'Time (min)', '(b)'}, 'Interpreter', 'latex', 'FontSize', 20);
y1 = ylabel(han,'Relative error, $\mathcal{E}_{2}$ (\%)', 'Interpreter', 'latex','FontSize',20);

% Increase distance between x-axis and xlabel
ax = gca;
ax.XLabel.Units = 'normalized';
ax.XLabel.Position(2) = -0.04;   % Move xlabel downward

set(gcf,'position',[100,100,750,800])
str = 'widthstderror_5_silent';
savePDF_width(str)
%------------------------Plotting------------------------------%
