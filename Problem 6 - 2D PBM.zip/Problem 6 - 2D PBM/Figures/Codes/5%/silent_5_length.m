clear all
close all
clc

%% silent - case 5% variation



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Particle mean length

f3  =  xlsread('mean_5_length.xlsx');

monte_mean_length        =  f3(2:2:end,1);
rosen_mean_length        =  f3(2:2:end,3);
harr_mean_length         =  f3(2:2:end,4);
li_mean_length           =  f3(2:2:end,5);
modirosen_mean_length    =  f3(2:2:end,6);
modiharr_mean_length     =  f3(2:2:end,7);
ffni_mean_length         =  f3(2:2:end,8);
sdr_mean_length          =  f3(2:2:end,9);
zhao_mean_length         =  f3(2:2:end,12);


f4  =  xlsread('var_5_length.xlsx');

monte_var_length        =  f4(2:2:end,1);
rosen_var_length        =  f4(2:2:end,3);
harr_var_length         =  f4(2:2:end,4);
li_var_length           =  f4(2:2:end,5);
modiharr_var_length     =  f4(2:2:end,6);
modirosen_var_length    =  f4(2:2:end,7);
ffni_var_length         =  f4(2:2:end,8);
sdr_var_length          =  f4(2:2:end,9);
zhao_var_length         =  f4(2:2:end,12);


monte_std_length        =  sqrt(monte_var_length);
rosen_std_length        =  sqrt(rosen_var_length);
harr_std_length         =  sqrt(harr_var_length);
li_std_length           =  sqrt(li_var_length);
modiharr_std_length     =  sqrt(modiharr_var_length);
modirosen_std_length    =  sqrt(modirosen_var_length);
ffni_std_length         =  sqrt(ffni_var_length);
sdr_std_length          =  sqrt(sdr_var_length);
zhao_std_length         =  sqrt(zhao_var_length);

rosen_meanerror_length        =  abs((monte_mean_length - rosen_mean_length)./monte_mean_length)*100;
harr_meanerror_length         =  abs((monte_mean_length  - harr_mean_length)./monte_mean_length)*100;
li_meanerror_length           =  abs((monte_mean_length  - li_mean_length)./monte_mean_length)*100;
modiharr_meanerror_length     =  abs((monte_mean_length  - modiharr_mean_length)./monte_mean_length)*100;
modirosen_meanerror_length    =  abs((monte_mean_length - modirosen_mean_length)./monte_mean_length)*100;
ffni_meanerror_length         =  abs((monte_mean_length  - ffni_mean_length)./monte_mean_length)*100;
sdr_meanerror_length          =  abs((monte_mean_length  - sdr_mean_length)./monte_mean_length)*100;
zhao_meanerror_length         =  abs((monte_mean_length  - zhao_mean_length)./monte_mean_length)*100;

rosen_stderror_length        =  abs((monte_std_length - rosen_std_length)./monte_std_length)*100;
harr_stderror_length         =  abs((monte_std_length  - harr_std_length)./monte_std_length)*100;
li_stderror_length           =  abs((monte_std_length  - li_std_length)./monte_std_length)*100;
modiharr_stderror_length     =  abs((monte_std_length  - modiharr_std_length)./monte_std_length)*100;
modirosen_stderror_length    =  abs((monte_std_length - modirosen_std_length)./monte_std_length)*100;
ffni_stderror_length         =  abs((monte_std_length  - ffni_std_length)./monte_std_length)*100;
sdr_stderror_length          =  abs((monte_std_length  - sdr_std_length)./monte_std_length)*100;
zhao_stderror_length         =  abs((monte_std_length  - zhao_std_length)./monte_std_length)*100;


tspan = [2:2:60];









% 
% figure
% 
% plot(tspan, rosen_mean_length, 'Marker', 'o', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.6350 0.0780 0.1840]);
% hold on
% plot(tspan, harr_mean_length, 'Marker', '*', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0 0.4470 0.7410]);
% plot(tspan, modiharr_mean_length, '-', 'Marker', 'x', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.9 0.1 0.3410]);
% plot(tspan, li_mean_length, '-', 'Marker', 'square', 'MarkerSize', 5,'LineWidth', 1.2, 'Color', [0.9290 0.6940 0.1250]);
% plot(tspan, modirosen_mean_length, '--', 'Marker', 'o', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.4940 0.1840 0.5560]);
% plot(tspan, zhao_mean_length, '--', 'Marker', '*', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.1010 0.4450 0.1330]);
% plot(tspan, ffni_mean_length,  '--', 'Marker', 'x', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.4660 0.6740 0.1880]);
% plot(tspan, sdr_mean_length, '--', 'Marker', 'square', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.3010 0.7450 0.9330]);
% 
% legend('RM ($\mathcal{N} = 64$)', 'HM ($\mathcal{N}$ = 12)', 'MHM ($\mathcal{N}$ = 12)', 'LM ($\mathcal{N}$ = 13)', 'MRM ($\mathcal{N}$ = 13)', 'ZOM, v=3 ($\mathcal{N}$ = 13)', 'FFNIM ($\mathcal{N}$ = 729)', 'Bivariate DRM, v=3 ($\mathcal{N}$ = 73)','Orientation','horizontal','NumColumns',4,'FontSize',12,'Interpreter','latex','LineWidth',1.1,'FontName','Arial');
% set(gca,'FontSize',11,'FontName','Arial','linewidth',1.1)
% set(gcf,'position',[100,100,750,600])
% str = 'lengthmeanerror_5_silent';
% savePDF_length(str)

















%------------------------Plotting------------------------------%
figure;

subplot(4,2,1)

plot(tspan, rosen_meanerror_length, 'Marker', 'o', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.6350 0.0780 0.1840]); % g
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([0.5 61]);
ylim([-0.1 1.5]);
yticks([0 1.5]);
yticklabels({'0','1.5'});

subplot(4,2,2)

plot(tspan, harr_meanerror_length, 'Marker', '*', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0 0.4470 0.7410]); % gamma
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([0.5 61]);
ylim([-0.1 1.5]);
yticks([0 1.5]);
yticklabels({'0','1.5'});

subplot(4,2,3)

plot(tspan, modiharr_meanerror_length, '-', 'Marker', 'x', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.9 0.1 0.3410]); % gamma
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([0.5 61]);
ylim([-0.1 1.5]);
yticks([0 1.5]);
yticklabels({'0','1.5'});

subplot(4,2,4)

plot(tspan, li_meanerror_length, '-', 'Marker', 'square', 'MarkerSize', 5,'LineWidth', 1.2, 'Color', [0.9290 0.6940 0.1250]); % eta
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([0.5 61]);
ylim([-0.1 1.5]);
yticks([0 1.5]);
yticklabels({'0','1.5'});

subplot(4,2,5)

plot(tspan, modirosen_meanerror_length, '--', 'Marker', 'o', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.4940 0.1840 0.5560]); % alpha
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([0.5 61]);
ylim([-0.1 1.5]);
yticks([0 1.5]);
yticklabels({'0','1.5'});

subplot(4,2,6)

plot(tspan, zhao_meanerror_length, '--', 'Marker', '*', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.1010 0.4450 0.1330]); % nu_0
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([0.5 61]);
ylim([-0.1 1.5]);
yticks([0 1.5]);
yticklabels({'0','1.5'});

subplot(4,2,7)

plot(tspan, ffni_meanerror_length, '--', 'Marker', 'x', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.4660 0.6740 0.1880]); % beta
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([0.5 61]);
ylim([-0.1 1.5]);
yticks([0 1.5]);
yticklabels({'0','1.5'});

subplot(4,2,8)

plot(tspan, sdr_meanerror_length, '--', 'Marker', 'square', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.3010 0.7450 0.9330]); % nu_0
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([0.5 61]);
ylim([-0.1 1.5]);
yticks([0 1.5]);
yticklabels({'0','1.5'});

% Create invisible axes
han = axes(gcf,'visible','off');
han.XLabel.Visible = 'on';
han.YLabel.Visible = 'on';
han.Title.Visible = 'on';

x1 = xlabel(han,{'Time (min)', '(a)'}, 'Interpreter', 'latex', 'FontSize', 20);
y1 = ylabel(han,'Relative error, $\mathcal{E}_{1}$ (\%)', 'Interpreter', 'latex','FontSize',20);
t1 = title(han,'Particle mean length','FontSize',20,'FontWeight','bold','Interpreter','latex');

% Increase distance between x-axis and xlabel
ax = gca;
ax.XLabel.Units = 'normalized';
ax.XLabel.Position(2) = -0.04;   % Move xlabel downward
%% 

set(gcf,'position',[100,100,750,800])
str = 'lengthmeanerror_5_silent';
savePDF_length(str)
%------------------------Plotting------------------------------%










figure;


%------------------------Plotting------------------------------%

subplot(4,2,1)

plot(tspan, rosen_stderror_length, 'Marker', 'o', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.6350 0.0780 0.1840]); % g
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,2)

plot(tspan, harr_stderror_length, 'Marker', '*', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0 0.4470 0.7410]); % gamma
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,3)

plot(tspan, modiharr_stderror_length, '-', 'Marker', 'x', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.9 0.1 0.3410]); % gamma
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,4)

plot(tspan, li_stderror_length, '-', 'Marker', 'square', 'MarkerSize', 5,'LineWidth', 1.2, 'Color', [0.9290 0.6940 0.1250]); % eta
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,5)

plot(tspan, modirosen_stderror_length, '--', 'Marker', 'o', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.4940 0.1840 0.5560]); % alpha
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,6)

plot(tspan, zhao_stderror_length, '--', 'Marker', '*', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.1010 0.4450 0.1330]); % nu_0
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,7)

plot(tspan, ffni_stderror_length, '--', 'Marker', 'x', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.4660 0.6740 0.1880]); % beta
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

subplot(4,2,8)

plot(tspan, sdr_stderror_length, '--', 'Marker', 'square', 'MarkerSize', 5, 'LineWidth', 1.2, 'Color', [0.3010 0.7450 0.9330]); % nu_0
set(gca,'FontSize',14,'FontName','Arial','linewidth',1.1)
xlim([1 61]);
ylim([-1 30]);
yticks([0 30]);
yticklabels({'0','30'});

% Create invisible axes
han = axes(gcf,'visible','off');
han.XLabel.Visible = 'on';
han.YLabel.Visible = 'on';

x1 = xlabel(han,{'Time (min)', '(b)'}, 'Interpreter', 'latex', 'FontSize', 20);
y1 = ylabel(han,'Relative error, $\mathcal{E}_{2}$ (\%)', 'Interpreter', 'latex','FontSize',20);

% Increase distance between x-axis and xlabel
ax = gca;
ax.XLabel.Units = 'normalized';
ax.XLabel.Position(2) = -0.04;   % Move xlabel downward

set(gcf,'position',[100,100,750,800])
str = 'lengthstderror_5_silent';
savePDF_length(str)
%------------------------Plotting------------------------------%