
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Linear elastic cantilever beam

clear all
close all
clc


N        =       10^7;


%----------------lognormal (x1, x2)-----------------%

m_log         =       [8000,   1500];
cof_log       =       [0.25,  0.25]/2;
s_log         =       m_log .* cof_log;
v_log         =       s_log.^2;

m_norm        =       log(m_log.^2./sqrt(v_log + m_log.^2));
s_norm        =       sqrt(log(v_log./m_log.^2 + 1));

x1            =       lognrnd(m_norm(1), s_norm(1), [N,1]);
x2            =       lognrnd(m_norm(2), s_norm(2), [N,1]);


%------------------gamma x3 ---------------------%

m_gam         =       4*10^6;
cof_gam       =       0.10*2;
s_gam         =       m_gam .* cof_gam;

theta_gam     =       s_gam^2/m_gam;
k_gam         =       m_gam/theta_gam;

x3            =       gamrnd(k_gam, theta_gam, [N,1]);


%--------------------normal x4, x5, x6, x7, x8--------------------------------------------%

mu       =       [5*10^4,  2*10^8,  4*10^8,  8*10^4,  2.05*10^5];
cof      =       [0.10,    0.10,    0.08,    0.15,    0.15]/2;
sigma    =       mu .* cof;

x4       =       normrnd(mu(1), sigma(1), [N,1]);
x5       =       normrnd(mu(2), sigma(2), [N,1]);
x6       =       normrnd(mu(3), sigma(3), [N,1]);
x7       =       normrnd(mu(4), sigma(4), [N,1]);
x8       =       normrnd(mu(5), sigma(5), [N,1]);

L        =       3000;
del      =       2000;

f        =       del - ((x1.^2 * L)./(2*x4.*x8) + (x2.^2 * L.^3)./(6*x5.*x8) + (x3.^2*L)./(2*x6.*x7));

mean_f   =       mean(f)
std_f    =       std(f)
skew_f   =       skewness(f)
kur_f    =       kurtosis(f)


