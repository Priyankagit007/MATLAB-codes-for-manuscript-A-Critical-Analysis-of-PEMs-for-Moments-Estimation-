
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Linear elastic cantilever beam

clear all
close all
clc


n = 8;



%----------------lognormal (x1, x2)-----------------%

m_log         =       [8000,   1500];
cof_log       =       [0.25,  0.25]/1;
s_log         =       m_log .* cof_log;
v_log         =       s_log.^2;

m_norm        =       log(m_log.^2./sqrt(v_log + m_log.^2));
s_norm        =       sqrt(log(v_log./m_log.^2 + 1));

g_log         =       (exp(s_norm.^2) + 2) .* sqrt(exp(s_norm.^2) - 1);
G_log         =       exp(4*s_norm.^2) + 2*exp(3*s_norm.^2) + 3*exp(2*s_norm.^2) - 6 + 3;

%------------------gamma x3---------------------%

m_gam         =       4*10^6;
cof_gam       =       0.10*4;
s_gam         =       m_gam .* cof_gam;

theta_gam     =       s_gam^2/m_gam;
k_gam         =       m_gam/theta_gam;

g_gam         =       2/sqrt(k_gam);
G_gam         =       6/k_gam + 3;

%--------------------normal x4, x5, x6, x7, x8--------------------------------------------%

mu_norm       =       [5*10^4,  2*10^8,  4*10^8,  8*10^4,  2.05*10^5];
cof_norm      =       [0.10,    0.10,    0.08,    0.15,    0.15]/1;
si_norm       =       mu_norm .* cof_norm;

g_norm        =       zeros(1,5);
G_norm        =       repmat(3,[1,5]);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu            =       [m_log, m_gam, mu_norm];
sigma         =       [s_log, s_gam, si_norm];
gamma         =       [g_log, g_gam, g_norm];
Gamma         =       [G_log, G_gam, G_norm];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cov     =     diag(sigma.^2);                 % covariance matrix        
rho     =     corrcov(cov);                   % corerlation matrix






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eigenvectors & Eigenvalues of correlation matrix

[eig_vec,eig_val]    =    eig(rho);         % eignvectors & eigenvalues

V                    =    eig_vec;          % eigenvectors
lambda               =    diag(eig_val);    % eigenvalues






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Diagonal matrix of standard deviations

sq_D  =  sqrt(cov);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples

samples  = [];
for i = 1:n
    
    xi_p     =   mu + (sqrt(n) * sq_D * V(:,i))';
    xi_m     =   mu - (sqrt(n) * sq_D * V(:,i))';
    
    samples  =   [samples; xi_p; xi_m];
    
end
samples;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L_sam = size(samples,1);

L        =       3000;
del      =       2000;

y = [];
for i = 1:L_sam
    
    x = samples(i,:);
    f = del - ((x(1).^2 * L)./(2*x(4).*x(8)) + (x(2).^2 * L.^3)./(6*x(5).*x(8)) + (x(3).^2*L)./(2*x(6).*x(7)));
    y = [y; f];
    
end
y;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    new_y = y.^i;
    
    mom = 0;
    for j = 1:n
        
        mom     = mom + lambda(j) * (new_y(2*j-1) + new_y(2*j))/2;
        
    end
    
    raw_mom = [raw_mom; mom/sum(lambda)];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4



[mean_y, std_y, ske_y, kur_y]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
 
mean_mcs = 983.2769;
std_mcs  = 159.2404;
ske_mcs  = -0.4952;
kur_mcs  = 3.4333;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 951.8957;
std_mcs  = 332.9168;
ske_mcs  = -1.0197;
kur_mcs  = 4.8489;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 821.7305;
std_mcs  = 786.6264;
ske_mcs  = -2.2705;
kur_mcs  = 12.8400;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

