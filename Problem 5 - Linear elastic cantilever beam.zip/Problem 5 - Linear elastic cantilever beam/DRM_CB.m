
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Cantilever beam

clear all
close all
clc


%%%%%%%%%%%%%%%%%%%
% no of inputs

n       =    8;



%%%%%%%%%%%%%%%%%%%%%%%%%
% no of samples

N       =    4;




%----------------lognormal (x1, x2)-----------------%

m_log         =       [8000,   1500];
cof_log       =       [0.25,  0.25]/4;
s_log         =       m_log .* cof_log;
v_log         =       s_log.^2;

m_norm        =       log(m_log.^2./sqrt(v_log + m_log.^2));
s_norm        =       sqrt(log(v_log./m_log.^2 + 1));



%------------------gamma x3---------------------%

m_gam         =       4*10^6;
cof_gam       =       0.10*1;
s_gam         =       m_gam .* cof_gam;

theta_gam     =       s_gam^2/m_gam;
k_gam         =       m_gam/theta_gam;



%--------------------normal x4, x5, x6, x7, x8--------------------------------------------%

mu_norm       =       [5*10^4,  2*10^8,  4*10^8,  8*10^4,  2.05*10^5];
cof_norm      =       [0.10,    0.10,    0.08,    0.15,    0.15]/4;
si_norm       =       mu_norm .* cof_norm;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu            =       [m_log, m_gam, mu_norm];
sigma         =       [s_log, s_gam, si_norm];




%%%%%%%%%%%%%%%%%%%%%%
% no of output moments

m       =    4;


%%%%%%%%%%%%%%%%%%%%
% s-variate

s       =    3;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% moments mu_j,i for each x_j   lognormal

moments_l = [];

for i = 0:2*N-1
    
    mom_l      =   exp(i.*m_norm + 0.5*i^2*s_norm.^2);
    
    moments_l  =  [moments_l; mom_l];
    
end

moments_l;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% moments mu_j,i for each x_j

moments_g = [];

for i = 0:2*N-1
    
    mom      =   theta_gam.^i .* gamma(k_gam+i)./gamma(k_gam);
    
    moments_g  =  [moments_g; mom];
    
end

moments_g;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% input moments mu_j,i for each x_j   normal

syms muu sigmaa t

mgf   =   exp(muu * t + 0.5 * sigmaa^2 * t^2);

mom = [];
for i = 0:2*N-1
    
    di   =   diff(mgf, t, i);
    
    mo   =   vpa(subs(di, t, 0));
    
    mom  =   [mom; mo];
    
end
mom;  


mu_0 = repmat(1,[1,5]);
mu_1 = mu_norm;
mu_2 = mu_norm.^2 + si_norm.^2;
mu_3 = mu_norm.^3 + 3 * mu_norm .* si_norm.^2;
mu_4 = mu_norm.^4 + 6 * mu_norm.^2 .* si_norm.^2 + 3 * si_norm.^4;
mu_5 = mu_norm.^5 + 10 * mu_norm.^3 .* si_norm.^2 + 15 * mu_norm .* si_norm.^4;
mu_6 = mu_norm.^6 + 15 * mu_norm.^4 .* si_norm.^2 + 45 * mu_norm.^2 .* si_norm.^4 + 15 * si_norm.^6;
mu_7 = mu_norm.^7 + 21 * mu_norm.^5 .* si_norm.^2 + 105 * mu_norm.^3 .* si_norm.^4 + 105 .* mu_norm .* si_norm.^6;
mu_8 = mu_norm.^8 + 28 * mu_norm.^6 .* si_norm.^2 + 210 * mu_norm.^4 .* si_norm.^4 + 420 * mu_norm.^2 .* si_norm.^6 + 105 * si_norm.^8;
mu_9 = mu_norm.^9 + 36 * mu_norm.^7 .* si_norm.^2 + 378 * mu_norm.^5 .* si_norm.^4 + 1260 * mu_norm.^3 .* si_norm.^6 + 945 * mu_norm .* si_norm.^8;
mu_10= mu_norm.^10 + 45 .* mu_norm.^8 .* si_norm.^2 + 630 * mu_norm.^6 .* si_norm.^4 + 3150 * mu_norm.^4 .* si_norm.^6 + 4725 * mu_norm.^2 .* si_norm.^8 + 945 * si_norm.^10;
mu_11= mu_norm.^11 + 55 * mu_norm.^9 .* si_norm.^2 + 990 * mu_norm.^7 .* si_norm.^4 + 6930 * mu_norm.^5 .* si_norm.^6 + 17325 * mu_norm.^3 .* si_norm.^8 + 10395 * mu_norm .* si_norm.^10;
mu_12= mu_norm.^12 + 66 * mu_norm.^10 .* si_norm.^2 + 1485 * mu_norm.^8 .* si_norm.^4 + 13860 * mu_norm.^6 .* si_norm.^6 + 51975 * mu_norm.^4 .* si_norm.^8 + 62370 * mu_norm.^2 .* si_norm.^10 + 10395 * si_norm.^12;
mu_13= mu_norm.^13 + 78 * mu_norm.^11 .* si_norm.^2 + 2145 * mu_norm.^9 .* si_norm.^4 + 25740 * mu_norm.^7 .* si_norm.^6 + 135135 * mu_norm.^5 .* si_norm.^8 + 270270 * mu_norm.^3 .* si_norm.^10 + 135135 * mu_norm .* si_norm.^12;


moments_n = [mu_0; mu_1; mu_2; mu_3; mu_4; mu_5; mu_6; mu_7];%; mu_8; mu_9];%; mu_10; mu_11; mu_12; mu_13];


moments  =  [moments_l, moments_g, moments_n];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights: w_j,i and Points: x_j,i

points  = [];
weights = [];

for j = 1:n                            % for each j = 1, 2, 3, ... , n
    
    moments_j   =   moments(:,j);      % moments of x_j = x1, x2,...
    
    
    
    
    
    
    
    %------------------------%
    % LHS matrix of moments
    
    LHS = [];    
    for i = 1:N
        
        vec     =   moments_j(i:N+i-1);
        
        
        row = [];        
        for k = 1:length(vec)
            
            row   =   [row, (-1)^(k-1) * vec(end-k+1)];
            
        end
        
        Row   =   row;        
        LHS   =   [LHS; Row];
        
            
    end    
    LHS;
    
    
    
    
    
    %------------------------------%
    % RHS column matrix of moments
    
    RHS    =    moments_j(N+1:2*N);
    
    
    
    
    
    
    
    %------------------------------%
    % r_j,1 ; r_j,2, r_j,3 ; ...
    
    r_j    =    linsolve(LHS, RHS);
    
    
    
    
    
    
    %-------------------------%
    % x_j,1 ; x_j,2 ; x_j,3  
    
    coeff = 1;    
    for k = 1:length(r_j)
        
        coeff    =   [coeff, (-1)^k * r_j(k)];
        
    end
    
    x_j    =   roots(coeff);    
    points = [points, x_j];
    
    
    
    
    %-----------------------------%
    % Denominators of each w_j,i
    
    deno = [];
    for i = 1:N
        
        pr   =   1;
        
        for k = 1:N
            if (k~=i)                
                pr    =    pr * (x_j(i) - x_j(k));
            end            
        end
        
        deno    =    [deno; pr];
        
    end
    deno;
    
    
    
    
    
    
    
    %--------------------------------------%
    % moments in numerator of each w_j,i
    
    num_mu  =  flip(moments_j(1:N))';
    
    for i = 1:length(num_mu)
        
        if (rem(i,2)==0)
            
            num_mu(i)   =   - num_mu(i);
            
        end
        
    end    
    num_mu;
    
    
    
    
    
    
    
    
    %----------------------------------%
    % q_j,ik in numerators of w_j,i
    
    q_ik = [];
    
    for i = 1:N
        
        
        
        q0  =  1;
        
        q   =  [];       
        for k = 1:N-1
            
            q_k   =   r_j(k) - x_j(i) * q0;
            q0    =   q_k;
            q     =   [q; q0];
            
        end
        
        
        
        
        q_ik   =   [q_ik, q];
        
    end
            
    num_q   =   [repmat(1, [1,N]); q_ik]';   
    
    
    
    
    
    
    
    
    
    
    %----------------------------%
    % numerator in w_j,i
    
    num   =   sum(num_mu .* num_q, 2);
    
    
    
    
    %---------------------------%
    % Weights w_j,i
    
    w_j       =   num./deno;
    
    weights   =   [weights, w_j];
        
end

points    =   points;
weights   =   weights;














%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculating all expectations & their powers

for i = 1:s   
    nCs(i) = nchoosek(n,i);    
end
nCs;

max_nCs  =  max(nCs);

all_exp = [];
for i = 1:s
    
    C = nchoosek([1:n], i);
    
    % E[Z(x1)],         E[Z(x2)],         E[Z(x3)]                             i = 1
    % E[Z(x1, x2)],     E[Z(x1, x3)],     E[Z(x2,x3)]                          i = 2
    % E[Z(x1, x2, x3)], E[Z(x1, x2, x4)], E[Z(x1, x3, x4)], E[Z(x2, x3, x4)]   i = 3
    
    
    
    
    
    
    %---------------------------------------------------------------------%
    Exp_j_m = [];
    
    for j = 1:length(C)
        
        vec = C(j,:);
        
        % i = 1
        % E[Z(x1)]  j = 1
        % E[Z(x2)]  j = 2
        % E[Z(x3)]  j = 3
        
        % i = 2
        % E[Z(x1, x2)]  j = 1
        % E[Z(x1, x3)]  j = 2
        % E[Z(x2, x3)]  j = 3
        
        % i = 3
        % E[Z(x1, x2, x3)]  j = 1
        % E[Z(x1, x2, x4)]  j = 1
        % E[Z(x1, x3, x4)]  j = 1
        % E[Z(x2, x3, x4)]  j = 1
        
        
        
        
        
        
        
        %--------Collection of weights & points---------%
        
        Ws   = [];
        x_js = [];
        for k = 1:length(vec)
            
            col         =     vec(k);
            
            wj_call     =     weights(:,col);            
            Ws          =     [Ws, wj_call];
            
            xj_call     =     points(:,col);
            x_js        =     [x_js, xj_call];
            
        end
        
        Ws;
        
        x_js;
        
        %--------Collection of weights & points---------%
        
        
        
        
        
        
        %------------------Product of weights--------------%
        prod_w   =   1;
        
        L        =   length(vec);

        for i1 = 1:L
            
            w_call   =   Ws(:,i1);
            
            
            
            
            new_w  = [];
            for i2 = 1:N                      % no. of quad points
                
                w          =   w_call(i2);
                
                
                rep_w      =   repmat(w, [N^(L-i1), 1]);
                
                new_w      =   [new_w; rep_w];
                
                rep_new_w  =   repmat(new_w, [N^(i1-1), 1]);
                 
            end
            
            rep_new_w;
            
            
            
            
            
            prod_w    =   prod_w .* rep_new_w;
            
        end
        final_w       =   prod_w;
        %------------------Product of weights--------------%
  
        
        
        
        
        
        
        
        
        
        %----------------------samples-----------------------%
        %-----------------------------------------%
        final_xj = [];
        for i1 = 1:length(vec)
            
            xj_call   =   x_js(:,i1);
            
            
            
            
            new_xj = [];
            for i2 = 1:N                     % no. of quad points
                
                xj          =   xj_call(i2);
                
                
                rep_xj      =   repmat(xj, [N^(L-i1), 1]);
                
                new_xj      =   [new_xj; rep_xj];
                
                rep_new_xj  =   repmat(new_xj, [N^(i1-1), 1]);
                 
            end
            
            
            
         
            final_xj = [final_xj, rep_new_xj];
                   
        end
        
        final_xj;
        %---------------------------------------%
        %--------------------------------------%
        L2       =     size(final_xj,1);
        
        sample   =     mu;
        
        samples = [];
        for i1 = 1:L2
            
            row_call           =     final_xj(i1,:);
            
            
            
            for i2 = 1:L
                
                position             =    vec(i2);
                
                entry_call           =    row_call(i2);
                
                sample(position)     =    entry_call;
                
            end
            
            
            
            samples = [samples; sample];
            
        end
        samples;       
        %-------------------------------------%
        %----------------------------samples----------------------%
        
        
        
        
        
        %----------------function----------------------%
        
        LL       =       3000;
        del      =       2000;

        final_y = [];
        for k = 1:L2
            
            x       = samples(k,:);
            
            f       = del - ((x(1).^2 * LL)./(2*x(4).*x(8)) + (x(2).^2 * LL.^3)./(6*x(5).*x(8)) + (x(3).^2*LL)./(2*x(6).*x(7)));
            
            final_y = [final_y; f];
            
        end
        final_y;
        
        %----------------function----------------------%
        
        
        
        
        
        
        
        
        %-----------------Expectations ^ m------------------------%
        M = [1:m];
        
        Exp_1 = [];
        for k = 1:m
            
            Exp_j      =   sum(final_w .* final_y.^k);
            
            Exp_1      =   [Exp_1; Exp_j];
            
        end
        Exp_1;
        %-----------------Expectations ^ m------------------------%
        
        
        
        
        
        Exp_j_m = [Exp_j_m, Exp_1];
        
    end  %----- j
    Exp_j_m;
    %-----------------------------------------------------------------------%
    
    
     
        
    %----------collection of all exp---------------%
    if (s>1)
        no_col    =  max_nCs - nchoosek(n,i);
        zeromat   =  zeros(m, no_col);
        Exp_j_m   =  [Exp_j_m, zeromat];
    end

        
    all_exp         =  [all_exp; Exp_j_m];
    %----------collection of all exp---------------%
    
end %------ i
all_exp;

% E[Z(x1)],      E[Z(x2)],      E[Z(x3)]
% E[Z(x1)]^2,    E[Z(x2)]^2,    E[Z(x3)]^2

% E[Z(x1,x2)],   E[Z(x1,x3)],   E[Z(x2,x3)]
% E[Z(x1,x2)]^2, E[Z(x1,x3)]^2, E[Z(x2,x3)]^2








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Z(mu) = y(mu), y(mu)^2, ..., y(mu)^m

LL        =       3000;
del       =       2000;

y_mean     =   del - ((mu(1).^2 * LL)./(2*mu(4).*mu(8)) + (mu(2).^2 * LL.^3)./(6*mu(5).*mu(8)) + (mu(3).^2*LL)./(2*mu(6).*mu(7)));

for i = 1:m
    
    z_mean(i)    =    y_mean^i;
    
end

z_mean  =  z_mean';








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Raw Moments of y(x)

raw_mom = [];
for i = 1:m
    
    
    Exp_2       =     all_exp(i:m:end,:);
    
    
    %--------------------------------------------%
    SUM = 0;
    for j = 0:s
        
        b       =    (-1)^j * nchoosek(n-s+j-1,j);
        
        if (j==s)
            
            E   =    z_mean(i);
            
        else
            
            E   =    sum(Exp_2(end-j,:));
            
        end
        
        SUM     =    SUM + (b*E);
        
    end
    %-------------------------------------------%
    
    
    
    raw_mom        =  [raw_mom; SUM];
        
    
end
raw_mom;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Central moments of y(x)

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4





[mean_y, std_y, ske_y, kur_y]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
 
mean_mcs = 983.2769;
std_mcs  = 159.2404;
ske_mcs  = -0.4952;
kur_mcs  = 3.4333;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 951.8957;
% std_mcs  = 332.9168;
% ske_mcs  = -1.0197;
% kur_mcs  = 4.8489;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 821.7305;
% std_mcs  = 786.6264;
% ske_mcs  = -2.2705;
% kur_mcs  = 12.8400;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

