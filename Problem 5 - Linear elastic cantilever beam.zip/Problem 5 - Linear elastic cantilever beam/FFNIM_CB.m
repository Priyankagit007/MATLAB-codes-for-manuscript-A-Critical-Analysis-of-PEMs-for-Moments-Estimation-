
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Linear elastic cantilever beam

clear all
close all
clc


n = 8;



%----------------lognormal (x1, x2)-----------------%

m_log         =       [8000,   1500];
cof_log       =       [0.25,  0.25]/1;
s_log         =       m_log .* cof_log;
v_log         =       s_log.^2;

m_norm        =       log(m_log.^2./sqrt(v_log + m_log.^2));
s_norm        =       sqrt(log(v_log./m_log.^2 + 1));

g_log         =       (exp(s_norm.^2) + 2) .* sqrt(exp(s_norm.^2) - 1);
G_log         =       exp(4*s_norm.^2) + 2*exp(3*s_norm.^2) + 3*exp(2*s_norm.^2) - 6 + 3;

%------------------gamma x3---------------------%

m_gam         =       4*10^6;
cof_gam       =       0.10*4;
s_gam         =       m_gam .* cof_gam;

theta_gam     =       s_gam^2/m_gam;
k_gam         =       m_gam/theta_gam;

g_gam         =       2/sqrt(k_gam);
G_gam         =       6/k_gam + 3;

%--------------------normal x4, x5, x6, x7, x8--------------------------------------------%

mu_norm       =       [5*10^4,  2*10^8,  4*10^8,  8*10^4,  2.05*10^5];
cof_norm      =       [0.10,    0.10,    0.08,    0.15,    0.15]/1;
si_norm       =       mu_norm .* cof_norm;

g_norm        =       zeros(1,5);
G_norm        =       repmat(3,[1,5]);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu            =       [m_log, m_gam, mu_norm];
sigma         =       [s_log, s_gam, si_norm];
gamma         =       [g_log, g_gam, g_norm];
Gamma         =       [G_log, G_gam, G_norm];






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha 

alpha_1      =     (gamma - sqrt(4 * Gamma - 3 * gamma.^2))/2;
alpha_2      =     zeros(1, n);
alpha_3      =     (gamma + sqrt(4 * Gamma - 3 * gamma.^2))/2;


alpha_x1     =     [alpha_1(1), alpha_2(1), alpha_3(1)];
alpha_x2     =     [alpha_1(2), alpha_2(2), alpha_3(2)];
alpha_x3     =     [alpha_1(3), alpha_2(3), alpha_3(3)];
alpha_x4     =     [alpha_1(4), alpha_2(4), alpha_3(4)];
alpha_x5     =     [alpha_1(5), alpha_2(5), alpha_3(5)];
alpha_x6     =     [alpha_1(6), alpha_2(6), alpha_3(6)];
alpha_x7     =     [alpha_1(7), alpha_2(7), alpha_3(7)];
alpha_x8     =     [alpha_1(8), alpha_2(8), alpha_3(8)];






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights

w1   =   ((4 * Gamma - 3 * gamma.^2) + gamma .* sqrt(4 * Gamma - 3 * gamma.^2)) ./ (2 * (4 * Gamma - 3 * gamma.^2) .* (Gamma - gamma.^2));
w2   =   (Gamma - gamma.^2 - 1) ./ (Gamma - gamma.^2);
w3   =   ((4 * Gamma - 3 * gamma.^2) - gamma .* sqrt(4 * Gamma - 3 * gamma.^2)) ./ (2 * (4 * Gamma - 3 * gamma.^2) .* (Gamma - gamma.^2));


w_x1  =  [w1(1), w2(1), w3(1)];
w_x2  =  [w1(2), w2(2), w3(2)];
w_x3  =  [w1(3), w2(3), w3(3)];
w_x4  =  [w1(4), w2(4), w3(4)];
w_x5  =  [w1(5), w2(5), w3(5)];
w_x6  =  [w1(6), w2(6), w3(6)];
w_x7  =  [w1(7), w2(7), w3(7)];
w_x8  =  [w1(8), w2(8), w3(8)];

w  =  [];
for i1 = 1:3    
    w_1   =   w_x1(i1);
    
    for i2 = 1:3        
        w_2    =    w_x2(i2);
        
        for i3 = 1:3            
            w_3    =   w_x3(i3);
            
            for i4 = 1:3
                w_4   =   w_x4(i4);
                
                for i5 = 1:3
                    w_5  =  w_x5(i5);
                    
                    for i6 = 1:3
                        w_6  =  w_x6(i6);
                        
                        for i7 = 1:3
                            w_7  =  w_x7(i7);         
                            
                            for i8 = 1:3
                                w_8  =  w_x8(i8);
            
                                we     =   w_1 * w_2 * w_3 * w_4 * w_5 * w_6 * w_7 * w_8;            
                                w      =   [w; we];
                            end
                        end
                    end
                end
            end            
        end        
    end    
end
w;






 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples

samples  =  [];
for i1 = 1:3    
    vec1   =   mu(1)  +  alpha_x1(i1) * sigma(1);
    
    for i2 = 1:3        
        vec2    =    mu(2)  +  alpha_x2(i2) * sigma(2);
        
        for i3 = 1:3            
            vec3   =   mu(3)   +   alpha_x3(i3) * sigma(3);
            
            for i4 = 1:3
                vec4       =  mu(4)   +  alpha_x4(i4) * sigma(4);
                
                for i5 = 1:3
                    vec5       =  mu(5)   +  alpha_x5(i5) * sigma(5);
                    
                    for i6 = 1:3
                        vec6       =  mu(6)   +  alpha_x6(i6) * sigma(6);
                        
                        for i7 = 1:3
                            vec7       =  mu(7)   +  alpha_x7(i7) * sigma(7);
                            
                            for i8 = 1:3
                                vec8  =  mu(8) + alpha_x8(i8) * sigma(8);
                                        
                                s          =   [vec1,  vec2,  vec3, vec4, vec5, vec6, vec7, vec8];            
                                samples    =   [samples; s];
                            end
                        end
                    end
                end
            end
        end        
    end
end
samples;









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L_sam = size(samples,1);

L        =       3000;
del      =       2000;

y = [];
for i = 1:L_sam
    
    x = samples(i,:);
    f = del - ((x(1).^2 * L)./(2*x(4).*x(8)) + (x(2).^2 * L.^3)./(6*x(5).*x(8)) + (x(3).^2*L)./(2*x(6).*x(7)));
    y = [y; f];
    
end
y;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m  =  4;

raw_mom = [];
for i = 1:m
    
    mom     = sum(w .* y.^i);
    raw_mom = [raw_mom; mom];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4
[mean_y, std_y, ske_y, kur_y]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
 
mean_mcs = 983.2769;
std_mcs  = 159.2404;
ske_mcs  = -0.4952;
kur_mcs  = 3.4333;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 951.8957;
std_mcs  = 332.9168;
ske_mcs  = -1.0197;
kur_mcs  = 4.8489;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 821.7305;
std_mcs  = 786.6264;
ske_mcs  = -2.2705;
kur_mcs  = 12.8400;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

