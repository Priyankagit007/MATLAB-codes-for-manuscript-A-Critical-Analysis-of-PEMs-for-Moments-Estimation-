
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Linear elastic cantilever beam

clear all
close all
clc


n = 8;



%----------------lognormal (x1, x2)-----------------%

m_log         =       [8000,   1500];
cof_log       =       [0.25,  0.25]/1;
s_log         =       m_log .* cof_log;
v_log         =       s_log.^2;

m_norm        =       log(m_log.^2./sqrt(v_log + m_log.^2));
s_norm        =       sqrt(log(v_log./m_log.^2 + 1));

g_log         =       (exp(s_norm.^2) + 2) .* sqrt(exp(s_norm.^2) - 1);
G_log         =       exp(4*s_norm.^2) + 2*exp(3*s_norm.^2) + 3*exp(2*s_norm.^2) - 6 + 3;

%------------------gamma x3---------------------%

m_gam         =       4*10^6;
cof_gam       =       0.10*4;
s_gam         =       m_gam .* cof_gam;

theta_gam     =       s_gam^2/m_gam;
k_gam         =       m_gam/theta_gam;

g_gam         =       2/sqrt(k_gam);
G_gam         =       6/k_gam + 3;

%--------------------normal x4, x5, x6, x7, x8--------------------------------------------%

mu_norm       =       [5*10^4,  2*10^8,  4*10^8,  8*10^4,  2.05*10^5];
cof_norm      =       [0.10,    0.10,    0.08,    0.15,    0.15]/1;
si_norm       =       mu_norm .* cof_norm;

g_norm        =       zeros(1,5);
G_norm        =       repmat(3,[1,5]);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu            =       [m_log, m_gam, mu_norm];
sigma         =       [s_log, s_gam, si_norm];
gamma         =       [g_log, g_gam, g_norm];
Gamma         =       [G_log, G_gam, G_norm];




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cov       =     diag(sigma.^2);
rho       =     corrcov(cov);







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha +-

alpha_p   =    (gamma + sqrt(4 * Gamma - 3 * gamma.^2))/2;
alpha_m   =    (gamma - sqrt(4 * Gamma - 3 * gamma.^2))/2;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% weights +-

w_p       =    1./(alpha_p .* (alpha_p - alpha_m));
w_m       =    1./(alpha_m .* (alpha_m - alpha_p));
w0        =    1 - w_p - w_m;










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% samples  

%----------------samples xi--------------------%
e  =  eye(n,n);

sam_1 = [];
for i = 1:n
    
    xi_p    =    mu + alpha_p .* sigma .* e(i,:);
    xi_m    =    mu + alpha_m .* sigma .* e(i,:);
    
    sam_1   =    [sam_1; xi_p; xi_m];
    
end
sam_1;




%------------------samples (xi,xj)------------------%
b  =  nchoosek(n,2);
C  =  nchoosek([1:n],2);


sam_2 = [];
for i = 1:b
    
    k           =   C(i,:);    
    xi_p_xj_p   =   mu + alpha_p .* sigma .* e(k(1),:) + alpha_p .* sigma .* e(k(2),:);    
    sam_2       =   [sam_2; xi_p_xj_p];
    
end
sam_2;

samples  =  [mu; sam_1; sam_2];









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L_sam = size(samples,1);

L        =       3000;
del      =       2000;

y = [];
for i = 1:L_sam
    
    x = samples(i,:);
    f = del - ((x(1).^2 * L)./(2*x(4).*x(8)) + (x(2).^2 * L.^3)./(6*x(5).*x(8)) + (x(3).^2*L)./(2*x(6).*x(7)));
    y = [y; f];
    
end
y;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Delta

rho_ij = [];
for i = 1:n-1
    
    row     =   rho(i,i+1:end);    
    rho_ij  =   [rho_ij, row];
    
end
rho_ij;



alpha_ij = [];
for i = 1:b
    
    row       =   C(i,:);    
    v         =   alpha_p(row(1)) * alpha_p(row(2));    
    alpha_ij  =   [alpha_ij, v];
    
end
alpha_ij;



delta_ij  =   rho_ij./alpha_ij;
Wpp       =   delta_ij;



del_matrix = [];
for i = 1:n
    
    vec         =    delta_ij(1:n-i);    
    k           =    [zeros(1,i-1), 1, vec];
    del_matrix  =    [del_matrix; k];    
    L           =    length(vec);    
    delta_ij    =    delta_ij(L+1:end);
    
end
del_matrix;

upper          =   triu(del_matrix,1);           % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
del_matrix     =   upper + eye(n,n) + lower;


delta_i  =  sum(del_matrix, 2);
delta    =  sum(delta_i);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Final weights

W0  =  1 - 3*n/2 + delta/2 + sum(w0);

Wp  =  w_p - delta_i' + 1;

Wm  =  w_m;








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    new_y    =  y.^i;
          
    mom      =  W0 * new_y(1) + sum(Wp .* new_y(2:2:2*n+1)') + sum(Wm .* new_y(3:2:2*n+1)') + sum(Wpp .* new_y(2*n+2:end)');
        
    raw_mom  =  [raw_mom; mom];
        
end
raw_mom;       
        

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

[mean_y, std_y, ske_y, kur_y]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
 
mean_mcs = 983.2769;
std_mcs  = 159.2404;
ske_mcs  = -0.4952;
kur_mcs  = 3.4333;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 951.8957;
std_mcs  = 332.9168;
ske_mcs  = -1.0197;
kur_mcs  = 4.8489;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 821.7305;
std_mcs  = 786.6264;
ske_mcs  = -2.2705;
kur_mcs  = 12.8400;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

