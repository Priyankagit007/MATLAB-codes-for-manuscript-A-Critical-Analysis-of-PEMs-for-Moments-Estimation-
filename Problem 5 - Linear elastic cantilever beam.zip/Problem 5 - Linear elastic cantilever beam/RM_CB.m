
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Linear elastic cantilever beam

clear all
close all
clc


n = 8;



%----------------lognormal (x1, x2)-----------------%

m_log         =       [8000,   1500];
cof_log       =       [0.25,  0.25]/1;
s_log         =       m_log .* cof_log;
v_log         =       s_log.^2;

m_norm        =       log(m_log.^2./sqrt(v_log + m_log.^2));
s_norm        =       sqrt(log(v_log./m_log.^2 + 1));

g_log         =       (exp(s_norm.^2) + 2) .* sqrt(exp(s_norm.^2) - 1);
G_log         =       exp(4*s_norm.^2) + 2*exp(3*s_norm.^2) + 3*exp(2*s_norm.^2) - 6 + 3;

%------------------gamma x3---------------------%

m_gam         =       4*10^6;
cof_gam       =       0.10*4;
s_gam         =       m_gam .* cof_gam;

theta_gam     =       s_gam^2/m_gam;
k_gam         =       m_gam/theta_gam;

g_gam         =       2/sqrt(k_gam);
G_gam         =       6/k_gam + 3;

%--------------------normal x4, x5, x6, x7, x8--------------------------------------------%

mu_norm       =       [5*10^4,  2*10^8,  4*10^8,  8*10^4,  2.05*10^5];
cof_norm      =       [0.10,    0.10,    0.08,    0.15,    0.15]/1;
si_norm       =       mu_norm .* cof_norm;

g_norm        =       zeros(1,5);
G_norm        =       repmat(3,[1,5]);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu            =       [m_log, m_gam, mu_norm];
sigma         =       [s_log, s_gam, si_norm];
gamma         =       [g_log, g_gam, g_norm];
Gamma         =       [G_log, G_gam, G_norm];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Correlation matrix

cov       =     diag(sigma.^2);
rho       =     corrcov(cov);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha +-

alpha_p   =     (gamma  + sqrt(4 + gamma.^2))/2;
alpha_m   =     (-gamma + sqrt(4 + gamma.^2))/2;


alpha_pm  =     [alpha_p; alpha_m];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights +-

wp        =     alpha_m./(alpha_p + alpha_m);
wm        =     alpha_p./(alpha_p + alpha_m);

w_pm      =     [wp; wm];





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
beta      =     [1, -1];




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples


samples = [];
for i1 = 1:2
    sam1  =  mu(1) + beta(i1) * alpha_pm(i1,1) * sigma(1);
    
    for i2 = 1:2        
        sam2   =   mu(2) +  beta(i2) * alpha_pm(i2,2) * sigma(2);
        
        for i3 = 1:2            
            sam3   =   mu(3) +  beta(i3) * alpha_pm(i3,3) * sigma(3);
            
            for i4 = 1:2
                sam4      =    mu(4) +  beta(i4) * alpha_pm(i4,4) * sigma(4);
                
                for i5 = 1:2
                    sam5      =    mu(5) +  beta(i5) * alpha_pm(i5,5) * sigma(5);
                    
                    for i6 = 1:2
                        sam6      =    mu(6) +  beta(i6) * alpha_pm(i6,6) * sigma(6);
                        
                        for i7 = 1:2
                            sam7      =    mu(7) +  beta(i7) * alpha_pm(i7,7) * sigma(7);
                            
                            for i8 = 1:2
                                sam8      =    mu(8) +  beta(i8) * alpha_pm(i8,8) * sigma(8);
            
                                samples   =   [samples; sam1, sam2, sam3, sam4, sam5, sam6, sam7, sam8];
                            end
                        end
                    end
                end
                
            end
        end        
    end    
end
samples;










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function Values

L_sam = size(samples,1);

L        =       3000;
del      =       2000;

y = [];
for i = 1:L_sam
    
    x = samples(i,:);
    f = del - ((x(1).^2 * L)./(2*x(4).*x(8)) + (x(2).^2 * L.^3)./(6*x(5).*x(8)) + (x(3).^2*L)./(2*x(6).*x(7)));
    y = [y; f];
    
end
y;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights

%-----------Uncorrelated weights--------------%
W1 = [];
for i1 = 1:2
    w1  =  w_pm(i1,1);
    
    for i2 = 1:2
        w2  =  w_pm(i2,2);
        
        for i3 = 1:2
            w3   =  w_pm(i3,3);
            
            for i4 = 1:2
                w4   =   w_pm(i4,4);
                
                for i5 = 1:2
                    w5   =   w_pm(i5,5);
                    
                    for i6 = 1:2
                        w6   =   w_pm(i6,6);
                        
                        for i7 = 1:2
                            w7   =   w_pm(i7,7);
                            
                            for i8 = 1:2
                                w8  =  w_pm(i8,8);
            
                                w    =  w1 * w2 * w3 * w4 * w5 * w6 * w7 * w8;            
                                W1   =  [W1; w];
                            end
                        end
                    end
                end
            end
        end
    end
end
W1;





%---------------rho_ij------------------%
rho_ij = [];
for i = 1:n-1
    
    vec     =     rho(i,i+1:end);
    rho_ij  =     [rho_ij, vec];
    
end
rho_ij;




%--------------denominator--------------%
pr = 1;
for i = 1:n

    pr   =    pr * (1 + (gamma(i)/2)^2);
    
end
Deno = sqrt(pr);




%----------------a_ij---------------%
aij    =    (rho_ij/2^n) / Deno;





%--------------Correlated weights---------------%
all_sign = [];
for i1 = 1:2
    sign1 = beta(i1);
    for i2 = 1:2
        sign2 = beta(i2);
        for i3 = 1:2
            sign3 = beta(i3);
            for i4 = 1:2
                sign4 = beta(i4);
                for i5 = 1:2
                    sign5 = beta(i5);
                    for i6 = 1:2
                        sign6 = beta(i6);
                        for i7 = 1:2
                            sign7 = beta(i7);
                            for i8 = 1:2
                                sign8 = beta(i8);
                                all_sign  = [all_sign; sign1, sign2, sign3, sign4, sign5, sign6, sign7, sign8];
                            end
                        end
                    end
                end
            end
        end
    end
end
all_sign;




C     =  nchoosek([1:n],2);
b     =  nchoosek(n,2);



%-------------Product of two signs--------------%
prod_sign_aij = [];
for i = 1:2^n
    
    vec   =   all_sign(i,:);   
    
    sign_aij = [];
    for j = 1:b
        
        k          =    C(j,:);
        prod       =    vec(k(1)) * vec(k(2));        
        sign_aij   =    [sign_aij, prod];
        
    end
    
    prod_sign_aij  =    [prod_sign_aij; sign_aij];
    
end
prod_sign_aij;

W2       =  prod_sign_aij .* aij;


%--------------Final weights-------------------%
Weights  =  sum([W1, W2],2);    % columnwise sum








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    mom     = sum(Weights .* y.^i);
    raw_mom = [raw_mom; mom];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

[mean_y, std_y, ske_y, kur_y]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
 
mean_mcs = 983.2769;
std_mcs  = 159.2404;
ske_mcs  = -0.4952;
kur_mcs  = 3.4333;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 951.8957;
std_mcs  = 332.9168;
ske_mcs  = -1.0197;
kur_mcs  = 4.8489;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

mean_mcs = 821.7305;
std_mcs  = 786.6264;
ske_mcs  = -2.2705;
kur_mcs  = 12.8400;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]

