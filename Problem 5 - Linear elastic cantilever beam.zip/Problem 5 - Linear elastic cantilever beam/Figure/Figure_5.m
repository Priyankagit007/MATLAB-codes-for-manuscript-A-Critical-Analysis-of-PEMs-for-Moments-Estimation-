
% Cantilever beam

clc
clear all
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Evans method

% EM_1 = [1.2320   -0.8892  -75.4487   -0.4190];
% EM_2 = [5.1571   -3.4861  -63.9221    4.5312];
% EM_3 = [24.9099  -12.6026  -27.5951   38.8490];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FFNI method

FFNIM_1 = [-0.0007    0.0225    1.2541    6.4598];
FFNIM_2 = [0.0095    0.0521    4.7008   20.5190];
FFNIM_3 = [0.0389    0.0441   15.3275   48.4585];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Harr method

HM_1 = [-0.0012    0.7404  -70.9199 -105.1438];
HM_2 = [0.0015    2.8829  -57.0334  -63.1352];
HM_3 = [-0.0578   10.7621  -15.2998   21.9223];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Li method

LM_1 = [-0.0023    0.4269   24.1526   22.9363];
LM_2 = [-0.0182    1.6453   26.4951   37.5611];
LM_3 = [-0.5008    6.1468   34.7484   64.9261];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified Harr method

MHM_1 = [-0.0012    0.7404  -70.9199 -105.1438];
MHM_2 = [0.0015    2.8829  -57.0334  -63.1352];
MHM_3 = [-0.0578   10.7621  -15.2998   21.9223];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified Rosenblueth method

MRM_1 = [-0.0028    0.6720   77.3690   74.7038];
MRM_2 = [-0.0258    2.5819   77.1641   80.2489];
MRM_3 = [-0.6510    9.2988   76.9221   89.6346];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Zhao and Ono method

ZOM_1 = [-0.0023    0.3369   12.8328   10.6698];
ZOM_2 = [-0.0182    1.3939   20.6492   33.2173];
ZOM_3 = [-0.4889    4.9940   13.8525   24.4052];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rosenblueth method

RM_1 = [-0.0011    0.2694   54.4750   59.8189];
RM_2 = [0.0017    1.0172   55.4787   67.9027];
RM_3 = [-0.1328    3.6451   58.9654   81.9878];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DRM

DRM_1 = [-0.0007    0.0224    0.0655    0.0916];
DRM_2 = [0.0097    0.0500    0.2046    0.1570];
DRM_3 = [0.0512   -0.0160    0.4277    2.0977];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MEan

y1 = abs([RM_1(1) HM_1(1) MHM_1(1) LM_1(1) MRM_1(1) ZOM_1(1) FFNIM_1(1) DRM_1(1);  RM_2(1) HM_2(1) MHM_2(1) LM_2(1) MRM_2(1) ZOM_2(1) FFNIM_2(1) DRM_2(1); RM_3(1) HM_3(1) MHM_3(1) LM_3(1) MRM_3(1) ZOM_3(1) FFNIM_3(1) DRM_3(1)]);
y2 = abs([RM_1(2) HM_1(2) MHM_1(2) LM_1(2) MRM_1(2) ZOM_1(2) FFNIM_1(2) DRM_1(2);  RM_2(2) HM_2(2) MHM_2(2) LM_2(2) MRM_2(2) ZOM_2(2) FFNIM_2(2) DRM_2(2); RM_3(2) HM_3(2) MHM_3(2) LM_3(2) MRM_3(2) ZOM_3(2) FFNIM_3(2) DRM_3(2)]);
y3 = abs([RM_1(3) HM_1(3) MHM_1(3) LM_1(3) MRM_1(3) ZOM_1(3) FFNIM_1(3) DRM_1(3);  RM_2(3) HM_2(3) MHM_2(3) LM_2(3) MRM_2(3) ZOM_2(3) FFNIM_2(3) DRM_2(3); RM_3(3) HM_3(3) MHM_3(3) LM_3(3) MRM_3(3) ZOM_3(3) FFNIM_3(3) DRM_3(3)]);
y4 = abs([RM_1(4) HM_1(4) MHM_1(4) LM_1(4) MRM_1(4) ZOM_1(4) FFNIM_1(4) DRM_1(4);  RM_2(4) HM_2(4) MHM_2(4) LM_2(4) MRM_2(4) ZOM_2(4) FFNIM_2(4) DRM_2(4); RM_3(4) HM_3(4) MHM_3(4) LM_3(4) MRM_3(4) ZOM_3(4) FFNIM_3(4) DRM_3(4)]);









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

color_matrix = [
    % 0.0 0.5 0.5; 
    0.0 0.8 0.8; 
    0.5 0.5 0.0;
    0.8 0.8 0.0; 
    0.9 0.54 0.0; 
    0.40 0.40 0.70; 
    0.60 0.40 0.80;
    0.6 0.10 0.10; 
    1.0 0.30 0.30  
];

% 1. Create a tiled chart layout
figure;
tcl = tiledlayout(2,2); % Adjust rows and columns as needed



% 2. Plot your data in different tiles
nexttile;
b1 = bar(y1, 'FaceColor', 'flat');
for k = 1:size(y1,2)
    b1(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'Case 1','Case 2', 'Case 3'});
ylabel('Relative error, $\mathcal{E}_{1}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)


nexttile;
b2 = bar(y2, 'FaceColor','flat');
for k = 1:size(y2,2)
    b2(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'Case 1','Case 2', 'Case 3'});
ylabel('Relative error, $\mathcal{E}_{2}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



nexttile;
b3 = bar(y3, 'FaceColor','flat');
for k = 1:size(y3,2)
    b3(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'Case 1','Case 2', 'Case 3'});
ylabel('Relative error, $\mathcal{E}_{3}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



nexttile;
b4 = bar(y4, 'FaceColor','flat');
for k = 1:size(y4,2)
    b4(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'Case 1','Case 2', 'Case 3'});
ylabel('Relative error, $\mathcal{E}_{4}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



% 3. Create a single legend for all plots
hL = legend(b1, 'RM ($\mathcal{N}$ = 256)', 'HM ($\mathcal{N}$ = 16)', 'MHM ($\mathcal{N}$ = 16)', 'LM ($\mathcal{N}$ = 17)', 'MRM ($\mathcal{N}$ = 17)', 'ZOM, v=3, 5 ($\mathcal{N}$ = 17, 33)', 'FFNIM ($\mathcal{N}$ = 6561)', 'Trivariate DRM, v=4 ($\mathcal{N}$ = 4065)', 'Location', 'south','Orientation','horizontal','NumColumns',4,'Interpreter','latex'); % You can specify an initial location here
set(gca,'FontName','Arial','linewidth',1.1)

% 4. Move the legend to the right side using the Layout property
hL.Layout.Tile = 'south';
hL.ItemTokenSize = [16 16];


set(gcf,'position',[100,100,650,500])
str = 'Prob_5_LECB';
savePDF(str)

