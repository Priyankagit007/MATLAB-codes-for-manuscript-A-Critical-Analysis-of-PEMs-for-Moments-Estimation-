
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Cantilever

clear all
close all
clc

n         =     3;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu_c       =      [2222.64,  4445.28,  200];
sigma_c    =      [444.5,  444.5,  10]*2;
gamma_c    =      zeros(1,n);
Gamma_c    =      repmat(3,[1,n]);

rh       =      0.5;
rho_ij   =      [0, rh, rh];



cov = [];
for i = 1:n
    
    vec         =    rho_ij(1:n-i) .* sigma_c(i) .* sigma_c(i+1:end);   
    k           =    [zeros(1,i-1), sigma_c(i)^2, vec];
    cov         =    [cov; k];    
    L           =    length(vec);    
    rho_ij      =    rho_ij(L+1:end);
    
end
cov;

di             =   diag(cov);
upper          =   triu(cov,1);                  % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
cov            =   upper + diag(di) + lower;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Rosenblatt transformation

mu1  =  mu_c(1);
mu2  =  mu_c(2);
mu3  =  mu_c(3);


s1   =  sigma_c(1);
s2   =  sigma_c(2);
s3   =  sigma_c(3);

lam11  =  cov(1,1);
lam12  =  cov(1,2);
lam13  =  cov(1,3);

lam21  =  cov(2,1);
lam22  =  cov(2,2);
lam23  =  cov(2,3);

lam31  =  cov(3,1);
lam32  =  cov(3,2);
lam33  =  cov(3,3);





lam_2  =  [lam11, lam12;
           lam21, lam22];

lam_3  =  [lam11, lam12, lam13; 
           lam21, lam22, lam23; 
           lam31, lam32, lam33];


lam_31_3    =      det([lam12, lam13; lam22, lam23]);
lam_32_3    =      -det([lam11, lam13; lam21, lam23]);
lam_33_3    =      det(lam_2);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input statistical moments of independent r.v - Y1, Y2, ...

mu       =     zeros(1,n);
sigma    =     repmat(1,[1,n]);
gamma    =     zeros(1,n);
Gamma    =     repmat(3,[1,n]);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha 

alpha_1      =     (gamma - sqrt(4 * Gamma - 3 * gamma.^2))/2;
alpha_2      =     zeros(1, n);
alpha_3      =     (gamma + sqrt(4 * Gamma - 3 * gamma.^2))/2;


alpha_x1     =     [alpha_1(1), alpha_2(1), alpha_3(1)];
alpha_x2     =     [alpha_1(2), alpha_2(2), alpha_3(2)];
alpha_x3     =     [alpha_1(3), alpha_2(3), alpha_3(3)];








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights

w1   =   ((4 * Gamma - 3 * gamma.^2) + gamma .* sqrt(4 * Gamma - 3 * gamma.^2)) ./ (2 * (4 * Gamma - 3 * gamma.^2) .* (Gamma - gamma.^2));
w2   =   (Gamma - gamma.^2 - 1) ./ (Gamma - gamma.^2);
w3   =   ((4 * Gamma - 3 * gamma.^2) - gamma .* sqrt(4 * Gamma - 3 * gamma.^2)) ./ (2 * (4 * Gamma - 3 * gamma.^2) .* (Gamma - gamma.^2));


w_x1  =  [w1(1), w2(1), w3(1)];
w_x2  =  [w1(2), w2(2), w3(2)];
w_x3  =  [w1(3), w2(3), w3(3)];



w  =  [];
for i1 = 1:3    
    w_1 = w_x1(i1);    
    
    for i2 = 1:3       
        w_2 = w_x2(i2);       
        
        for i3 = 1:3            
            w_3 = w_x3(i3);                   
           
            we   =  w_1 * w_2 * w_3;
            w    =  [w; we];
        end       
    end    
end
w;





 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples

samples  =  [];
for i1 = 1:3
    vec1 = mu(1) + alpha_x1(i1) * sigma(1);
    
    for i2 = 1:3        
        vec2 = mu(2) + alpha_x2(i2) * sigma(2);
        
        for i3 = 1:3
            vec3 = mu(3) + alpha_x3(i3) * sigma(3);
                                       
            s          =   [vec1,  vec2,  vec3];            
            samples    =   [samples; s];          
        end        
    end    
end
samples;









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L = size(samples,1);

y = [];
for i = 1:L
    
    z           =     samples(i,:);   
    
    B1          =     z(2) * sqrt(det(lam_2)/lam11) + (lam12/lam11) * s1 * z(1);
    B2          =     z(3) * sqrt(det(lam_3)/det(lam_2)) - (lam_31_3/lam_33_3) * s1 * z(1) - (lam_32_3/lam_33_3) * B1;

    f           =     0.0533 - 10^(-9)*(4 * 2.54^3./((mu3 + B2) .* 0.0622 * 0.0988)) .* sqrt(((mu1 + s1 * z(1))./0.0622^2).^2 + ((mu2 + B1)./0.0988^2).^2);

    y       =     [y; f];
    
end
y;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m  =  4;

raw_mom = [];
for i = 1:m
    
    mom     = sum(w .* y.^i);
    raw_mom = [raw_mom; mom];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 0.0121;
% std_mcs  = 0.0131;
% ske_mcs  = -0.7093;
% kur_mcs  = 3.8443;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 0.0128;
% std_mcs  = 0.01076;
% ske_mcs  = -0.5205;
% kur_mcs  = 3.3699;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
  
mean_mcs = 0.0134;
std_mcs  = 0.0079;
ske_mcs  = -0.2937;
kur_mcs  = 3.0342;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]
