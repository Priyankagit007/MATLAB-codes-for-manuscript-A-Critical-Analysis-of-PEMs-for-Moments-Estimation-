
% Simple cantilever beam

clc
clear all
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Evans method

% EM_1 = [-0.3763    0.4250  -64.1422   -3.297];
% EM_2 = [0.2214    0.9700  -75.2817  -11.9960];
% EM_3 = [0.0387    0.7111  -97.0339  -15.3709];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FFNI method

FFNIM_1 = [-0.3735    0.3592    0.7860    6.9195];
FFNIM_2 = [0.2195    0.9614    2.7963   -1.5625];
FFNIM_3 = [0.0358    0.6967    5.2583  -10.5853];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Harr method

HM_1 = [-1.0475    1.0296   96.4334   64.9053];
HM_2 = [0.3210    3.8548   58.7648   44.3496];
HM_3 = [-0.7696   -4.2942   24.0664   34.7843];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Li method

LM_1 = [-0.5883    3.2332   63.2627   66.6328];
LM_2 = [0.3210    3.8548   58.7648   44.3496];
LM_3 = [0.3982    8.1393  319.1642   10.0509];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified Harr method

MHM_1 = [-0.9203   -0.3123   54.5960   40.0276];
MHM_2 = [0.3210    3.8548   58.7648   44.3496];
MHM_3 = [-0.7596   -3.8925  109.1988   63.1342];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified Rosenblueth method

MRM_1 = [-1.1133    2.4381  122.4792   87.8976];
MRM_2 = [-0.3364    1.5476  137.0216   79.9188];
MRM_3 = [-0.3837    1.6565  327.4439   62.1693];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Zhao and Ono method

ZOM_1 = [-0.5054    2.5883   22.7322   12.8978];
ZOM_2 = [0.2721    3.0782   23.1186    9.9006];
ZOM_3 = [0.2371    2.9864  -15.3367    6.7071];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rosenblueth method

RM_1 = [-1.0187    1.1519   99.0507   61.5257];
RM_2 = [-0.4479   -1.2447   83.9467   48.1757];
RM_3 = [-0.6821   -5.0496   91.9671   51.1204];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DRM

DRM_1 = [-0.4164    0.2869    3.3583    5.1442];
DRM_2 = [0.1868    0.7765    3.9863    0.5906];
DRM_3 = [0.0158    0.4833    5.5726    0.6372];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MEan

y1 = abs([RM_1(1) HM_1(1) MHM_1(1) LM_1(1) MRM_1(1) ZOM_1(1) FFNIM_1(1) DRM_1(1);  RM_2(1) HM_2(1) MHM_2(1) LM_2(1) MRM_2(1) ZOM_2(1) FFNIM_2(1) DRM_2(1); RM_3(1) HM_3(1) MHM_3(1) LM_3(1) MRM_3(1) ZOM_3(1) FFNIM_3(1) DRM_3(1)]);
y2 = abs([RM_1(2) HM_1(2) MHM_1(2) LM_1(2) MRM_1(2) ZOM_1(2) FFNIM_1(2) DRM_1(2);  RM_2(2) HM_2(2) MHM_2(2) LM_2(2) MRM_2(2) ZOM_2(2) FFNIM_2(2) DRM_2(2); RM_3(2) HM_3(2) MHM_3(2) LM_3(2) MRM_3(2) ZOM_3(2) FFNIM_3(2) DRM_3(2)]);
y3 = abs([RM_1(3) HM_1(3) MHM_1(3) LM_1(3) MRM_1(3) ZOM_1(3) FFNIM_1(3) DRM_1(3);  RM_2(3) HM_2(3) MHM_2(3) LM_2(3) MRM_2(3) ZOM_2(3) FFNIM_2(3) DRM_2(3); RM_3(3) HM_3(3) MHM_3(3) LM_3(3) MRM_3(3) ZOM_3(3) FFNIM_3(3) DRM_3(3)]);
y4 = abs([RM_1(4) HM_1(4) MHM_1(4) LM_1(4) MRM_1(4) ZOM_1(4) FFNIM_1(4) DRM_1(4);  RM_2(4) HM_2(4) MHM_2(4) LM_2(4) MRM_2(4) ZOM_2(4) FFNIM_2(4) DRM_2(4); RM_3(4) HM_3(4) MHM_3(4) LM_3(4) MRM_3(4) ZOM_3(4) FFNIM_3(4) DRM_3(4)]);









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting

color_matrix = [
    % 0.0 0.5 0.5; 
    0.0 0.8 0.8; 
    0.5 0.5 0.0;
    0.8 0.8 0.0; 
    0.9 0.54 0.0; 
    0.40 0.40 0.70; 
    0.60 0.40 0.80;
    0.6 0.10 0.10; 
    1.0 0.30 0.30  
];

% 1. Create a tiled chart layout
figure;
tcl = tiledlayout(2,2,'TileSpacing','loose','Padding','loose'); % Adjust rows and columns as needed



% 2. Plot your data in different tiles
nexttile;
b1 = bar(y1, 'FaceColor', 'flat');
for k = 1:size(y1,2)
    b1(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'$\rho = -0.5$','$\rho = 0$', '$\rho = 0.5$'}, 'TickLabelInterpreter','latex');
ylabel('Relative error, $\mathcal{E}_{1}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)


nexttile;
b2 = bar(y2, 'FaceColor','flat');
for k = 1:size(y2,2)
    b2(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'$\rho = -0.5$','$\rho = 0$', '$\rho = 0.5$'}, 'TickLabelInterpreter','latex');
ylabel('Relative error, $\mathcal{E}_{2}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



nexttile;
b3 = bar(y3, 'FaceColor','flat');
for k = 1:size(y3,2)
    b3(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'$\rho = -0.5$','$\rho = 0$', '$\rho = 0.5$'}, 'TickLabelInterpreter','latex');
ylabel('Relative error, $\mathcal{E}_{3}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



nexttile;
b4 = bar(y4, 'FaceColor','flat');
for k = 1:size(y4,2)
    b4(k).CData = color_matrix(k,:);
end
set(gca,'XTickLabel',{'$\rho = -0.5$','$\rho = 0$', '$\rho = 0.5$'}, 'TickLabelInterpreter','latex');
ylabel('Relative error, $\mathcal{E}_{4}$ (\%)', 'Interpreter', 'latex');
set(gca,'FontName','Arial','linewidth',1.1)



% 3. Create a single legend for all plots
hL = legend(b4, 'RM ($\mathcal{N}$ = 8)', 'HM ($\mathcal{N}$ = 6)', 'MHM ($\mathcal{N}$ = 6)', 'LM ($\mathcal{N}$ = 10)', 'MRM ($\mathcal{N}$ = 10)', 'ZOM, v=5 ($\mathcal{N}$ = 13)', 'FFNIM ($\mathcal{N}$ = 27)', 'Bivariate DRM, v=5 ($\mathcal{N}$ = 61)', 'Location', 'south','Orientation','horizontal','NumColumns',4,'Interpreter','latex'); % You can specify an initial location here
set(gca,'FontName','Arial','linewidth',1.1)



% 4. Move the legend to the right side using the Layout property
hL.Layout.Tile = 'south';
hL.ItemTokenSize = [18 18];


set(gcf,'position',[100,100,650,500])
str = ['Prob_2_simple_CB'];
savePDF(str)

