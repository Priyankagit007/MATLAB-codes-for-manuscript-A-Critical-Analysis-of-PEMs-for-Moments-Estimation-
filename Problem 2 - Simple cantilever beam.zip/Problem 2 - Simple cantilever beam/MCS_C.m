

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Cantilever

clear all
close all
clc

N        =      10^7;
n        =      3;


mu       =      [2222.64,  4445.28,  200];
sigma    =      [444.5,  444.5,  10]*2;
rho_ij   =      [0, 0.5, 0.5];


cov = [];
for i = 1:n
    
    vec         =    rho_ij(1:n-i) .* sigma(i) .* sigma(i+1:end);   
    k           =    [zeros(1,i-1), sigma(i)^2, vec];
    cov         =    [cov; k];    
    L           =    length(vec);    
    rho_ij      =    rho_ij(L+1:end);
    
end
cov;

di             =   diag(cov);
upper          =   triu(cov,1);                  % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
cov            =   upper + diag(di) + lower;

x              =   mvnrnd(mu, cov, N);

x1             =   x(:,1);
x2             =   x(:,2);
x3             =   x(:,3);



f              =   0.0533 - 10^(-9) * (4 * 2.54^3./(x3 .* 0.0622 * 0.0988)) .* sqrt((x1./0.0622^2).^2 + (x2./0.0988^2).^2);

mean_f         =   mean(f)
std_f          =   std(f)
skew_f         =   skewness(f)
kur_f          =   kurtosis(f)
