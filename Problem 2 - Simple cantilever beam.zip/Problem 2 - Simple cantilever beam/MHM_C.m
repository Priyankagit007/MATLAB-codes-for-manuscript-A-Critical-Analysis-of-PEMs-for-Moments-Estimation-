
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Cantilever

clear all
close all
clc

n      =  3;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu       =      [2222.64,  4445.28,  200];
sigma    =      [444.5,  444.5,  10]*2;
gamma    =      zeros(1,n);

rh       =      0.5;
rho_ij   =      [0, rh, rh];



cov = [];
for i = 1:n
    
    vec         =    rho_ij(1:n-i) .* sigma(i) .* sigma(i+1:end);   
    k           =    [zeros(1,i-1), sigma(i)^2, vec];
    cov         =    [cov; k];    
    L           =    length(vec);    
    rho_ij      =    rho_ij(L+1:end);
    
end
cov;

di             =   diag(cov);
upper          =   triu(cov,1);                  % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
cov            =   upper + diag(di) + lower;
rho            =   corrcov(cov);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eigenvectors & Eigenvalues of correlation matrix

[eig_vec, eig_val]   =    eig(rho);

V                    =    eig_vec;         % eigenvectors
lambda               =    diag(eig_val);   % eigenvalues





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Root of diagonal matrix of eigenvalues

sq_Delta   =    sqrt(eig_val);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Root of diagonal matrix of standard deviations

sq_D       =    diag(sigma);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples

e   =   eye(n,n);

samples  = [];
for i = 1:n
    
    xi_p     =   mu + sqrt(n) * (sq_D * V(:,i))' * sq_Delta(i,i);
    xi_m     =   mu - sqrt(n) * (sq_D * V(:,i))' * sq_Delta(i,i);

    
    samples  =   [samples; xi_p; xi_m];
    
end
samples;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function values

L = size(samples,1);

y = [];
for i = 1:L
    
    x = samples(i,:);
    f = 0.0533 - 10^(-9)*(4 * 2.54^3./(x(3) .* 0.0622 * 0.0988)) .* sqrt((x(1)./0.0622^2).^2 + (x(2)./0.0988^2).^2);
    y = [y; f];
    
end
y;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    new_y = y.^i;
    
    mom = 0;
    for j = 1:n
        
        mom     = mom + (new_y(2*j-1) + new_y(2*j))/2;
        
    end
    
    raw_mom = [raw_mom; mom/n];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 0.0121;
% std_mcs  = 0.0131;
% ske_mcs  = -0.7093;
% kur_mcs  = 3.8443;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 0.0128;
% std_mcs  = 0.01076;
% ske_mcs  = -0.5205;
% kur_mcs  = 3.3699;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
  
mean_mcs = 0.0134;
std_mcs  = 0.0079;
ske_mcs  = -0.2937;
kur_mcs  = 3.0342;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]
