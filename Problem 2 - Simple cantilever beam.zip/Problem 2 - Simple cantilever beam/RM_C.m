
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Cantilever


clear all
close all
clc

n         =     3;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input moments

mu       =      [2222.64,  4445.28,  200];
sigma    =      [444.5,  444.5,  10]*2;
gamma    =      zeros(1,n);

rh       =      0.5;
rho_ij   =      [0, rh, rh];


cov = [];
for i = 1:n
    
    vec         =    rho_ij(1:n-i) .* sigma(i) .* sigma(i+1:end);   
    k           =    [zeros(1,i-1), sigma(i)^2, vec];
    cov         =    [cov; k];    
    L           =    length(vec);    
    rho_ij      =    rho_ij(L+1:end);
    
end
cov;

di             =   diag(cov);
upper          =   triu(cov,1);                  % upper triangular matrix
lower          =   upper';                       % lower triangular matrix
cov            =   upper + diag(di) + lower;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Correlation matrix

rho       =     corrcov(cov);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% alpha +-

alpha_p   =     (gamma  + sqrt(4 + gamma.^2))/2;
alpha_m   =     (-gamma + sqrt(4 + gamma.^2))/2;


alpha_pm  =     [alpha_p; alpha_m];







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights +-

wp        =     alpha_m./(alpha_p + alpha_m);
wm        =     alpha_p./(alpha_p + alpha_m);

w_pm      =     [wp; wm];





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
beta      =     [1, -1];




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Samples


samples = [];
for i1 = 1:2
    sam1 = mu(1) + beta(i1) * alpha_pm(i1,1) * sigma(1);
    
    for i2 = 1:2        
        sam2 = mu(2) +  beta(i2) * alpha_pm(i2,2) * sigma(2);
        
        for i3 = 1:2            
            sam3 = mu(3) +  beta(i3) * alpha_pm(i3,3) * sigma(3);                            
            
            samples   =   [samples; sam1, sam2, sam3];           
        end        
    end    
end
samples;










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function Values

L = size(samples,1);

y = [];
for i = 1:L
    
    x = samples(i,:);
    f = 0.0533 - 10^(-9)*(4 * 2.54^3./(x(3) .* 0.0622 * 0.0988)) .* sqrt((x(1)./0.0622^2).^2 + (x(2)./0.0988^2).^2);
    y = [y; f];
    
end
y;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weights

%-----------Uncorrelated weights--------------%
W1 = [];
for i1 = 1:2
    w1 = w_pm(i1,1);
    
    for i2 = 1:2
        w2 = w_pm(i2,2);
        
        for i3 = 1:2
            w3 = w_pm(i3,3);

            w    =  w1 * w2 * w3;            
            W1   =  [W1; w];
        end
    end
end
W1;





%---------------rho_ij------------------%
rho_ij = [];
for i = 1:n-1
    
    vec     =     rho(i,i+1:end);
    rho_ij  =     [rho_ij, vec];
    
end
rho_ij;




%--------------denominator--------------%
pr = 1;
for i = 1:n

    pr   =    pr * (1 + (gamma(i)/2)^2);
    
end
Deno = sqrt(pr);




%----------------a_ij---------------%
aij    =    (rho_ij/2^n) / Deno;





%--------------Correlated weights---------------%
all_sign = [];
for i1 = 1:2
    sign1 = beta(i1);
    for i2 = 1:2
        sign2 = beta(i2);
        for i3 = 1:2
            sign3 = beta(i3);
            all_sign  = [all_sign; sign1, sign2, sign3];
        end
    end
end
all_sign;




C     =  nchoosek([1:n],2);
b     =  nchoosek(n,2);



%-------------Product of two signs--------------%
prod_sign_aij = [];
for i = 1:2^n
    
    vec   =   all_sign(i,:);   
    
    sign_aij = [];
    for j = 1:b
        
        k          =    C(j,:);
        prod       =    vec(k(1)) * vec(k(2));        
        sign_aij   =    [sign_aij, prod];
        
    end
    
    prod_sign_aij  =    [prod_sign_aij; sign_aij];
    
end
prod_sign_aij;

W2       =  prod_sign_aij .* aij;


%--------------Final weights-------------------%
Weights  =  sum([W1, W2],2);    % columnwise sum








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mean, Variance, Skewness, Kurtosis

m = 4;

raw_mom = [];
for i = 1:m
    
    mom     = sum(Weights .* y.^i);
    raw_mom = [raw_mom; mom];
    
end
raw_mom;

mean_y = raw_mom(1)

var_y  = raw_mom(2) - raw_mom(1)^2;

std_y  = sqrt(var_y)

ske_y  = (raw_mom(3) - 3 * raw_mom(2) * raw_mom(1) + 2 * raw_mom(1)^3) / sqrt(var_y)^3

kur_y  = (raw_mom(4) - 4 * raw_mom(3) * raw_mom(1) + 6 * raw_mom(2) * raw_mom(1)^2 - 3 * raw_mom(1)^4) / sqrt(var_y)^4

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 0.0121;
% std_mcs  = 0.0131;
% ske_mcs  = -0.7093;
% kur_mcs  = 3.8443;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo

% mean_mcs = 0.0128;
% std_mcs  = 0.01076;
% ske_mcs  = -0.5205;
% kur_mcs  = 3.3699;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Monte Carlo
  
mean_mcs = 0.0134;
std_mcs  = 0.0079;
ske_mcs  = -0.2937;
kur_mcs  = 3.0342;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Error

err_mean = ((mean_mcs - mean_y)/mean_mcs)*100;
err_std  = ((std_mcs - std_y)/std_mcs)*100;
err_ske  = ((ske_mcs - ske_y)/ske_mcs)*100;
err_kur  = ((kur_mcs - kur_y)/kur_mcs)*100;

final_err  =  [err_mean, err_std, err_ske, err_kur]
